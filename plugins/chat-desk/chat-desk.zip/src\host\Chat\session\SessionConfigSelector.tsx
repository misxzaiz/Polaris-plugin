/**
 * SessionConfigSelector - 会话配置选择器
 *
 * 用于选择 Agent/Model/Effort/PermissionMode
 * 位于 ChatStatusBar 中，影响下一次发送消息的行为
 *
 * Agent/Model 列表优先从 cliInfoStore 动态获取，降级使用 PRESET_AGENTS/PRESET_MODELS
 */

import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { ChevronDown, Bot, Cpu, Zap, Shield, Plug } from 'lucide-react'
import { clsx } from 'clsx'
import {
  PRESET_AGENTS,
  PRESET_MODELS,
  EFFORT_OPTIONS,
  PERMISSION_MODE_OPTIONS,
  type SessionRuntimeConfig,
  type EffortLevel,
  type PermissionMode,
} from '@/types/sessionConfig'
import { useCliInfoStore } from '@/stores/cliInfoStore'
import { useAgentStore } from '@/stores/agentStore'
import { useConfigStore } from '@/stores'
import { useModelProfileStore } from '@/stores/modelProfileStore'
import { useEngineMetadataStore } from '@/stores/engineMetadataStore'
import { getEngineEffortOptions, getEnginePermissionOptions } from '@/utils/engineCapabilities'
import { isProfileForEngine, OFFICIAL_API_PROFILE, profileModelOptions, type WireApi } from '@/types/modelProfile'
import { useActiveSessionId, useSessionMetadataList, sessionStoreManager } from '@/stores/conversationStore/sessionStoreManager'
import { normalizeEngineId } from '@/utils/engineDisplay'
import { getEngineSelectors } from '@/utils/engineCapabilities'

interface SessionConfigSelectorProps {
  /** 当前配置 */
  config: SessionRuntimeConfig
  /** 配置变更回调 */
  onChange: (config: SessionRuntimeConfig) => void
  /** 是否禁用 */
  disabled?: boolean
  /** 只渲染指定类型的选择器，不传则渲染全部 */
  visibleTypes?: SelectorType[]
  /** 布局变体：inline 横向紧凑（主行），panel 纵向带 label（折叠面板） */
  variant?: 'inline' | 'panel'
  /**
   * 引擎覆盖：传入时按该引擎过滤 Profile / 推导选择器，不依赖活跃会话引擎。
   * 用于新建会话面板（状态栏会话的引擎 ≠ 面板待选引擎）。
   */
  engineOverride?: string
  /**
   * 选择是否写回当前活跃会话 metadata（状态栏切换 = true）。
   * 新建会话面板传 false：面板里的选择只在「创建」时生效，不污染当前会话。
   */
  writeThroughToSession?: boolean
}

type SelectorType = 'agent' | 'model' | 'effort' | 'permission' | 'profile'

/** Profile 线路协议的视觉标识（状态栏 Profile 选择器用，三协议各自区分） */
function wireApiBadge(wireApi?: WireApi): string {
  switch (wireApi) {
    case 'openai-chat-completions':
      return '🔵'
    case 'openai-responses':
      return '🟢'
    default:
      // 缺省 / anthropic-messages
      return '🟣'
  }
}

/** 安全解析 baseUrl 主机名，非法 URL 时回退原串（避免选择器渲染崩溃） */
function safeHostname(baseUrl: string): string {
  try {
    return new URL(baseUrl).hostname
  } catch {
    return baseUrl
  }
}

/**
 * 会话配置选择器组件
 */
export function SessionConfigSelector({
  config,
  onChange,
  disabled = false,
  visibleTypes,
  variant = 'inline',
  engineOverride,
  writeThroughToSession = true,
}: SessionConfigSelectorProps) {
  const { t } = useTranslation('chat')
  const [openDropdown, setOpenDropdown] = useState<SelectorType | null>(null)
  const [customInput, setCustomInput] = useState<{ type: SelectorType; value: string } | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // 点击外部关闭下拉
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpenDropdown(null)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // 模型 Profile 列表
  const profiles = useModelProfileStore(s => s.profiles)

  // 当前引擎（用于过滤 Profile）：优先取 engineOverride（新建会话面板），
  // 否则取活动会话的引擎，降级到全局默认引擎。
  // 映射到 isProfileForEngine 的引擎参数（claude / simple-ai）。
  const activeSessionId = useActiveSessionId()
  const sessionMetadataList = useSessionMetadataList()
  const defaultEngine = useConfigStore(s => s.config?.defaultEngine)
  const activeMeta = sessionMetadataList.find(s => s.id === activeSessionId)
  const activeEngineId = normalizeEngineId(engineOverride ?? activeMeta?.engineId ?? defaultEngine)
  const currentEngine: string =
    activeEngineId === 'simple-ai'
      ? 'simple-ai'
      : activeEngineId === 'claude-code'
        ? 'claude'
        : activeEngineId

  const isSimpleAiEngine = currentEngine === 'simple-ai'
  useEffect(() => {
    if (isSimpleAiEngine) {
      void useAgentStore.getState().loadSimpleAiAgents()
    }
  }, [isSimpleAiEngine])

  // 插件引擎声明的模型目录（contributes.engines[].models 经 EngineMetadata.models 透传，
  // 如 codebuddy 的 hy4-preview）。用 useMemo 保持引用稳定，避免 zustand 选择器返回新数组导致重渲染。
  const engineMetadatas = useEngineMetadataStore(s => s.metadatas)
  const engineDeclaredModels = useMemo(
    () => engineMetadatas.find(m => m.id === currentEngine)?.models?.filter(Boolean) ?? null,
    [engineMetadatas, currentEngine],
  )

  // 动态 Agent 列表：claude 引擎优先 CLI 获取，SimpleAI 用两级 discover(项目级+全局 corpus)，降级 PRESET
  const dynamicAgents = useCliInfoStore(s => s.agents)
  const simpleAiAgents = useAgentStore(s => s.simpleAiAgents)
  const agentList = useMemo(() => {
    const emptyOption = { id: '', name: t('sessionConfig.noAgent'), description: t('sessionConfig.noAgentDesc') }
    if (isSimpleAiEngine) {
      return [
        emptyOption,
        ...simpleAiAgents.map(a => ({
          id: a.slug,
          name: `${a.emoji ? a.emoji + ' ' : ''}${a.name}`,
          description: a.description,
        })),
      ]
    }
    if (dynamicAgents.length > 0) {
      return [
        emptyOption,
        ...dynamicAgents.map(a => ({
          id: a.id,
          name: a.name,
          description: `${a.source === 'plugin' ? t('sessionConfig.pluginSource') : t('sessionConfig.builtinSource')}${a.defaultModel ? ` · ${a.defaultModel}` : ''}`,
        }))
      ]
    }
    return PRESET_AGENTS
  }, [dynamicAgents, simpleAiAgents, isSimpleAiEngine, t])


  // 模型列表：根据当前选中的 Profile 动态生成。
  // - 选择官方 API（modelProfileId='' 或未选 Profile）：
  //   · claude：使用官方模型档位
  //   · simple-ai：必须由 Profile 提供，无 Profile 时为空（SimpleAI 无官方通道）
  // - 选择某个 Profile：使用该 Profile 的 modelOptions（为空时回退到 [model]）
  const modelList = useMemo(() => {
    // 插件引擎声明的模型目录优先（声明即权威目录）：
    // 官方 Claude PRESET 对插件引擎无意义，Profile 也未必建立（如 codebuddy 免登录直用）。
    // 首项保留「不设置」= 走引擎默认模型（adapter 侧默认）。
    if (engineDeclaredModels && engineDeclaredModels.length > 0) {
      return [
        { id: '', name: t('sessionConfig.noModel'), description: '', supportsStreaming: true },
        ...engineDeclaredModels.map(m => ({
          id: m,
          name: m,
          description: '',
          supportsStreaming: true,
        })),
      ]
    }
    const profileId = config.modelProfileId
    if (!profileId) {
      // SimpleAI 模型完全由 Profile 驱动，无 Profile 时不可选模型
      if (currentEngine === 'simple-ai') return []
      return PRESET_MODELS
    }
    const profile = profiles.find(p => p.id === profileId)
    if (!profile) {
      if (currentEngine === 'simple-ai') return []
      return PRESET_MODELS
    }
    const options = (profile.modelOptions?.length ? profile.modelOptions : [profile.model]).filter(Boolean)
    return options.map(m => ({
      id: m,
      name: m,
      description: '',
      supportsStreaming: true,
    }))
  }, [config.modelProfileId, profiles, currentEngine, engineDeclaredModels, t])

  // 切换供应商（Profile）后，清掉不属于该 Profile 的残留模型选择。
  // config.model 是跨 Profile 持久化的：从官方 API（opus/sonnet/haiku）切到第三方
  // Profile 时，下拉会因「保留当前已选」而继续显示并发送那个 CLI 官方别名，第三方端点
  // 不认 → 400 invalid_request_error: unknown provider for model opus。
  // 清空（而非选默认）让用户显式选择；发送层另有 normalizeModelForProfile 兜底，
  // 空 model 会回退到 profile.model 默认模型，请求仍可正常发出。
  useEffect(() => {
    if (disabled || config.profileMode !== 'profile' || !config.modelProfileId) return
    const profile = profiles.find(p => p.id === config.modelProfileId)
    if (!profile || !config.model) return
    if (profileModelOptions(profile).includes(config.model)) return
    onChange({ ...config, model: '' })
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅依赖 Profile 变更触发，config 整体读用（见上注释）
  }, [profiles, config.modelProfileId, config.profileMode, disabled])

  // 按当前引擎过滤 Profile 列表
  const compatibleProfiles = useMemo(() => {
    return profiles.filter(p => isProfileForEngine(p, currentEngine))
  }, [profiles, currentEngine])

  // 获取当前选择的显示名称
  const getAgentLabel = useCallback((agentId?: string) => {
    if (!agentId) return t('sessionConfig.noAgent')
    const agent = agentList.find(a => a.id === agentId)
    if (agent?.name) return agent.name
    // corpus/自定义专家兜底:catalog 映射 emoji+显示名(claude 引擎 CLI 列表不含它们)
    const entry = useAgentStore.getState().catalog.find(c => c.slug === agentId)
      ?? useAgentStore.getState().customAgents.find(c => c.slug === agentId)
    if (entry) return `${'emoji' in entry && entry.emoji ? entry.emoji + ' ' : ''}${entry.name}`
    return agentId
  }, [t, agentList])

  const getModelLabel = useCallback((modelId?: string) => {
    if (!modelId) return t('sessionConfig.noModel')
    // 检查当前选中 Profile 的模型列表
    const activeProfile = profiles.find(p => p.id === config.modelProfileId)
    if (activeProfile) {
      const options = activeProfile.modelOptions?.length ? activeProfile.modelOptions : [activeProfile.model]
      if (options.includes(modelId)) return modelId
    }
    // 官方模型
    const model = PRESET_MODELS.find(m => m.id === modelId)
    return model?.name || modelId
  }, [t, profiles, config.modelProfileId])

  const getEffortLabel = useCallback((effort?: EffortLevel | '') => {
    if (!effort) return t('sessionConfig.noEffort')
    // 引擎声明的选项优先（标签可能自定义），降级全局 EFFORT_OPTIONS
    const declared = getEngineEffortOptions(currentEngine)?.find(o => o.value === effort)
    if (declared) return declared.label
    const opt = EFFORT_OPTIONS.find(o => o.value === effort)
    return opt?.label || effort
  }, [t, currentEngine])

  const getPermissionLabel = useCallback((mode?: PermissionMode | '') => {
    if (!mode) return t('sessionConfig.noPermission')
    const declared = getEnginePermissionOptions(currentEngine)?.find(o => o.value === mode)
    if (declared) return declared.label
    const opt = PERMISSION_MODE_OPTIONS.find(o => o.value === mode)
    return opt?.label || mode
  }, [t, currentEngine])

  // 通用选择处理
  const handleSelect = useCallback((type: SelectorType, value: string) => {
    // 跳过提示项
    if (value === '__skipped__') return
    // 处理字段名映射
    const configKey = type === 'permission' ? 'permissionMode' : type === 'profile' ? 'modelProfileId' : type
    // 切换供应商时自动重置模型选择
    const nextConfig: Partial<SessionRuntimeConfig> = {
      [configKey]: value,
    }
    if (type === 'profile') {
      // 切换到官方 API 或新供应商时，清空模型选择（让用户重新选或默认）
      nextConfig.model = ''
      // 二态供应商模式（官方 / 指定 Profile）
      if (value === '') {
        // 官方 API
        nextConfig.profileMode = 'official'
        nextConfig.modelProfileId = ''
      } else {
        // 指定 Profile
        nextConfig.profileMode = 'profile'
        nextConfig.modelProfileId = value
      }
    }
    onChange({
      ...config,
      ...nextConfig,
    })
    // P1: Profile / Model / Agent 是会话级覆盖 — 写入当前会话的 metadata，实现窗口间隔离。
    // 新建会话面板（writeThroughToSession=false）不写回当前会话，仅持有面板态，创建时统一透传。
    const activeId = writeThroughToSession ? sessionStoreManager.getState().activeSessionId : null
    if (activeId) {
      if (type === 'profile') {
        // 二态供应商模式写入会话级覆盖：
        // - 官方 → 哨兵 + profileMode=official
        // - 指定 Profile → id + profileMode=profile
        if (value === '') {
          sessionStoreManager.getState().updateSessionModelProfile(activeId, OFFICIAL_API_PROFILE)
          sessionStoreManager.getState().updateSessionProfileMode(activeId, 'official')
        } else {
          sessionStoreManager.getState().updateSessionModelProfile(activeId, value)
          sessionStoreManager.getState().updateSessionProfileMode(activeId, 'profile')
        }
      } else if (type === 'model') {
        sessionStoreManager.getState().updateSessionModel(activeId, value)
      } else if (type === 'agent') {
        // 空值 = 清除专家；非空 = 写入会话级专家覆盖。
        sessionStoreManager.getState().updateSessionAgent(activeId, value || null)
      }
    }
    setOpenDropdown(null)
  }, [config, onChange, writeThroughToSession])

  const handleCustomInputConfirm = useCallback((type: SelectorType) => {
    if (!customInput || customInput.type !== type) return
    const value = customInput.value.trim()
    if (value) {
      handleSelect(type, value)
    }
    setCustomInput(null)
  }, [customInput, handleSelect])

  // 打开自定义输入模式
  const openCustomInput = useCallback((type: SelectorType) => {
    setCustomInput({ type, value: '' })
    setOpenDropdown(null)
    // 延迟聚焦输入框
    setTimeout(() => inputRef.current?.focus(), 0)
  }, [])

  // 渲染下拉选项
  const renderDropdown = (type: SelectorType) => {
    if (openDropdown !== type) return null

    type DropdownItem = { value: string; label: string; description?: string; disabled?: boolean }
    const items: DropdownItem[] = []

    switch (type) {
      case 'agent':
        items.push(...agentList.map(a => ({
          value: a.id,
          label: a.name,
          description: a.description,
        })))
        break
      case 'model':
        items.push(...modelList.map(m => ({
          value: m.id,
          label: m.name,
          description: m.description,
        })))
        break
      case 'effort': {
        // 引擎声明的 effort 选项优先（如 codebuddy 的 minimal 值），
        // 无声明降级到全局 EFFORT_OPTIONS（向后兼容）
        const opts = getEngineEffortOptions(currentEngine) ?? EFFORT_OPTIONS
        items.push(...opts.map(o => ({
          value: o.value,
          label: o.label,
          description: o.description,
        })))
        break
      }
      case 'permission': {
        // 引擎声明的 permission 选项优先，无声明降级到全局 PERMISSION_MODE_OPTIONS
        const opts = getEnginePermissionOptions(currentEngine) ?? PERMISSION_MODE_OPTIONS
        items.push(...opts.map(o => ({
          value: o.value,
          label: o.label,
          description: o.description,
        })))
        break
      }
      case 'profile': {
        // P2/P3: 区块 = 官方 API / 分组路由(多分组) / 指定 Profile
        // 区块 1：官方 API（value='' → profileMode=official）
        items.push({
          value: '',
          label: t('sessionConfig.officialApi'),
          description: t('sessionConfig.officialApiDesc'),
        })
        // 区块 2：指定 Profile（value=profileId → profileMode=profile）
        items.push(...compatibleProfiles.map(p => {
          const modelCount = p.modelOptions?.length || 1
          return {
            value: p.id,
            label: `${wireApiBadge(p.wireApi)} ${p.name}`,
            description: p.description || `${p.baseUrl ? safeHostname(p.baseUrl) : ''} · ${modelCount} 个模型`,
          }
        }))
        // 被当前引擎过滤掉的 Profile 提示
        const skippedCount = profiles.length - compatibleProfiles.length
        if (skippedCount > 0) {
          items.push({
            value: '__skipped__',
            label: `… 另有 ${skippedCount} 个 Profile 不适用于当前引擎`,
            description: '',
            disabled: true,
          })
        }
        break
      }
    }

    const getCurrentValue = (): string | undefined => {
      switch (type) {
        case 'agent': return config.agent
        case 'model': return config.model
        case 'effort': return config.effort
        case 'permission': return config.permissionMode
        case 'profile': {
          // 二态高亮。根据当前 profileMode + modelProfileId 对齐下拉项 value：
          // - official → 高亮 '' (官方 API)
          // - profile → 高亮对应 profileId
          const mode = config.profileMode ?? 'profile'
          if (mode === 'official') return ''
          return config.modelProfileId ?? ''
        }
        default: return undefined
      }
    }

    const currentValue = getCurrentValue()

    return (
      <div className={clsx(
        'absolute bottom-full left-0 mb-1',
        'bg-background-elevated border border-border rounded-lg shadow-lg',
        'min-w-[180px] max-h-[240px] overflow-y-auto',
        'z-dropdown animate-panel-in'
      )}>
        {items.map((item) => (
          <button
            key={item.value}
            onClick={() => !item.disabled && handleSelect(type, item.value)}
            disabled={item.disabled}
            title={item.disabled ? item.description : undefined}
            className={clsx(
              'w-full px-3 py-2 text-left text-xs',
              'transition-colors',
              'flex flex-col gap-0.5',
              item.disabled
                ? 'opacity-50 cursor-not-allowed hover:bg-transparent'
                : 'hover:bg-background-hover',
              currentValue === item.value && 'bg-primary/10 text-primary'
            )}
          >
            <span className="font-medium">{item.label}</span>
            {item.description && (
              <span className="text-text-tertiary text-[10px]">{item.description}</span>
            )}
          </button>
        ))}
        {/* 分隔线 */}
        <div className="border-t border-border my-1" />
        {/* 自定义输入选项 */}
        <button
          onClick={() => openCustomInput(type)}
          className={clsx(
            'w-full px-3 py-2 text-left text-xs',
            'hover:bg-background-hover transition-colors',
            'text-text-tertiary italic'
          )}
        >
          ✏️ {t('sessionConfig.custom')}
        </button>
      </div>
    )
  }

  // 选择器元数据映射（图标需可区分：profile 用 Plug，与 model 的 Cpu 区分开）
  const selectorMeta: Record<SelectorType, { icon: React.ReactNode; label: string; getValue: () => string }> = {
    agent: {
      icon: <Bot size={12} />,
      label: t('sessionConfig.agent'),
      getValue: () => getAgentLabel(config.agent),
    },
    model: {
      icon: <Cpu size={12} />,
      label: t('sessionConfig.model'),
      getValue: () => getModelLabel(config.model),
    },
    effort: {
      icon: <Zap size={12} />,
      label: t('sessionConfig.effort'),
      getValue: () => getEffortLabel(config.effort),
    },
    permission: {
      icon: <Shield size={12} />,
      label: t('sessionConfig.permission'),
      getValue: () => getPermissionLabel(config.permissionMode),
    },
    profile: {
      icon: <Plug size={12} />,
      label: t('sessionConfig.provider'),
      getValue: () => {
        // 二态显示：官方 / 指定 Profile
        const mode = config.profileMode ?? 'profile'
        if (mode === 'official') return t('sessionConfig.officialApi')
        if (!config.modelProfileId) return t('sessionConfig.noProfile')
        const profile = profiles.find(p => p.id === config.modelProfileId)
        if (!profile) return t('sessionConfig.noProfile')
        return `${wireApiBadge(profile.wireApi)} ${profile.name}`
      },
    },
  }

  // 各选择器值的最大宽度：profile（端点）最常用，给更宽的展示空间
  const VALUE_MAX_W: Record<SelectorType, string> = {
    profile: 'max-w-[140px]',
    model: 'max-w-[90px]',
    effort: 'max-w-[64px]',
    agent: 'max-w-[90px]',
    permission: 'max-w-[72px]',
  }

  // 渲染单个选择器按钮
  // - inline：横向紧凑，仅图标 + 截断值（主行）
  // - panel：纵向，图标 + 字段名 + 值（折叠面板，可读性优先）
  const renderSelector = (type: SelectorType, mode: 'inline' | 'panel') => {
    const { icon, label, getValue } = selectorMeta[type]
    const currentValue = getValue()
    return (
      <div className={clsx('relative', mode === 'panel' && 'w-full')}>
        <button
          onClick={() => !disabled && setOpenDropdown(openDropdown === type ? null : type)}
          disabled={disabled}
          className={clsx(
            'flex items-center gap-1 rounded text-xs transition-colors',
            mode === 'panel' ? 'w-full px-2 py-1' : 'px-1.5 py-0.5',
            disabled
              ? 'text-text-muted cursor-not-allowed'
              : 'text-text-tertiary hover:text-text-primary hover:bg-background-hover',
            openDropdown === type && 'bg-primary/10 text-primary'
          )}
          title={t(`sessionConfig.${type}Tooltip`)}
        >
          <span className="shrink-0">{icon}</span>
          {mode === 'panel' && <span className="shrink-0 text-text-muted">{label}</span>}
          <span className={clsx('truncate', mode === 'panel' ? 'flex-1 text-left' : VALUE_MAX_W[type])}>
            {currentValue}
          </span>
          <ChevronDown size={12} className="opacity-50 shrink-0" />
        </button>
        {renderDropdown(type)}
      </div>
    )
  }

  const ALL_TYPES: SelectorType[] = ['agent', 'model', 'effort', 'permission', 'profile']
  // 仅展示当前引擎实际支持的选择器：与调用方传入的 visibleTypes 求交集，
  // 防止向不支持的引擎渲染会导致后端报错的 profile / 无效的 agent·effort。
  const allowedByEngine = getEngineSelectors(activeEngineId)
  const typesToShow = (visibleTypes ?? ALL_TYPES).filter(t => allowedByEngine.includes(t))

  return (
    <div ref={containerRef} className={clsx(variant === 'panel' ? 'flex flex-col gap-0.5 w-full' : 'flex items-center gap-1')}>
      {typesToShow.map(type => (
        <React.Fragment key={type}>{renderSelector(type, variant)}</React.Fragment>
      ))}
      {/* 自定义输入浮层 */}
      {customInput && (
        <div className="fixed inset-0 z-modal flex items-center justify-center bg-black/30">
          <div className="bg-background-elevated border border-border rounded-lg p-4 min-w-[280px] shadow-xl">
            <div className="text-xs text-text-secondary mb-2">
              {t('sessionConfig.customInputLabel', { type: selectorMeta[customInput.type].label })}
            </div>
            <input
              ref={inputRef}
              type="text"
              value={customInput.value}
              onChange={(e) => setCustomInput({ ...customInput, value: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCustomInputConfirm(customInput.type)
                if (e.key === 'Escape') setCustomInput(null)
              }}
              className="w-full px-3 py-2 text-sm bg-background-surface border border-border rounded-lg outline-none focus:border-primary"
              placeholder={t('sessionConfig.customInputPlaceholder', { type: customInput.type })}
            />
            <div className="flex justify-end gap-2 mt-3">
              <button
                onClick={() => setCustomInput(null)}
                className="px-3 py-1.5 text-xs text-text-secondary hover:text-text-primary"
              >
                {t('sessionConfig.cancel')}
              </button>
              <button
                onClick={() => handleCustomInputConfirm(customInput.type)}
                className="px-3 py-1.5 text-xs bg-primary text-white rounded hover:bg-primary-hover"
              >
                {t('sessionConfig.confirm')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/**
 * 简化版选择器（仅 Agent + Model）
 *
 * 用于空间受限的场景
 */
export function CompactSessionSelector({
  config,
  onChange,
  disabled = false,
}: SessionConfigSelectorProps) {
  const { t } = useTranslation('chat')
  const [openDropdown, setOpenDropdown] = useState<SelectorType | null>(null)
  const [customInput, setCustomInput] = useState<{ type: SelectorType; value: string } | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // 动态 Agent 列表
  const dynamicAgents = useCliInfoStore(s => s.agents)
  const agentList = useMemo(() => {
    const emptyOption = { id: '', name: t('sessionConfig.noAgent') }
    if (dynamicAgents.length > 0) {
      return [emptyOption, ...dynamicAgents.map(a => ({ id: a.id, name: a.name }))]
    }
    return PRESET_AGENTS
  }, [dynamicAgents, t])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpenDropdown(null)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSelect = useCallback((type: SelectorType, value: string) => {
    // 处理 permission -> permissionMode 映射
    if (type === 'permission') {
      onChange({ ...config, permissionMode: value as PermissionMode })
    } else if (type === 'effort') {
      onChange({ ...config, effort: value as EffortLevel })
    } else {
      onChange({ ...config, [type]: value })
    }
    setOpenDropdown(null)
  }, [config, onChange])

  // 处理自定义输入确认
  const handleCustomInputConfirm = useCallback((type: SelectorType) => {
    if (!customInput || customInput.type !== type) return
    const value = customInput.value.trim()
    if (value) {
      handleSelect(type, value)
    }
    setCustomInput(null)
  }, [customInput, handleSelect])

  // 打开自定义输入模式
  const openCustomInput = useCallback((type: SelectorType) => {
    setCustomInput({ type, value: '' })
    setOpenDropdown(null)
    setTimeout(() => inputRef.current?.focus(), 0)
  }, [])

  const getAgentLabel = (agentId?: string) => {
    if (!agentId) return t('sessionConfig.noAgent')
    const agent = agentList.find(a => a.id === agentId)
    if (agent?.name) return agent.name
    // corpus/自定义专家兜底:catalog 映射 emoji+显示名（CompactSessionSelector 无 catalog 订阅，从 agentStore 读取）
    const agentState = useAgentStore.getState()
    const entry = agentState.catalog.find(c => c.slug === agentId)
      ?? agentState.customAgents.find(c => c.slug === agentId)
    if (entry) return `${'emoji' in entry && entry.emoji ? entry.emoji + ' ' : ''}${entry.name}`
    return agentId
  }

  const getModelLabel = (modelId?: string) => {
    if (!modelId) return t('sessionConfig.noModel')
    return PRESET_MODELS.find(m => m.id === modelId)?.name || modelId
  }

  const selectorLabels: Record<SelectorType, string> = {
    agent: t('sessionConfig.agent'),
    model: t('sessionConfig.model'),
    effort: t('sessionConfig.effort'),
    permission: t('sessionConfig.permission'),
    profile: t('sessionConfig.provider'),
  }

  return (
    <div ref={containerRef} className="flex items-center gap-0.5">
      {/* Agent */}
      <div className="relative">
        <button
          onClick={() => !disabled && setOpenDropdown(openDropdown === 'agent' ? null : 'agent')}
          disabled={disabled}
          className={clsx(
            'flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs transition-colors',
            disabled
              ? 'text-text-muted cursor-not-allowed'
              : 'text-text-tertiary hover:text-text-primary hover:bg-background-hover',
            openDropdown === 'agent' && 'bg-primary/10 text-primary'
          )}
        >
          <Bot size={12} />
          <span className="max-w-[48px] truncate">{getAgentLabel(config.agent)}</span>
          <ChevronDown size={10} className="opacity-50" />
        </button>
        {openDropdown === 'agent' && (
          <div className="absolute bottom-full left-0 mb-1 bg-background-elevated border border-border rounded-lg shadow-lg min-w-[140px] z-dropdown">
            {agentList.map(agent => (
              <button
                key={agent.id}
                onClick={() => handleSelect('agent', agent.id)}
                className={clsx(
                  'w-full px-2 py-1.5 text-left text-xs hover:bg-background-hover',
                  config.agent === agent.id && 'bg-primary/10 text-primary'
                )}
              >
                {agent.name}
              </button>
            ))}
            <div className="border-t border-border my-1" />
            <button
              onClick={() => openCustomInput('agent')}
              className="w-full px-2 py-1.5 text-left text-xs hover:bg-background-hover text-text-tertiary italic"
            >
              ✏️ {t('sessionConfig.custom')}
            </button>
          </div>
        )}
      </div>

      {/* Model */}
      <div className="relative">
        <button
          onClick={() => !disabled && setOpenDropdown(openDropdown === 'model' ? null : 'model')}
          disabled={disabled}
          className={clsx(
            'flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs transition-colors',
            disabled
              ? 'text-text-muted cursor-not-allowed'
              : 'text-text-tertiary hover:text-text-primary hover:bg-background-hover',
            openDropdown === 'model' && 'bg-primary/10 text-primary'
          )}
        >
          <Cpu size={12} />
          <span className="max-w-[48px] truncate">{getModelLabel(config.model)}</span>
          <ChevronDown size={10} className="opacity-50" />
        </button>
        {openDropdown === 'model' && (
          <div className="absolute bottom-full left-0 mb-1 bg-background-elevated border border-border rounded-lg shadow-lg min-w-[140px] z-dropdown">
            {PRESET_MODELS.map(model => (
              <button
                key={model.id}
                onClick={() => handleSelect('model', model.id)}
                className={clsx(
                  'w-full px-2 py-1.5 text-left text-xs hover:bg-background-hover',
                  config.model === model.id && 'bg-primary/10 text-primary'
                )}
              >
                {model.name}
              </button>
            ))}
            <div className="border-t border-border my-1" />
            <button
              onClick={() => openCustomInput('model')}
              className="w-full px-2 py-1.5 text-left text-xs hover:bg-background-hover text-text-tertiary italic"
            >
              ✏️ {t('sessionConfig.custom')}
            </button>
          </div>
        )}
      </div>

      {/* 自定义输入浮层 */}
      {customInput && (
        <div className="fixed inset-0 z-modal flex items-center justify-center bg-black/30">
          <div className="bg-background-elevated border border-border rounded-lg p-4 min-w-[280px] shadow-xl">
            <div className="text-xs text-text-secondary mb-2">
              {t('sessionConfig.customInputLabel', { type: selectorLabels[customInput.type] })}
            </div>
            <input
              ref={inputRef}
              type="text"
              value={customInput.value}
              onChange={(e) => setCustomInput({ ...customInput, value: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCustomInputConfirm(customInput.type)
                if (e.key === 'Escape') setCustomInput(null)
              }}
              className="w-full px-3 py-2 text-sm bg-background-surface border border-border rounded-lg outline-none focus:border-primary"
              placeholder={t('sessionConfig.customInputPlaceholder', { type: customInput.type })}
            />
            <div className="flex justify-end gap-2 mt-3">
              <button
                onClick={() => setCustomInput(null)}
                className="px-3 py-1.5 text-xs text-text-secondary hover:text-text-primary"
              >
                {t('sessionConfig.cancel')}
              </button>
              <button
                onClick={() => handleCustomInputConfirm(customInput.type)}
                className="px-3 py-1.5 text-xs bg-primary text-white rounded hover:bg-primary-hover"
              >
                {t('sessionConfig.confirm')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default SessionConfigSelector
