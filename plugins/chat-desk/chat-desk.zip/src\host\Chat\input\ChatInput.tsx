/**
 * 聊天输入组件 - 支持附件和工作区文件引用
 *
 * 支持功能:
 * - 文本输入
 * - 文件/图片附件 (粘贴、拖放、选择)
 * - 工作区引用 (@workspace)
 * - 文件引用 (@/path)
 */

import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { IconSend, IconStop, IconPaperclip } from '../../../shims/misc'
import { Sparkles, Wand2, Undo2, Redo2, Loader2, Check, X, Bot, Zap, ChevronDown } from 'lucide-react'
import { useWorkspaceStore, useToastStore, useConfigStore } from '@/stores'
import { useInputUIStore } from '@/stores/inputUIStore'
import { eventBus } from '@/services/eventBus'
import { useActiveSessionInputDraft, useActiveSessionActions, useActiveSessionWorkspace, useActiveSessionPromptSuggestion, useActiveSessionPromptOptimize, useActiveSessionPendingQueue, useSessionState } from '@/stores/conversationStore/useActiveSession'
import type { ConversationState } from '@/stores/conversationStore/types'
import {
  runPromptOptimize,
  cancelPromptOptimize,
  usePromptOptimizePreview,
  readStoredOptimizeConfig,
  storeOptimizeConfig,
  type PromptOptimizeConfig,
} from '@/services/promptOptimizeService'
import { useDebouncedCallback } from '@/hooks/useDebounce'
import { UnifiedSuggestion, type SuggestionItem, type ConversationSuggestion, type CapSuggestion } from './FileSuggestion'
import { AttachmentPreview } from './AttachmentPreview'
import { ContextBlockPreview } from './ContextBlockPreview'
import { AutoResizingTextarea } from './AutoResizingTextarea'
import { SnippetParamPanel } from './SnippetParamPanel'
import { PendingBriefingCard } from '../compact-handoff/PendingBriefingCard'
import { PendingQueueCard } from './PendingQueueCard'
import { InputBanner } from './InputBanner'
import { UiSlot } from './UiSlot'
import { useFileSearch } from '@/hooks/useFileSearch'
import { useSnippetStore } from '@/stores/snippetStore'
import { resolveTemplateVariables } from '@/services/workspaceReference'
import type { FileMatch } from '@/services/fileSearch'
import type { Workspace, EngineId } from '@/types'
import { getChatDisplayStyleVars } from '@/types'
import type { Attachment } from '@/types/attachment'
import type { ContextBlock } from '@/stores/conversationStore/types'
import { materializeContextBlocks, upsertContextBlock } from './contextBlockRegistry'
import { createLogger } from '@/utils/logger'
import { normalizeEngineId, getEngineFullName } from '@/utils/engineDisplay'
import { dialogStorageService } from '@/services/dialogStorage/service'
import { packForReference } from '@/services/conversationPackager'
import type { PromptSnippet } from '@/types/promptSnippet'
import type { SkillItem } from '@/types/skill'
import { McpServerItem } from './FileSuggestion'
import { useSkillStore } from '@/stores/skillStore'
import { useCliInfoStore } from '@/stores/cliInfoStore'
import { useActiveSessionId } from '@/stores/conversationStore/sessionStoreManager'
import { resolveSessionEngine } from '@/stores/conversationStore/conversationStoreUtils'
import { useModelProfileStore } from '@/stores/modelProfileStore'
import { isProfileForEngine } from '@/types/modelProfile'
import type { PromptOptimizeMode, OptimizeDirection } from '@/stores/conversationStore/types'
import {
  getCliCommandSuggestions,
  matchBlockedCliCommand,
  type CliCommandSuggestion,
} from '@/services/cliSlashCommands'
import { tryHandleSlashCommand } from './chatCommandRouter'
import { buildCapReferenceBlock, matchCaps, parseCapSlashCommand } from '@/services/capSlashCommand'
import { useCapCatalogStore } from '@/stores/capCatalogStore'
import {
  appendPromptHistoryEntry,
  arePromptHistoryEntriesEqual,
  navigatePromptHistory,
} from './promptHistory'
import {
  persistPromptHistoryEntries,
  readPromptHistoryEntries,
} from '@/services/promptHistoryService'
import { useAgentStore } from '@/stores/agentStore'
import { pluginRegistry, listEnabledPluginMcpServers } from '@/plugin-system'
import { usePluginStore } from '@/stores/pluginStore'
import {
  createAttachment,
  validateAttachment,
  validateAttachments,
  isImageType,
  ATTACHMENT_LIMITS,
} from '@/types/attachment'

const log = createLogger('ChatInput')

/** 提示词优化可选引擎（与 CommitInput 的引擎浮层保持一致） */
const OPTIMIZE_ENGINE_OPTIONS: Array<{ id: EngineId; label: string; Icon: typeof Bot }> = [
  { id: 'claude-code', label: 'Claude', Icon: Bot },
  { id: 'simple-ai', label: 'Simple', Icon: Zap },
]

/** 提示词优化模式选项（标签/提示语走 i18n） */
const OPTIMIZE_MODE_OPTIONS: Array<{
  key: PromptOptimizeMode
  label: string
  hint: string
  costHint?: string
  Icon: typeof Zap
}> = [
  { key: 'quick', label: 'promptOptimize.modeQuick', hint: 'promptOptimize.modeQuickHint', Icon: Zap },
  { key: 'deep', label: 'promptOptimize.modeDeep', hint: 'promptOptimize.modeDeepHint', Icon: Sparkles, costHint: 'promptOptimize.modeDeepCost' },
]

/** 提示词优化方向选项（标签走 i18n） */
const OPTIMIZE_DIRECTION_OPTIONS: Array<{ key: OptimizeDirection; label: string }> = [
  { key: 'convergent', label: 'promptOptimize.dirConvergent' },
  { key: 'divergent', label: 'promptOptimize.dirDivergent' },
  { key: 'elaborate', label: 'promptOptimize.dirElaborate' },
  { key: 'structured', label: 'promptOptimize.dirStructured' },
  { key: 'custom', label: 'promptOptimize.dirCustom' },
]

/** 提示词优化迭代轮次选项 */
const OPTIMIZE_ITERATION_OPTIONS = [1, 2, 3, 4, 5] as const

/** 将引擎 id 映射到 Profile 过滤用的引擎类别 */
function toProfileEngine(engineId: string): string {
  const e = normalizeEngineId(engineId)
  // 已知引擎映射到其别名，插件引擎直接透传
  return e === 'simple-ai' ? 'simple-ai' : e === 'claude-code' ? 'claude' : e
}

export interface EditMode {
  messageId: string
  content: string
}

interface ChatInputProps {
  /** 返回 Promise<boolean> 时：false = 发送失败，prompt 历史提交事务据此回滚；
   *  火烧即忘（void/undefined）时视为已提交。 */
  onSend: (message: string, workspaceDir?: string, attachments?: Attachment[]) => Promise<boolean> | boolean | void
  disabled?: boolean
  isStreaming?: boolean
  onInterrupt?: () => void
  currentWorkDir?: string | null
  editMode?: EditMode | null
  onCancelEdit?: () => void
  onEditSend?: (messageId: string, newContent: string, workspaceDir?: string) => void
  /**
   * 嵌入式状态栏（会话配置选择器/语音区等）。
   * 渲染在底部工具栏中段（附件按钮和发送按钮之间）。
   * 不传则只显示附件 + 发送（极简场景）。
   */
  statusBarSlot?: React.ReactNode
}

export function ChatInput({
  onSend,
  disabled = false,
  isStreaming = false,
  onInterrupt,
  currentWorkDir: _currentWorkDir,
  editMode = null,
  onCancelEdit,
  onEditSend,
  statusBarSlot,
}: ChatInputProps) {
  const { t } = useTranslation('chat')
  const chatDisplay = useConfigStore((state) => state.config?.chatDisplay)
  const chatDisplayStyle = useMemo(() => getChatDisplayStyleVars(chatDisplay), [chatDisplay])
// 获取启用的 MCP Server（供 / 命令使用）
  const pluginStates = usePluginStore((state) => state.pluginStates)
  const enabledMcpServers = useMemo(() => {
    const pluginsById = new Map((pluginRegistry.listPlugins() as any[]).map((p: any) => [p.id, p]))
    return listEnabledPluginMcpServers(pluginStates)
      .map((server: any) => ({
        id: server.id,
        name: pluginsById.get(server.pluginId)?.name ?? server.id,
      }))
      .filter((s: any) => s.name)
  }, [pluginStates])

// 获取当前会话的工作区
  const currentWorkspace = useActiveSessionWorkspace()
  /** prompt 历史归属工作区：持久化 key 与隔离维度（按 workspace 隔离，避免跨项目串味） */
  const promptHistoryWorkspacePath = currentWorkspace?.path ?? null

  // 当前会话引擎：CLI 斜杠命令建议/拦截仅对 Claude Code 引擎生效
  const activeSessionId = useActiveSessionId()
  // 中断进行中标志：停止按钮的即时反馈态（按下后按钮禁用转圈直到 session_end，
  // 最长 5s 兜底）。此前按钮无任何状态变化，可反复点击且无「正在中断」提示（审计 5.11）。
  const isInterrupting = useSessionState(
    activeSessionId,
    useCallback((s: ConversationState) => s.isInterrupting ?? false, []),
    false
  )
  const defaultEngine = useConfigStore((state) => state.config?.defaultEngine)
  const isClaudeEngine = useMemo(
    () => resolveSessionEngine(activeSessionId ?? '', defaultEngine) === 'claude-code',
    [activeSessionId, defaultEngine]
  )

  /** 选中片段时的光标位置信息（用于局部替换） */
  const [snippetTriggerBefore, setSnippetTriggerBefore] = useState<{ before: string; cursor: number } | null>(null)
  // 使用 Store 中的输入草稿（用于会话切换同步）
  const inputDraft = useActiveSessionInputDraft()
  const promptSuggestion = useActiveSessionPromptSuggestion()
  const {
    updateInputDraft, setPromptSuggestion,
    undoPromptOptimize, redoPromptOptimize, applyPendingPromptOptimize,
    resetPromptOptimize, clearPromptOptimizeError,
    updateContextBlockNote,
    enqueuePending, sendPendingNow,
  } = useActiveSessionActions()
  const pendingQueue = useActiveSessionPendingQueue()

  // 提示词优化状态（per-session 版本栈）+ 优化会话流式预览
  const promptOptimize = useActiveSessionPromptOptimize()
  const optimizePreview = usePromptOptimizePreview(
    promptOptimize.status === 'running' ? promptOptimize.optimizeSessionId : null
  )
  const [optimizePickerOpen, setOptimizePickerOpen] = useState(false)
  const optimizePickerRef = useRef<HTMLDivElement>(null)
  const optimizeButtonRef = useRef<HTMLButtonElement>(null)

  // 本地 state（即时响应）
  const [localText, setLocalText] = useState('')
  const [localAttachments, setLocalAttachments] = useState<Attachment[]>([])
  const [localContextBlocks, setLocalContextBlocks] = useState<ContextBlock[]>([])
  const contextBlocksRef = useRef<ContextBlock[]>([])
  const [activeSnippet, setActiveSnippet] = useState<PromptSnippet | null>(null)

  // Prompt 历史（终端风格 ArrowUp 召回）
  // entries 统一为旧→新序；historyIndex=null 表示未进入浏览态。
  // 持久化走 cap.kv（promptHistoryService，per-workspace）；内存 ref 是浏览态事实源。
  const sentHistoryRef = useRef<string[]>([])
  const [historyIndex, setHistoryIndex] = useState<number | null>(null)

  // 按工作区加载历史（cap.kv）。代数号防过期加载覆盖：切工作区后早到的旧响应直接丢弃，
  // 不用超时掩盖；加载期间已发送的条目与历史表幂等合并（append 自动去重）。
  const promptHistoryLoadGenRef = useRef(0)
  useEffect(() => {
    const gen = ++promptHistoryLoadGenRef.current
    sentHistoryRef.current = []
    setHistoryIndex(null)
    let alive = true
    void readPromptHistoryEntries(promptHistoryWorkspacePath).then((loaded) => {
      if (!alive || gen !== promptHistoryLoadGenRef.current) return
      let merged = loaded
      for (const entry of sentHistoryRef.current) {
        merged = appendPromptHistoryEntry(merged, entry)
      }
      sentHistoryRef.current = merged
    })
    return () => {
      alive = false
    }
  }, [promptHistoryWorkspacePath])

  // 历史提交事务：成功返回且内容有变化才落库。失败（send 返回 false / 抛错）
  // 不入史，保证「按 ↑ 召回的一定是发出过的内容」。
  // 调用方不等待本事务完成即可做 UI 清理（回滚只影响浏览态事实源，无需阻塞输入框）。
  const commitPromptHistory = useCallback(
    async (text: string, send: () => Promise<boolean> | boolean | void) => {
      const trimmed = text.trim()
      if (!trimmed) return
      const before = sentHistoryRef.current
      const appended = appendPromptHistoryEntry(before, trimmed)
      let ok: boolean
      try {
        ok = (await send()) !== false
      } catch {
        ok = false
      }
      if (!ok) return
      if (arePromptHistoryEntriesEqual(before, appended)) return // 与最后一条相同：无变化不写
      sentHistoryRef.current = appended
      void persistPromptHistoryEntries(promptHistoryWorkspacePath, appended)
    },
    [promptHistoryWorkspacePath]
  )

  // 编辑模式同步：进入编辑模式时填入消息内容
  useEffect(() => {
    if (editMode) {
      setLocalText(editMode.content)
      setHistoryIndex(null)
      // 聚焦输入框
      setTimeout(() => textareaRef.current?.focus(), 0)
    }
  }, [editMode])

  // 创建防抖的持久化函数（300ms 延迟）
  // 通过 ref 读取最新 contextBlocks，避免闭包过期；contextBlocks 与附件平行持久化。
  const { debounced: debouncedPersistDraft, cancel: cancelPersistDraft } = useDebouncedCallback(
    (text: string, attachments: Attachment[]) => {
      updateInputDraft({ text, attachments, contextBlocks: contextBlocksRef.current })
    },
    300
  )

  // 批 6（审计 5.3 草稿串号）：会话切换时取消挂起的防抖持久化——
  // 300ms 窗口内 A 会话的草稿回调会在切到 B 后才执行，updateInputDraft
  // 按调用时刻的活跃会话落盘，A 的草稿写进 B 且 A 丢最后一段输入。
  // 取消后 A 的草稿停留在 A 的最后一次已落盘状态（≤300ms 损失，可接受）。
  useEffect(() => {
    return () => {
      cancelPersistDraft()
    }
  }, [activeSessionId, cancelPersistDraft])

  // 会话切换时同步 Store 草稿到本地 state（只在 sessionId 变化时执行）
  // inputDraft 在 sessionId 变化时才会更新，无需添加依赖
  useEffect(() => {
    log.info('[TCB] ChatInput 同步 effect 触发', {
      textLen: inputDraft.text?.length,
      attachLen: inputDraft.attachments?.length,
      blockLen: inputDraft.contextBlocks?.length ?? 0,
    })
    setLocalText(inputDraft.text)
    setLocalAttachments(inputDraft.attachments)
    const blocks = inputDraft.contextBlocks ?? []
    contextBlocksRef.current = blocks
    setLocalContextBlocks(blocks)
  }, [inputDraft])

  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // 监听全局聚焦请求（快捷键新建会话等场景触发，见 useWindowManager）
  useEffect(() => {
    return eventBus.on('chat:focus-input', () => {
      // 推迟一拍，确保会话切换引起的重渲染完成后再聚焦
      setTimeout(() => textareaRef.current?.focus(), 0)
    })
  }, [])

  // 从本地 state 获取当前值
  const value = localText
  const attachments = localAttachments

  // 统一建议状态
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [suggestionItems, setSuggestionItems] = useState<SuggestionItem[]>([])
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [suggestionPosition, setSuggestionPosition] = useState({ top: 0, left: 0 })
  const [fileWorkspace, setFileWorkspace] = useState<Workspace | null>(null)
  // @对话 引用：历史会话建议
  const [conversationMatches, setConversationMatches] = useState<ConversationSuggestion[]>([])
  const [conversationMode, setConversationMode] = useState(false)

  const { currentWorkspaceId, workspaces } = useWorkspaceStore()
  const { fileMatches, searchFiles, clearResults } = useFileSearch()

  // 加载历史会话列表（全引擎聚合：后端统一归档所有引擎会话）供 @对话 引用
  const searchConversations = useCallback(async (query: string) => {
    try {
      const result = await dialogStorageService.listConversations({ pageSize: 50 })
      const q = query.toLowerCase().trim()
      const items: ConversationSuggestion[] = result.items
        .filter(m => !q
          || (m.title ?? '').toLowerCase().includes(q)
          || (m.firstUserText ?? '').toLowerCase().includes(q))
        .map(m => ({
          externalId: m.externalId,
          title: m.title || '(无标题)',
          engineId: normalizeEngineId(m.engineId),
          messageCount: m.messageCount,
          updatedAt: m.updatedAt,
          // 源对话工作区：落盘优先用它，避免当前会话无工作区时无法导出
          workspacePath: m.workspacePath ?? null,
        }))
      setConversationMatches(items)
    } catch (e) {
      log.warn('加载历史对话列表失败', { error: String(e) })
      setConversationMatches([])
    }
  }, [])
  const {
    setInputLength,
    setAttachmentCount,
    setSuggestionMode,
  } = useInputUIStore()

  // 同步字数到 store
  useEffect(() => {
    setInputLength(value.length)
  }, [value.length, setInputLength])

  // 同步附件数量到 store
  useEffect(() => {
    setAttachmentCount(attachments.length)
  }, [attachments.length, setAttachmentCount])

  // 同步建议模式到 store
  useEffect(() => {
    setSuggestionMode(showSuggestions ? 'file' : null)
  }, [showSuggestions, setSuggestionMode])

  // 智能定位建议框
  const calculateSuggestionPosition = useCallback(() => {
    const textarea = textareaRef.current
    if (!textarea) return { top: 0, left: 0 }

    const rect = textarea.getBoundingClientRect()
    const spaceBelow = window.innerHeight - rect.bottom
    // 建议框高度可被 AI 经 cap.ui.input 即时调节（默认 320）
    const suggestionHeight = useInputUIStore.getState().floating.height
    const shouldShowAbove = spaceBelow < suggestionHeight

    const left = Math.max(8, Math.min(rect.left, window.innerWidth - 300))

    return {
      top: shouldShowAbove ? rect.top - suggestionHeight - 8 : rect.bottom + 8,
      left,
    }
  }, [])

  // 添加附件
  const addAttachment = useCallback(async (file: File, source: 'paste' | 'drag' | 'select') => {
    // 验证
    const validation = validateAttachment(file)
    if (!validation.valid) {
      log.warn('Attachment validation failed', { error: validation.error })
      useToastStore.getState().error(validation.error!)
      return
    }

    // 创建附件
    const attachment = await createAttachment(file, source)
    const newAttachments = [...attachments, attachment]
    const totalValidation = validateAttachments(newAttachments)
    if (!totalValidation.valid) {
      log.warn('Total attachment validation failed', { error: totalValidation.error })
      useToastStore.getState().error(totalValidation.error!)
      return
    }
    // 立即更新本地 state
    setLocalAttachments(newAttachments)
    // 持久化到 Store
    debouncedPersistDraft(value, newAttachments)
  }, [attachments, value, debouncedPersistDraft])

  // 移除附件
  const removeAttachment = useCallback((id: string) => {
    const newAttachments = attachments.filter(a => a.id !== id)
    // 立即更新本地 state
    setLocalAttachments(newAttachments)
    // 持久化到 Store
    debouncedPersistDraft(value, newAttachments)
  }, [attachments, value, debouncedPersistDraft])

  // ── 上下文块（如浏览器圈选区域）──
  // 由外部组件经 addContextBlock 写入，这里负责移除与显示。
  const removeContextBlock = useCallback((id: string) => {
    const blocks = contextBlocksRef.current.filter((b) => b.id !== id)
    contextBlocksRef.current = blocks
    setLocalContextBlocks(blocks)
    // 整体替换 draft，保留 text/attachments
    updateInputDraft({ text: value, attachments: localAttachments, contextBlocks: blocks })
  }, [value, localAttachments, updateInputDraft])

  // 处理粘贴
  const handlePaste = useCallback(async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items
    if (!items) return

    let hasFiles = false

    for (const item of Array.from(items)) {
      // 图片
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile()
        if (file) {
          await addAttachment(file, 'paste')
          hasFiles = true
        }
      }
      // 文件
      else if (item.kind === 'file') {
        const file = item.getAsFile()
        if (file && !isImageType(file.type)) {
          await addAttachment(file, 'paste')
          hasFiles = true
        }
      }
    }

    if (hasFiles) {
      e.preventDefault()
    }
  }, [addAttachment])

  // 处理拖放
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const files = Array.from(e.dataTransfer?.files || [])
    for (const file of files) {
      await addAttachment(file, 'drag')
    }
  }, [addAttachment])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  // 处理文件选择
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    for (const file of files) {
      await addAttachment(file, 'select')
    }
    // 清空 input 以便再次选择同一文件
    e.target.value = ''
  }, [addAttachment])

  // 打开文件选择
  const openFileDialog = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  // ===== 提示词优化 =====
  const optimizeRunning = promptOptimize.status === 'running'
  // 以 / 开头的输入会被解析为命令，优化会破坏命令语义
  const isSlashCommandInput = value.trimStart().startsWith('/')

  // 点击外部关闭优化引擎浮层
  useEffect(() => {
    if (!optimizePickerOpen) return
    const handleClickOutside = (e: MouseEvent) => {
      if (
        optimizePickerRef.current && !optimizePickerRef.current.contains(e.target as Node) &&
        optimizeButtonRef.current && !optimizeButtonRef.current.contains(e.target as Node)
      ) {
        setOptimizePickerOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [optimizePickerOpen])

  /** 版本栈操作前把本地文本同步进 store 草稿（消除 300ms 防抖差，保证手改判定/冲突检测基线准确） */
  const syncDraftNow = useCallback(() => {
    cancelPersistDraft()
    updateInputDraft({ text: value, attachments, contextBlocks: contextBlocksRef.current })
  }, [cancelPersistDraft, updateInputDraft, value, attachments])

  /** 提示词优化配置：引擎 + 模式 + Profile + 模型（持久化到 localStorage） */
  const profiles = useModelProfileStore((s: any) => s.profiles) as any[]
  const [optimizeEngine, setOptimizeEngine] = useState<EngineId>(
    () => readStoredOptimizeConfig(normalizeEngineId(defaultEngine)).engineId,
  )
  const [optimizeMode, setOptimizeMode] = useState<PromptOptimizeMode>('quick')
  const [optimizePrivacyNotice, setOptimizePrivacyNotice] = useState(false)
  const [optimizeProfileId, setOptimizeProfileId] = useState('')
  const [optimizeModel, setOptimizeModel] = useState('')
  const [showOptimizeAdvanced, setShowOptimizeAdvanced] = useState(false)
  // 优化方向（缺省 structured = 等价现有默认行为）
  const [optimizeDirection, setOptimizeDirection] = useState<OptimizeDirection>(
    () => readStoredOptimizeConfig(normalizeEngineId(defaultEngine)).direction ?? 'structured',
  )
  // 自定义方向指令（direction === 'custom' 时使用）
  const [optimizeCustomText, setOptimizeCustomText] = useState<string>(
    () => readStoredOptimizeConfig(normalizeEngineId(defaultEngine)).customDirectionText ?? '',
  )
  // 迭代轮次（缺省 1 = 单轮）
  const [optimizeIterations, setOptimizeIterations] = useState<number>(
    () => readStoredOptimizeConfig(normalizeEngineId(defaultEngine)).iterations ?? 1,
  )

  // 不要求关联工作区：优化会话可无工作区运行（free），与无工作区聊天一致
  // 注意：必须在 optimizeDirection / optimizeCustomText 等 useState 声明之后计算，
  // 否则 const 未初始化即被引用，触发 TDZ ReferenceError。
  const canOptimize = Boolean(
    value.trim() && !optimizeRunning && !editMode && !isSlashCommandInput && !disabled && activeSessionId
      && (optimizeDirection !== 'custom' || optimizeCustomText.trim() !== '')
  )

  // 切换引擎时清空已选的 Profile / 模型
  const setOptimizeEngineAndReset = useCallback(
    (id: EngineId) => {
      setOptimizeEngine(id)
      setOptimizeProfileId('')
      setOptimizeModel('')
    },
    [],
  )

  // 引擎 → Profile 列表（排除官方 API，Profile 用空字符串代表官方）
  const optimizeProfileOptions = useMemo(
    () =>
      profiles
        .filter((p) => isProfileForEngine(p, toProfileEngine(optimizeEngine)))
        .map((p) => ({ value: p.id, label: p.name, description: p.baseUrl })),
    [profiles, optimizeEngine],
  )
  // 模型列表：走 Profile 的 modelOptions，保留当前已选
  const optimizeModelOptions = useMemo(() => {
    const profile = profiles.find((p) => p.id === optimizeProfileId)
    const base = profile
      ? (profile.modelOptions?.length ? profile.modelOptions : [profile.model]).filter(Boolean)
      : []
    const set = new Set(base)
    if (optimizeModel) set.add(optimizeModel)
    return [...set].map((m: any) => ({ value: m as string, label: m as string }))
  }, [profiles, optimizeProfileId, optimizeModel])

  // 持久化优化配置
  const persistOptimizeConfig = useCallback(
    (cfg: PromptOptimizeConfig) => storeOptimizeConfig(cfg),
    [],
  )

  const handleOptimizeWithConfig = useCallback(() => {
    if (optimizeMode === 'deep' && !localStorage.getItem('polaris.promptOptimize.privacyNoticeSeen')) {
      setOptimizePrivacyNotice(true)
      return
    }
    // custom 方向必须填指令，空则阻断执行
    if (optimizeDirection === 'custom' && !optimizeCustomText.trim()) {
      return
    }
    setOptimizePickerOpen(false)
    if (!canOptimize || !activeSessionId) return
    const cfg: PromptOptimizeConfig = {
      engineId: optimizeEngine,
      mode: optimizeMode,
      modelProfileId: optimizeProfileId || undefined,
      model: optimizeModel || undefined,
      direction: optimizeDirection,
      customDirectionText: optimizeDirection === 'custom' ? optimizeCustomText.trim() : undefined,
      iterations: optimizeIterations,
    }
    persistOptimizeConfig(cfg)
    syncDraftNow()
    // 工作区解析与发送消息对齐：会话关联工作区 → 全局当前工作区 → 无（free 优化会话）
    const workspace = currentWorkspace ?? workspaces.find((w) => w.id === currentWorkspaceId) ?? null
    void runPromptOptimize({
      sourceSessionId: activeSessionId,
      workspaceId: workspace?.id,
      workspacePath: workspace?.path,
      engineId: optimizeEngine,
      mode: optimizeMode,
      modelProfileId: cfg.modelProfileId,
      model: cfg.model,
      direction: optimizeDirection,
      customDirectionText: cfg.customDirectionText,
      iterations: optimizeIterations,
      sourceText: value,
    })
  }, [
    canOptimize, activeSessionId, optimizeEngine, optimizeMode, optimizeProfileId, optimizeModel,
    optimizeDirection, optimizeCustomText, optimizeIterations,
    value, syncDraftNow, currentWorkspace, workspaces, currentWorkspaceId, persistOptimizeConfig,
  ])

  const handleCancelOptimize = useCallback(() => {
    if (activeSessionId) cancelPromptOptimize(activeSessionId)
  }, [activeSessionId])

  const handleUndoOptimize = useCallback(() => {
    syncDraftNow()
    undoPromptOptimize()
  }, [syncDraftNow, undoPromptOptimize])

  const handleRedoOptimize = useCallback(() => {
    syncDraftNow()
    redoPromptOptimize()
  }, [syncDraftNow, redoPromptOptimize])

  const handleApplyOptimizeResult = useCallback(() => {
    syncDraftNow()
    applyPendingPromptOptimize()
  }, [syncDraftNow, applyPendingPromptOptimize])

  // 版本控件可见性/可用性
  const optimizeCursorText = promptOptimize.history[promptOptimize.cursor]?.text ?? ''
  const showVersionControls = promptOptimize.status === 'idle' && promptOptimize.history.length > 1
  const canUndoVersion = promptOptimize.status === 'idle' && promptOptimize.history.length > 0
    && (promptOptimize.cursor > 0 || value !== optimizeCursorText)
  // redo 需当前文本与栈内当前版本一致（手改后禁用，防覆盖丢失）
  const canRedoVersion = promptOptimize.status === 'idle'
    && promptOptimize.cursor < promptOptimize.history.length - 1
    && value === optimizeCursorText

  const optimizeTitle = useMemo(() => {
    if (optimizeRunning) return t('promptOptimize.running')
    if (editMode) return t('promptOptimize.editModeBlocked')
    if (isSlashCommandInput) return t('promptOptimize.slashBlocked')
    if (!value.trim()) return t('promptOptimize.emptyInput')
    return t('promptOptimize.buttonTitle')
  }, [optimizeRunning, editMode, isSlashCommandInput, value, t])

  // 构建统一建议列表
  const buildSuggestionItems = useCallback((
    workspaceList: Workspace[],
    fileList: FileMatch[],
    filterQuery?: string
  ): SuggestionItem[] => {
    const items: SuggestionItem[] = []

    // 添加工作区
    const filteredWorkspaces = filterQuery
      ? workspaceList.filter(w => w.name.toLowerCase().includes(filterQuery.toLowerCase()))
      : workspaceList
    filteredWorkspaces.forEach(w => {
      items.push({ type: 'workspace', data: w })
    })

    // 添加文件
    fileList.forEach(f => {
      items.push({ type: 'file', data: f })
    })

    return items
  }, [])

  // 检测触发符
  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value
    // 立即更新本地 state（即时响应）
    setLocalText(newValue)
    // 用户手动编辑时退出历史浏览模式
    if (historyIndex !== null) setHistoryIndex(null)
    // 防抖持久化到 Store
    debouncedPersistDraft(newValue, attachments)

    // 非 @对话 分支默认退出历史对话模式（@对话 分支内会重新置 true）
    setConversationMode(false)

    const textarea = textareaRef.current
    if (!textarea || !containerRef.current) return

    const cursorPosition = textarea.selectionStart
    const textBeforeCursor = newValue.slice(0, cursorPosition)

    // === -1. Polaris 专家命令参数补全（/agent、/dispatch 的 slug、/nexus 的场景） ===
    const agentArgMatch = textBeforeCursor.match(/^\/(agent|dispatch|nexus)\s+(\S*)$/)
    if (agentArgMatch) {
      const cmdName = agentArgMatch[1]
      const argQuery = agentArgMatch[2].toLowerCase()
      const agentState = useAgentStore.getState()
      let agentItems: SuggestionItem[] = []
      if (cmdName === 'nexus') {
        agentItems = agentState.rosters
          .filter(r => r.slug.includes(argQuery) || r.title.toLowerCase().includes(argQuery))
          .map(r => ({
            type: 'agent' as const,
            data: {
              slug: r.slug,
              name: r.title || r.slug,
              description: `${r.mode} · ${r.duration} · ${r.summary}`,
              emoji: '🚀',
              insertText: `/nexus ${r.slug} `,
            },
          }))
      } else {
        const pool = [
          ...agentState.customAgents.map(c => ({
            slug: c.slug, name: c.name, description: `自定义 · ${c.description}`, emoji: c.emoji ?? '🧩',
          })),
          ...agentState.catalog.map(c => ({
            slug: c.slug, name: c.name, description: c.description, emoji: c.emoji,
          })),
        ]
        agentItems = pool
          .filter(a =>
            a.slug.toLowerCase().includes(argQuery)
            || a.name.toLowerCase().includes(argQuery)
            || a.description.toLowerCase().includes(argQuery))
          .slice(0, 12)
          .map(a => ({
            type: 'agent' as const,
            data: { ...a, insertText: `/${cmdName} ${a.slug} ` },
          }))
      }
      if (agentItems.length > 0) {
        setSuggestionItems(agentItems)
        setSelectedIndex(0)
        setShowSuggestions(true)
        const position = calculateSuggestionPosition()
        setSuggestionPosition({ top: position.top, left: position.left })
        return
      }
      setShowSuggestions(false)
      setSuggestionItems([])
      return
    }

    // === -0.5 /cap 参数补全（消息首，cap id / 中文短名过滤） ===
    const capArgMatch = textBeforeCursor.match(/^\/cap\s+(\S*)$/)
    if (capArgMatch) {
      // 懒加载目录（会话级缓存）；未就绪时本次不弹建议，下一次按键即出现
      void useCapCatalogStore.getState().ensure()
      const caps = useCapCatalogStore.getState().caps
      const capItems: SuggestionItem[] = matchCaps(caps, capArgMatch[1])
        .slice(0, 12)
        .map(c => ({
          type: 'cap' as const,
          data: { id: c.id, name: `（${c.name}）`, summary: c.summary } as CapSuggestion,
        }))
      if (capItems.length > 0) {
        setSuggestionItems(capItems)
        setSelectedIndex(0)
        setShowSuggestions(true)
        const position = calculateSuggestionPosition()
        setSuggestionPosition({ top: position.top, left: position.left })
        return
      }
      setShowSuggestions(false)
      setSuggestionItems([])
      return
    }

    // === 0. / 命令触发检测（任意位置，必须在所有 @ 检测之前） ===
    // 规则：光标前最后一个片段以 / 开头，且 / 前是词边界（行首、空格、或标点符号）
    // 排除 @/path 中的 /（@ 后面的 / 不触发）
    const slashMatch = textBeforeCursor.match(/(^|[\s(,;]|\[)\/(\S*)$/)
    if (slashMatch && !textBeforeCursor.match(/@\/[^\s]*$/)) {
      const query = slashMatch[2].toLowerCase()
      const snippets = useSnippetStore.getState().snippets
      const skills = useSkillStore.getState().skills
      // /cap 命令数据源预载（键入 /c.. 即开始，发送时缓存通常已就绪）
      if ('cap'.startsWith(query) || query.startsWith('cap')) {
        void useCapCatalogStore.getState().ensure()
      }

      // CLI 命令建议：仅 Claude 引擎、且 / 是消息首字符时提供
      // （与 CLI 语义对齐：只有整条消息以 / 开头才会被解析为命令）
      const isMessageStart = slashMatch.index === 0 && slashMatch[1] === ''
      const cliCommandItems: SuggestionItem[] = isClaudeEngine && isMessageStart
        ? getCliCommandSuggestions(
            query,
            useCliInfoStore.getState().slashCommands,
            new Set(skills.flatMap(s => [s.id, s.name])),
          ).map(c => ({ type: 'cli-command' as const, data: c }))
        : []

      const matched: SuggestionItem[] = [
        // 快捷片段
        ...snippets
          .filter(s => s.enabled && (
            s.name.toLowerCase().includes(query)
            || (s.description?.toLowerCase().includes(query) ?? false)
          ))
          .map(s => ({ type: 'snippet' as const, data: s })),
        // CLI 命令（顺序须与 UnifiedSuggestion 分组渲染顺序一致，保证键盘导航连贯）
        ...cliCommandItems,
        // Skill
        ...skills
          .filter(s => (
            s.id.toLowerCase().includes(query)
            || s.name.toLowerCase().includes(query)
            || (s.description?.toLowerCase().includes(query) ?? false)
          ))
          .map(s => ({ type: 'skill' as const, data: s })),
        // MCP 插件
        ...enabledMcpServers
          .filter(m => (
            m.id.toLowerCase().includes(query)
            || m.name.toLowerCase().includes(query)
            || m.id.toLowerCase().replace(/^polaris[-_.]/, '').includes(query)
          ))
          .map(m => ({ type: 'mcp' as const, data: m })),
        // /cap 命令入口（仅消息首；参数补全在 /cap <空格> 后由独立分支接管）
        ...(isMessageStart && 'cap'.startsWith(query)
          ? [{
              type: 'cap' as const,
              data: {
                id: '',
                name: '（命令）',
                summary: '注入 cap 能力协议速查——空格后可按 id / 中文短名过滤',
              } as CapSuggestion,
            }]
          : []),
      ]

      if (matched.length > 0) {
        setSuggestionItems(matched)
        setSelectedIndex(0)
        setShowSuggestions(true)
        const position = calculateSuggestionPosition()
        setSuggestionPosition({ top: position.top, left: position.left })
        return // 不继续走 @ 检测
      }
    }

    // 1. 检测跨工作区引用 (@/path)
    const crossWorkspaceMatch = textBeforeCursor.match(/@\/([^\s]*)$/)
    if (crossWorkspaceMatch) {
      const pathPart = crossWorkspaceMatch[1] || ''
      const items = buildSuggestionItems(workspaces, [], pathPart)
      setSuggestionItems(items)
      setSelectedIndex(0)
      setShowSuggestions(items.length > 0)
      setFileWorkspace(null)

      const position = calculateSuggestionPosition()
      setSuggestionPosition({ top: position.top, left: position.left })
      return
    }

    // 1.5 检测 @对话 引用（历史会话 → packToSummary 落盘 → 转 @path 注入）
    //     必须在 partialMatch（会匹配中文「对话」）之前拦截
    const conversationMatch = textBeforeCursor.match(/@对话(?:\s+(\S*))?$/)
    if (conversationMatch) {
      setConversationMode(true)
      setFileWorkspace(null)
      setSuggestionItems([])
      setShowSuggestions(true)
      setSelectedIndex(0)
      void searchConversations(conversationMatch[1] ?? '')

      const position = calculateSuggestionPosition()
      setSuggestionPosition({ top: position.top, left: position.left })
      return
    }

    // 1.6 @专家 提及：在消息任意位置 `@专家<查询>` 弹出专家列表，选中后注入 `@专家:slug` 文本
    //      必须用专属中文前缀以避免与 @workspace / @path 通配分支冲突
    //      必须在 partialMatch（会匹配中文「专家」）之前拦截
    const agentMentionMatch = textBeforeCursor.match(/@专家(?:\s+(\S*))?$/)
    if (agentMentionMatch) {
      setConversationMode(false)
      setFileWorkspace(null)
      const query = (agentMentionMatch[1] ?? '').toLowerCase()
      const agentState = useAgentStore.getState()
      const pool = [
        ...agentState.customAgents.map(c => ({
          slug: c.slug, name: c.name, description: `自定义 · ${c.description}`, emoji: c.emoji ?? '🧩',
        })),
        ...agentState.catalog.map(c => ({
          slug: c.slug, name: c.name, description: c.description, emoji: c.emoji,
        })),
      ]
      const matched = pool
        .filter(a =>
          query === '' ||
          a.slug.toLowerCase().includes(query) ||
          a.name.toLowerCase().includes(query) ||
          a.description.toLowerCase().includes(query)
        )
        .slice(0, 12)
      const agentItems: SuggestionItem[] = matched.map(a => ({
        type: 'agent-mention' as const,
        data: {
          slug: a.slug,
          name: a.name,
          description: a.description,
          emoji: a.emoji,
          insertText: `@专家:${a.slug} `,
        },
      }))
      setSuggestionItems(agentItems)
      setSelectedIndex(0)
      setShowSuggestions(agentItems.length > 0)

      const position = calculateSuggestionPosition()
      setSuggestionPosition({ top: position.top, left: position.left })
      return
    }

    // 2. 检测 @workspace:path 语法（已指定工作区）
    const workspaceMatch = textBeforeCursor.match(/@([\w\u4e00-\u9fa5-]+):([^\s]*)$/)
    if (workspaceMatch) {
      const workspaceName = workspaceMatch[1]
      const pathPart = workspaceMatch[2] || ''

      const matchedWorkspace = workspaces.find(w =>
        w.name.toLowerCase() === workspaceName.toLowerCase()
      )

      if (matchedWorkspace) {
        // 找到匹配的工作区，显示该工作区的文件
        setFileWorkspace(matchedWorkspace)
        searchFiles(pathPart, matchedWorkspace)
      } else {
        // 未找到工作区，显示工作区列表
        const items = buildSuggestionItems(workspaces, [], workspaceName)
        setSuggestionItems(items)
        setSelectedIndex(0)
        setShowSuggestions(items.length > 0)
        setFileWorkspace(null)
      }

      const position = calculateSuggestionPosition()
      setSuggestionPosition({ top: position.top, left: position.left })
      return
    }

    // 3. 检测用户正在输入工作区名或文件路径（无冒号）
    const partialMatch = textBeforeCursor.match(/@([\w\u4e00-\u9fa5-\u4e00-\u9fa5/.\\_-]*)$/)
    if (partialMatch) {
      const query = partialMatch[1]

      // 如果包含路径分隔符，说明是在输入当前工作区的文件路径
      if (query.includes('/') || query.includes('\\') || query.includes('.')) {
        setShowSuggestions(false)
        setSuggestionItems([])
        setFileWorkspace(null)
        searchFiles(query)

        const position = calculateSuggestionPosition()
        setSuggestionPosition({ top: position.top, left: position.left })
        return
      }

      // 同时显示工作区和当前工作区文件建议
      if (query.length > 0) {
        const items = buildSuggestionItems(workspaces, [], query)
        setSuggestionItems(items)
        setSelectedIndex(0)
        // 始终显示建议浮窗，因为文件搜索可能返回结果
        setShowSuggestions(true)
        setFileWorkspace(null)
        // 同时搜索当前工作区文件
        searchFiles(query)

        const position = calculateSuggestionPosition()
        setSuggestionPosition({ top: position.top, left: position.left })
        return
      }
    }

    // 4. 检测单独的 @ 符号（显示工作区列表和当前工作区文件提示）
    const atOnlyMatch = textBeforeCursor.match(/@$/)
    if (atOnlyMatch) {
      const items = buildSuggestionItems(workspaces, [])
      setSuggestionItems(items)
      setSelectedIndex(0)
      setShowSuggestions(items.length > 0)
      setFileWorkspace(null)
      // 搜索当前工作区文件（空查询显示所有）
      searchFiles('')

      const position = calculateSuggestionPosition()
      setSuggestionPosition({ top: position.top, left: position.left })
      return
    }

    // 隐藏所有建议
    setShowSuggestions(false)
    setSuggestionItems([])
    clearResults()
  }, [workspaces, searchFiles, clearResults, calculateSuggestionPosition, buildSuggestionItems, attachments, debouncedPersistDraft, historyIndex, searchConversations, enabledMcpServers, isClaudeEngine])

  // 当 fileMatches 更新时，合并到 suggestionItems（@对话 模式下不合并文件）
  useEffect(() => {
    if (conversationMode) return
    // 重新构建建议列表，包含工作区和文件
    const workspaceItems = suggestionItems.filter(i => i.type === 'workspace')
    const fileItems: SuggestionItem[] = fileMatches.map(f => ({ type: 'file' as const, data: f }))
    const newItems = [...workspaceItems, ...fileItems]

    if (newItems.length > 0) {
      setSuggestionItems(newItems)
      // 如果有结果但当前未显示，则显示建议浮窗
      if (!showSuggestions) {
        setShowSuggestions(true)
        setSelectedIndex(0)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- showSuggestions/suggestionItems toggles visibility only
  }, [fileMatches])

  // @对话 模式：历史会话列表加载后，合并到 suggestionItems
  useEffect(() => {
    if (!conversationMode) return
    const items: SuggestionItem[] = conversationMatches.map(c => ({ type: 'conversation' as const, data: c }))
    setSuggestionItems(items)
    setShowSuggestions(items.length > 0)
    setSelectedIndex(0)
  }, [conversationMatches, conversationMode])

  // 解析自动变量（提前定义，供 selectSuggestion 使用）
  const resolveSnippetAutoVars = useCallback((content: string): string => {
    return resolveTemplateVariables(content, {
      workspaceName: currentWorkspace?.name ?? '',
      workspacePath: currentWorkspace?.path ?? '',
      contextWorkspaces: [],
    })
  }, [currentWorkspace])

  // 选择建议项
  const selectSuggestion = useCallback((item: SuggestionItem) => {
    const textarea = textareaRef.current
    if (!textarea) return

    const cursorPosition = textarea.selectionStart
    const textBeforeCursor = value.slice(0, cursorPosition)
    const textAfterCursor = value.slice(cursorPosition)

    const replaceSlashToken = (replacement: string): string => {
      const slashToken = textBeforeCursor.match(/(^|[\s(,;]|\[)\/\S*$/)
      if (!slashToken || slashToken.index === undefined) return value
      const tokenStart = slashToken.index + slashToken[1].length
      return textBeforeCursor.slice(0, tokenStart) + replacement + textAfterCursor
    }

    const applySlashReplacement = (replacement: string) => {
      const replaced = replaceSlashToken(replacement)
      setLocalText(replaced)
      updateInputDraft({ text: replaced, attachments, contextBlocks: contextBlocksRef.current })
      setShowSuggestions(false)
      setSuggestionItems([])
      setTimeout(() => {
        textarea.focus()
        const cursor = replaced.length - textAfterCursor.length
        textarea.setSelectionRange(cursor, cursor)
      }, 0)
    }

    let newText: string

    if (item.type === 'snippet') {
      // 片段选中：仅替换光标处的 /xxx，保留前后文本。
      const snippet = item.data as PromptSnippet
      const expanded = resolveSnippetAutoVars(snippet.content)
      if (snippet.variables.length > 0) {
        setSnippetTriggerBefore({ before: textBeforeCursor, cursor: cursorPosition })
        setActiveSnippet(snippet)
      } else {
        applySlashReplacement(expanded)
      }
      setShowSuggestions(false)
      setSuggestionItems([])
      return
    } else if (item.type === 'cli-command') {
      // CLI 命令：保留斜杠插入 `/name `，回车后整条消息交给 Claude CLI 解析执行
      const cmd = item.data as CliCommandSuggestion
      applySlashReplacement(`/${cmd.name} `)
      return
    } else if (item.type === 'skill') {
      const skill = item.data as SkillItem
      applySlashReplacement(`skill-${skill.id} `)
      return
    } else if (item.type === 'agent-mention') {
      // @专家 提及：只替换 `@专家<查询>` 这个 token，不替换整条命令
      const agent = item.data as import('./FileSuggestion').AgentArgSuggestion
      const replaced = textBeforeCursor.replace(/@专家(?:\s+\S*)?$/, `@专家:${agent.slug} `) + textAfterCursor
      setLocalText(replaced)
      updateInputDraft({ text: replaced, attachments, contextBlocks: contextBlocksRef.current })
      setShowSuggestions(false)
      setSuggestionItems([])
      setTimeout(() => {
        textarea.focus()
        const cursor = replaced.length - textAfterCursor.length
        textarea.setSelectionRange(cursor, cursor)
      }, 0)
      return
    } else if (item.type === 'agent') {
      // 专家参数补全：整条命令替换为 insertText（命令必在消息首）
      const agent = item.data as import('./FileSuggestion').AgentArgSuggestion
      const replaced = agent.insertText + textAfterCursor
      setLocalText(replaced)
      updateInputDraft({ text: replaced, attachments, contextBlocks: contextBlocksRef.current })
      setShowSuggestions(false)
      setSuggestionItems([])
      setTimeout(() => {
        textarea.focus()
        const cursor = agent.insertText.length
        textarea.setSelectionRange(cursor, cursor)
      }, 0)
      return
    } else if (item.type === 'mcp') {
      const mcp = item.data as McpServerItem
      applySlashReplacement(`mcp-${mcp.id} `)
      return
    } else if (item.type === 'cap') {
      // /cap 条目：选中转为轻量引用 chip（cap-help ContextBlock），正文仅移除 `/cap <查询>` 前缀。
      // 引用与正文解耦：正文零标记 token，chip 走 ContextBlockPreview 通道，发送时统一在消息末尾物化。
      // 不能走 replaceSlashToken——/cap <查询> 是双 token，/cap 恒在消息首，仿 agent 分支整条前缀替换。
      // 目录未就绪/空目录 → 保留现文本回退（/cap 命令文本，发送时由 chatCommandRouter 兜底）。
      const cap = item.data as CapSuggestion
      const catalog = useCapCatalogStore.getState()
      const entry = cap.id ? catalog.caps.find(c => c.id === cap.id) : undefined
      const canConvert = Boolean(entry) || (!cap.id && catalog.caps.length > 0)
      if (!canConvert) return
      const block = buildCapReferenceBlock(entry, catalog.caps)
      const nextBlocks = upsertContextBlock(contextBlocksRef.current, block)
      contextBlocksRef.current = nextBlocks
      setLocalContextBlocks(nextBlocks)
      const replaced = textAfterCursor
      setLocalText(replaced)
      // 立即整体回写草稿（不走防抖路径），防切会话/发送竞态丢块
      updateInputDraft({ text: replaced, attachments, contextBlocks: nextBlocks })
      setShowSuggestions(false)
      setSuggestionItems([])
      setTimeout(() => {
        textarea.focus()
        textarea.setSelectionRange(0, 0)
      }, 0)
      return
    } else if (item.type === 'conversation') {
      // @对话 引用：加载源消息 → packForReference 落盘 → 把 @对话 替换为 @path（复用现有 @path 注入链）
      const conv = item.data as ConversationSuggestion
      const beforeCursor = textBeforeCursor
      const afterCursor = textAfterCursor
      // 落盘工作区：优先用源对话自己的工作区（它本来就在那产生），
      // 避免当前会话（如无工作区的会话）无 path 时报「未关联工作区」。
      // 两者都没有才真正无法导出。
      const workspacePath = conv.workspacePath || currentWorkspace?.path || ''
      setShowSuggestions(false)
      setSuggestionItems([])
      setConversationMode(false)

      void (async () => {
        try {
          if (!workspacePath) {
            useToastStore.getState().error(t('handoff.failToast'), t('handoff.reasonNoWorkspace'))
            return
          }
          const messages = await dialogStorageService.getConversationMessages(conv.externalId)
          if (messages.length === 0) {
            useToastStore.getState().error(t('handoff.failToast'), t('handoff.emptyContent'))
            return
          }
          // 摘要模式：控制注入体积，避免上下文膨胀
          const { fileRef } = await packForReference(messages, conv.title, conv.externalId, workspacePath)
          const replaced = beforeCursor.replace(/@对话(?:\s+\S*)?$/, `@${fileRef.relPath} `) + afterCursor
          setLocalText(replaced)
          debouncedPersistDraft(replaced, attachments)
          log.info('@对话 引用已插入', { externalId: conv.externalId, ref: fileRef.relPath })
          setTimeout(() => {
            textarea.focus()
            const newCursorPos = replaced.length - afterCursor.length
            textarea.setSelectionRange(newCursorPos, newCursorPos)
          }, 0)
        } catch (e) {
          const err = e instanceof Error ? e : new Error(String(e))
          log.error('@对话 引用插入失败', err, { externalId: conv.externalId })
          useToastStore.getState().error(t('handoff.failToast'), err.message)
        }
      })()
      return
    } else if (item.type === 'workspace') {
      const workspace = item.data as Workspace
      newText = textBeforeCursor.replace(/@[\w\u4e00-\u9fa5-/]*$/, `@${workspace.name}:`) + textAfterCursor
    } else {
      const file = item.data as FileMatch
      if (fileWorkspace) {
        // 跨工作区引用: @workspace:path
        newText = textBeforeCursor.replace(/@[\w\u4e00-\u9fa5-]+:[^\s]*$/, `@${fileWorkspace.name}:${file.relativePath} `) + textAfterCursor
      } else {
        // 当前工作区引用: @path
        newText = textBeforeCursor.replace(/@[^\s]*$/, `@${file.relativePath} `) + textAfterCursor
      }
    }

    // 立即更新本地 state
    setLocalText(newText)
    // 持久化到 Store
    debouncedPersistDraft(newText, attachments)
    setShowSuggestions(false)
    setSuggestionItems([])
    setFileWorkspace(null)

    setTimeout(() => {
      textarea.focus()
      const newCursorPos = newText.length - textAfterCursor.length
      textarea.setSelectionRange(newCursorPos, newCursorPos)
    }, 0)
  }, [value, fileWorkspace, attachments, debouncedPersistDraft, resolveSnippetAutoVars, currentWorkspace, t, updateInputDraft])

  const handleSend = useCallback(async () => {
    const trimmed = value.trim()
    const hasBlocks = contextBlocksRef.current.length > 0
    if (disabled && attachments.length === 0 && !hasBlocks) return
    // 批 6（审计 5.11）：输入长度上限——附件有完整限制而纯文本无上限，粘贴
    // 几十万字符直接进草稿与引擎。与附件纪律对齐（validateAttachment 同形态
    // toast 拦截），普通对话远低于此阈值，只有误粘贴大文件内容才会触达。
    const MAX_INPUT_CHARS = 200_000
    if (trimmed.length > MAX_INPUT_CHARS) {
      useToastStore.getState().warning(
        t('input.tooLong', '消息过长（{{count}} 字符，上限 {{max}}）', {
          count: trimmed.length,
          max: MAX_INPUT_CHARS,
        }),
        t('input.tooLongHint', '请分段发送，或把大段内容存为文件后用 @引用'),
      )
      return
    }
    // 输入为空但有待发送队列：Enter 直接发送队首（立即优先；流式中自动中断当前回复再发）
    if (!trimmed && !editMode && pendingQueue.length > 0 && attachments.length === 0 && !hasBlocks) {
      void sendPendingNow(pendingQueue[0].id)
      return
    }
    if (!trimmed && attachments.length === 0 && !hasBlocks) return

    // 流式回复中：不直接发送，整条入队，session_end / 中断后自动逐条发送
    if (isStreaming) {
      // 本地斜杠命令在流式中忽略（保持原行为：流式中本地命令不执行、不入队）
      if (
        trimmed.startsWith('/nexus') ||
        trimmed.startsWith('/agent') ||
        trimmed.startsWith('/dispatch') ||
        trimmed.startsWith('/assault')
      ) {
        return
      }
      // 流式 /cap 收编：目录就绪时转为引用 chip（正文取剩余部分），不再把注入块字面入队；
      // 目录未就绪 / 多命中 → 维持字面入队（已知残余，见 plans/reference-mapping-spec.md R5）
      let effectiveText = trimmed
      const capCmd = parseCapSlashCommand(trimmed)
      if (capCmd) {
        const catalog = useCapCatalogStore.getState()
        if (catalog.loaded && catalog.caps.length > 0) {
          const matches = capCmd.firstToken ? matchCaps(catalog.caps, capCmd.firstToken) : []
          if (matches.length === 1 && matches[0]) {
            const nextBlocks = upsertContextBlock(contextBlocksRef.current, buildCapReferenceBlock(matches[0]))
            contextBlocksRef.current = nextBlocks
            setLocalContextBlocks(nextBlocks)
            updateInputDraft({ text: capCmd.remainder, attachments: localAttachments, contextBlocks: nextBlocks })
            effectiveText = capCmd.remainder
          } else if (!capCmd.firstToken || matches.length === 0) {
            const nextBlocks = upsertContextBlock(contextBlocksRef.current, buildCapReferenceBlock(undefined, catalog.caps))
            contextBlocksRef.current = nextBlocks
            setLocalContextBlocks(nextBlocks)
            updateInputDraft({ text: capCmd.rest, attachments: localAttachments, contextBlocks: nextBlocks })
            effectiveText = capCmd.rest
          }
        }
      }
      // 引用内容发送单点物化：统一追加在正文之后（末尾包含契约，plans/reference-mapping-spec.md）
      const { trailing } = await materializeContextBlocks(contextBlocksRef.current, currentWorkspace?.path)
      const messageContent = trailing ? (effectiveText ? `${effectiveText}\n\n${trailing}` : trailing) : effectiveText
      enqueuePending({
        id: crypto.randomUUID(),
        text: messageContent,
        attachments: attachments.length > 0 ? attachments : undefined,
        createdAt: Date.now(),
      })
      // 上下文块已随消息入队（左侧边栏圈选记录 store 已随内置浏览器退役）
      const _sentBlockIds = contextBlocksRef.current.map((b) => b.id)
      void _sentBlockIds
      // 记录到 prompt 历史（记录用户正文；/cap 引用已转 chip，不入史）。
      // 入队是本地同步操作，不需要发送事务：
      // 真正送出发生在队列派发时，失败时队列本身会保留队首；历史按「已入队即记录」处理。
      if (effectiveText) {
        const appended = appendPromptHistoryEntry(sentHistoryRef.current, effectiveText)
        if (!arePromptHistoryEntriesEqual(sentHistoryRef.current, appended)) {
          sentHistoryRef.current = appended
          void persistPromptHistoryEntries(promptHistoryWorkspacePath, appended)
        }
      }
      // 清空本地 state 与草稿
      cancelPersistDraft()
      setLocalText('')
      setLocalAttachments([])
      contextBlocksRef.current = []
      setLocalContextBlocks([])
      updateInputDraft({ text: '', attachments: [], contextBlocks: [] })
      resetPromptOptimize()
      setHistoryIndex(null)
      return
    }

    // Polaris 本地斜杠命令：/nexus /agent /dispatch /assault → 委托 chatCommandRouter
    const cmd = tryHandleSlashCommand(trimmed, { activeSessionId })
    if (cmd.handled) {
      cancelPersistDraft()
      setLocalText('')
      setLocalAttachments([])
      updateInputDraft({ text: '', attachments: [], contextBlocks: [] })
      contextBlocksRef.current = []
      setLocalContextBlocks([])
      setHistoryIndex(null)
      resetPromptOptimize()
      if (cmd.sendText) {
        // 本地斜杠命令发送：当前挂着的引用 chips 一并物化追加在 sendText 末尾
        //（修复旧分支静默丢弃 TCB 的洞）；prompt 历史照旧记录 sendText 全文
        const { trailing } = await materializeContextBlocks(contextBlocksRef.current, currentWorkspace?.path)
        const sendText = trailing ? `${cmd.sendText}\n\n${trailing}` : cmd.sendText
        void commitPromptHistory(sendText, () =>
          onSend(sendText, currentWorkspace?.path, attachments.length > 0 ? attachments : undefined)
        )
      }
      return
    }

    // /spec 规格驱动开发命令（已移除）

    // Claude 引擎：拦截 /clear（及别名）—— CLI 侧会新开对话，
    // 导致 CLI 上下文与 Polaris 界面历史脱钩。清空上下文请用 Polaris 新建会话。
    if (isClaudeEngine) {
      const blocked = matchBlockedCliCommand(trimmed)
      if (blocked) {
        useToastStore.getState().info(
          t('cliCommand.clearBlockedTitle', { command: `/${blocked}` }),
          t('cliCommand.clearBlockedDetail')
        )
        return
      }
    }

    // 优化进行中发送 = 用户放弃本轮优化结果
    if (optimizeRunning && activeSessionId) {
      cancelPromptOptimize(activeSessionId)
    }

    // 取消 pending 的防抖回调，防止旧值写回 Store
    cancelPersistDraft()

    // 编辑模式：调用 editAndResend 而非普通发送
    if (editMode && onEditSend) {
      // 流式中 store 的 editAndResend 会静默拒绝（流式守卫），而下方清理逻辑
      // 无条件清空输入 → 用户编辑改动丢失且零反馈（审计 5.4）。此处提前拦截，
      // 保留输入与编辑态，流式结束后再发送。
      if (isStreaming) {
        useToastStore.getState().warning(t('input.editBlockedWhileStreaming', '回复进行中，暂不能发送编辑消息，请稍候'))
        return
      }
      onEditSend(editMode.messageId, trimmed, currentWorkspace?.path)
    } else {
      // 普通发送：引用内容（TCB / cap-help / 插件 kind）单点物化，统一追加在用户正文
      // **之后**（末尾包含契约）：有工作区 → 全部落盘为一个 .polaris-handoff/tcb-*.md，
      // 末尾只放固定引导句 + @path（引擎按引用读取，避免消息体膨胀）；
      // 无工作区 / 落盘失败 → 末尾追加格式化全文（保底不丢内容）。
      const { trailing } = await materializeContextBlocks(contextBlocksRef.current, currentWorkspace?.path)
      const messageContent = trailing ? (trimmed ? `${trimmed}\n\n${trailing}` : trailing) : trimmed
      // 整段文本作为一条消息发送，保留用户输入的换行/空行格式。
      // （待发送队列仅用于「流式回复期间预输入」，见上方 isStreaming 分支；
      //   空闲时不再按换行拆分，避免用户写长消息按回车换行被误拆成多条排队。）
      // 发送 + 历史记录走提交事务（见 commitPromptHistory）：发送失败不入史，
      // 不需要等待事务完成即可清理输入（回滚不影响 UI，浏览态事实源由 helper 兜底）。
      void commitPromptHistory(trimmed, () =>
        onSend(messageContent, currentWorkspace?.path, attachments.length > 0 ? attachments : undefined)
      )
      // 上下文块已随消息发出（左侧边栏圈选记录 store 已随内置浏览器退役）
      const _sentBlockIds2 = contextBlocksRef.current.map((b) => b.id)
      void _sentBlockIds2
    }

    // 清空本地 state
    setLocalText('')
    setLocalAttachments([])
    contextBlocksRef.current = []
    setLocalContextBlocks([])
    // 清空 Store 草稿
    updateInputDraft({ text: '', attachments: [], contextBlocks: [] })
    // 清空提示词优化版本栈（草稿已发出，版本历史随之失效）
    resetPromptOptimize()
    // 退出编辑模式
    if (editMode) onCancelEdit?.()
    // 重置历史索引
    setHistoryIndex(null)
  }, [value, disabled, isStreaming, attachments, localAttachments, onSend, updateInputDraft, cancelPersistDraft, currentWorkspace, promptHistoryWorkspacePath, editMode, onEditSend, onCancelEdit, isClaudeEngine, t, optimizeRunning, activeSessionId, resetPromptOptimize, enqueuePending, sendPendingNow, pendingQueue, commitPromptHistory])

  // 键盘事件处理
  const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      // 中文 IME 组词中按 Enter 是「确认候选词上屏」，不是发送（对齐下方 ↑/↓ 历史召回的
      // isComposing 防护）。漏掉此判断会把组词中的半截文本直接发出，中文用户必踩。
      if (e.nativeEvent.isComposing) return

      // 如果建议框打开，选择建议
      if (showSuggestions && suggestionItems.length > 0) {
        e.preventDefault()
        selectSuggestion(suggestionItems[selectedIndex])
        return
      }

      // 正常发送
      e.preventDefault()
      handleSend()
      return
    }

    // 上下箭头选择建议（优先级高于历史记录）
    if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && showSuggestions && suggestionItems.length > 0) {
      e.preventDefault()

      const maxIndex = suggestionItems.length - 1
      const direction = e.key === 'ArrowUp' ? -1 : 1

      setSelectedIndex(prev => {
        const newIndex = prev + direction
        if (newIndex < 0) return maxIndex
        if (newIndex > maxIndex) return 0
        return newIndex
      })
      return
    }

    // ArrowUp/ArrowDown prompt 历史召回（终端风格；语义对齐 promptHistory 模块 / ZCode）
    if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && !showSuggestions && sentHistoryRef.current.length > 0) {
      const blocked =
        disabled ||              // 无可用会话时放行（P8）
        e.shiftKey ||
        e.ctrlKey ||
        e.metaKey ||
        e.altKey ||
        e.nativeEvent.isComposing // 中文 IME 组词中按 ↑/↓ 是候选导航，不能当历史召回（P4）
      const entries = sentHistoryRef.current
      const isBrowsing = historyIndex !== null
      // 只在「空输入」或「已在浏览态」时接管方向键（P1 修复：浏览态可整段上下翻），
      // 不抢走多行输入原本的光标移动行为（对齐 ZCode PromptHistoryPlugin）。
      if (!blocked && (isBrowsing || value === '')) {
        const result = navigatePromptHistory(
          entries,
          historyIndex,
          e.key === 'ArrowUp' ? 'up' : 'down'
        )
        if (result.shouldHandle) {
          e.preventDefault()
          setHistoryIndex(result.nextIndex)
          setLocalText(result.nextValue)
          // 召回值不写草稿 Store（P7）：浏览不得污染草稿，真实编辑才在
          // handleInputChange 中持久化；翻尽退出浏览态回到浏览前输入即可。
          return
        }
      }
    }

    // ESC 关闭建议 / 中断流式输出 / 退出编辑模式
    if (e.key === 'Escape') {
      if (showSuggestions) {
        setShowSuggestions(false)
        setSuggestionItems([])
        clearResults()
        return
      }
      if (editMode) {
        onCancelEdit?.()
        return
      }
      if (isStreaming && onInterrupt) {
        onInterrupt()
        return
      }
    }

    // Tab 选择建议
    if (e.key === 'Tab' && !e.shiftKey && showSuggestions && suggestionItems.length > 0) {
      e.preventDefault()
      selectSuggestion(suggestionItems[selectedIndex])
    }
  }, [
    showSuggestions,
    suggestionItems,
    selectedIndex,
    selectSuggestion,
    clearResults,
    handleSend,
    isStreaming,
    onInterrupt,
    value,
    historyIndex,
    disabled,
    editMode,
    onCancelEdit,
  ])

  // 点击外部关闭建议
  useEffect(() => {
    const handleClickOutside = () => {
      setShowSuggestions(false)
      setSuggestionItems([])
    }

    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  const canSend = (value.trim() || attachments.length > 0 || contextBlocksRef.current.length > 0) && !disabled
  // 是否有可提交草稿（与 canSend 内容判定同源）。
  // 用于按钮状态机：流式 + 有草稿 → 停止键与发送键并排（发送键点击入队）；流式 + 空 → 显示中断键。
  const hasDraftToSubmit = value.trim() || attachments.length > 0 || contextBlocksRef.current.length > 0

  // 中断/停止按钮元素：流式期间的紧急出口。
  // 根因（U2，perf-ux-round2）：原状态机在「流式+有草稿」时用发送键整体替换中断键，
  // 唯一停止手段只剩无 UI 提示的 ESC（handleKeyDown 的 Escape 分支），紧急出口消失。
  // 抽出共用元素后两形态并存：空输入独占按钮位（原语义不变）；
  // 有草稿时与发送键并排（16px 图标 + p-1.5 = 28px 命中区 ≥ 24px，窄面板不挤压）。
  const interruptButton = isStreaming && onInterrupt && (
    <button
      onClick={onInterrupt}
      disabled={isInterrupting}
      className="shrink-0 p-1.5 rounded-full bg-danger text-white hover:bg-danger-hover transition-colors disabled:opacity-60 disabled:cursor-not-allowed shadow-soft"
      title={isInterrupting ? t('input.interrupting', '正在中断…') : t('input.interrupt')}
    >
      {isInterrupting
        ? <Loader2 size={16} className="animate-spin" />
        : <IconStop size={16} />}
    </button>
  )

  return (
    <div data-theme-panel className="chat-input-root border-t border-border bg-background-elevated relative" ref={containerRef} style={chatDisplayStyle}>
      {/* 待发送简报卡片（压缩交接产物，随下一条消息作为上下文发出） */}
      <PendingBriefingCard />
      {/* 待发送队列胶囊（流式预输入 / 多行拆分入队项） */}
      <PendingQueueCard />
      {/* 片段变量填写浮窗 */}
      {activeSnippet && (
        <SnippetParamPanel
          snippet={activeSnippet}
          onExpand={(content) => {
            const expanded = resolveSnippetAutoVars(content)
            let nextText = expanded
            if (snippetTriggerBefore) {
              const match = snippetTriggerBefore.before.match(/(^|[\s(,;]|\[)\/\S*$/)
              if (match && match.index !== undefined) {
                const tokenStart = match.index + match[1].length
                nextText = snippetTriggerBefore.before.slice(0, tokenStart)
                  + expanded
                  + localText.slice(snippetTriggerBefore.cursor)
              }
            }
            setLocalText(nextText)
            setActiveSnippet(null)
            setSnippetTriggerBefore(null)
            updateInputDraft({ text: nextText, attachments, contextBlocks: contextBlocksRef.current })
            setTimeout(() => textareaRef.current?.focus(), 0)
          }}
          onCancel={() => {
            setActiveSnippet(null)
            setSnippetTriggerBefore(null)
          }}
        />
      )}
      {/* 编辑模式提示条 */}
      {editMode && (
        <div className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 border-b border-primary/20 text-xs text-primary">
          <span>{t('input.editingMessage')}</span>
          <button
            onClick={onCancelEdit}
            className="ml-auto px-1.5 py-0.5 rounded hover:bg-primary/20 transition-colors"
          >
            {t('input.cancelEdit')}
          </button>
        </div>
      )}
      {/* 下一步建议气泡（--prompt-suggestions）：仅在输入框为空、非流式、非编辑态时展示 */}
      {promptSuggestion && !value.trim() && !isStreaming && !editMode && (
        <div className="px-2 sm:px-3 pt-2">
          <button
            type="button"
            onClick={() => {
              setLocalText(promptSuggestion)
              setPromptSuggestion(null)
              debouncedPersistDraft(promptSuggestion, attachments)
              setTimeout(() => textareaRef.current?.focus(), 0)
            }}
            title={t('input.promptSuggestionHint')}
            className="group flex items-start gap-1.5 max-w-full px-2.5 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/20 text-xs text-primary/90 text-left transition-colors"
          >
            <Sparkles size={13} className="shrink-0 mt-0.5 opacity-70" />
            <span className="line-clamp-2 break-words">{promptSuggestion}</span>
          </button>
        </div>
      )}
      {/* 提示词优化胶囊：优化中（流式预览 + 取消） */}
      {optimizeRunning && (
        <div className="px-2 sm:px-3 pt-2">
          <div className="flex items-start gap-1.5 max-w-full px-2.5 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary/90">
            <Loader2 size={13} className="shrink-0 mt-0.5 animate-spin" />
            <span className="flex-1 min-w-0 line-clamp-2 break-words whitespace-pre-wrap">
              {optimizePreview.isStreaming && optimizePreview.text.trim()
                ? optimizePreview.text
                : optimizeMode === 'deep' && !optimizePreview.text.trim()
                  ? t('promptOptimize.readingContext')
                  : t('promptOptimize.running')}
            </span>
            {promptOptimize.pendingMeta && (promptOptimize.pendingMeta.totalIterations ?? 1) > 1 && (
              <span className="shrink-0 px-1.5 py-0.5 rounded text-[10px] bg-primary/20 text-primary">
                {t('promptOptimize.iterationBadge', {
                  defaultValue: '第 {{cur}}/{{total}} 轮',
                  cur: promptOptimize.pendingMeta.iteration ?? 1,
                  total: promptOptimize.pendingMeta.totalIterations ?? 1,
                })}
              </span>
            )}
            <button
              onClick={handleCancelOptimize}
              className="shrink-0 p-0.5 rounded hover:bg-primary/20 transition-colors"
              title={t('promptOptimize.cancel')}
            >
              <X size={12} />
            </button>
          </div>
        </div>
      )}
      {/* 提示词优化胶囊：结果就绪（输入被手改，待用户确认应用） */}
      {promptOptimize.status === 'ready' && promptOptimize.pendingResult && (
        <div className="px-2 sm:px-3 pt-2">
          <div className="flex items-start gap-1.5 max-w-full px-2.5 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary/90">
            <Wand2 size={13} className="shrink-0 mt-0.5 opacity-70" />
            <div className="flex-1 min-w-0">
              <span className="font-medium">{t('promptOptimize.readyTitle')}</span>
              <p className="line-clamp-2 break-words text-primary/70 mt-0.5">{promptOptimize.pendingResult}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={handleApplyOptimizeResult}
                className="flex items-center gap-1 px-2 py-1 text-[11px] text-primary hover:bg-primary/20 rounded transition-colors"
                title={t('promptOptimize.applyHint')}
              >
                <Check size={12} />
                {t('promptOptimize.apply')}
              </button>
              <button
                onClick={resetPromptOptimize}
                className="p-0.5 rounded text-primary/60 hover:bg-primary/20 transition-colors"
                title={t('promptOptimize.discard')}
              >
                <X size={12} />
              </button>
            </div>
          </div>
        </div>
      )}
      {/* 提示词优化胶囊：失败（原文无损，可关闭后重试） */}
      {promptOptimize.status === 'idle' && promptOptimize.error && (
        <div className="px-2 sm:px-3 pt-2">
          <div className="flex items-start gap-1.5 max-w-full px-2.5 py-1.5 rounded-lg bg-danger/10 border border-danger/20 text-xs text-danger">
            <Wand2 size={13} className="shrink-0 mt-0.5 opacity-70" />
            <span className="flex-1 min-w-0 line-clamp-2 break-words">
              {t('promptOptimize.errorPrefix')}{promptOptimize.error}
            </span>
            <button
              onClick={clearPromptOptimizeError}
              className="shrink-0 p-0.5 rounded hover:bg-danger/20 transition-colors"
              title={t('promptOptimize.dismissError')}
            >
              <X size={12} />
            </button>
          </div>
        </div>
      )}
      {/* AI 注入的动态横幅（cap.ui.input banner） */}
      <InputBanner />
      {/* AI 注入的输入区插槽组件（cap.self.mutate input-extra） */}
      <div className="px-2 sm:px-3 pb-0.5">
        <UiSlot slotId="input-extra" />
      </div>
      <div className="p-2 sm:p-3">
        {/* 输入框统一容器（纵向布局：附件预览 + textarea + 底部工具栏） */}
        <div
          className="relative flex flex-col bg-background-surface border border-border rounded-lg sm:rounded-xl focus-within:ring-2 focus-within:ring-border focus-within:border-primary shadow-soft hover:shadow-medium"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          {/* 隐藏的文件输入 */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={handleFileSelect}
            accept={`image/*,${ATTACHMENT_LIMITS.codeExtensions.join(',')}`}
          />

          {/* 上下文块预览（浏览器圈选等，可展开核对，可加备注，发送时转文本） */}
          <ContextBlockPreview
            blocks={localContextBlocks}
            onRemove={removeContextBlock}
            onUpdateNote={updateContextBlockNote}
          />

          {/* 附件预览（内嵌到容器顶部） */}
          <AttachmentPreview
            attachments={attachments}
            onRemove={removeAttachment}
          />

          {/* 文本输入（独占整宽，无边框融入外框） */}
          <AutoResizingTextarea
            ref={textareaRef}
            value={value}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder={attachments.length > 0 ? t('input.placeholderWithAttachment') : t('input.placeholder')}
            className="chat-input-text w-full px-2.5 sm:px-3 pt-2.5 pb-1.5 bg-transparent text-text-primary placeholder:text-text-tertiary resize-none outline-none border-0"
            disabled={disabled}
            maxHeight={200}
            minHeight={40}
          />

          {/* 底部工具栏 - 左侧创作辅助 / 中段状态栏 / 右侧发送 */}
          <div className="flex items-center gap-1.5 min-w-0 px-1.5 sm:px-2 pb-1.5 pt-1 rounded-b-lg sm:rounded-b-xl">
            {/* 左侧：附件按钮 + 提示词优化 + 版本控件 */}
            <div className="flex items-center gap-1 shrink-0 rounded-full px-0.5 py-0.5">
              <button
                onClick={openFileDialog}
                disabled={disabled || isStreaming}
                className="shrink-0 p-1.5 rounded-full text-text-tertiary hover:text-text-primary hover:bg-background-hover transition-colors disabled:opacity-50"
                title={t('input.addAttachment')}
              >
                <IconPaperclip size={16} />
              </button>
              {/* 提示词优化按钮 + 引擎/模式选择浮层 */}
              <div className="relative">
                <button
                  ref={optimizeButtonRef}
                  onClick={() => setOptimizePickerOpen((v) => !v)}
                  disabled={!canOptimize}
                  className="shrink-0 p-1.5 rounded-full text-text-tertiary hover:text-primary hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  title={optimizeTitle}
                >
                  {optimizeRunning ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <Wand2 size={16} />
                  )}
                </button>
                {optimizePickerOpen && (
                  <div
                    ref={optimizePickerRef}
                    className="absolute left-0 bottom-full mb-1 z-dropdown w-[220px] rounded-lg shadow-lg bg-background-elevated border border-border flex flex-col max-h-[70vh]"
                  >
                    {/* 可滚动内容区 */}
                    <div className="overflow-y-auto overscroll-contain py-1.5">
                    {/* 引擎选择 */}
                    <div className="px-2 pb-1.5 text-[11px] font-medium text-text-tertiary">
                      {t('promptOptimize.selectEngine')}
                    </div>
                    {OPTIMIZE_ENGINE_OPTIONS.map(({ id, label, Icon }) => (
                      <button
                        key={id}
                        onClick={() => setOptimizeEngineAndReset(id)}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs transition-colors rounded-md hover:bg-background-hover text-text-secondary hover:text-text-primary"
                        title={getEngineFullName(id)}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span className="flex-1 text-left">{label}</span>
                        {optimizeEngine === id && <Check className="w-3 h-3 text-primary" />}
                      </button>
                    ))}

                    {/* 模式切换 */}
                    <div className="my-1.5 border-t border-border" />
                    <div className="px-2 pb-1 text-[11px] font-medium text-text-tertiary">
                      {t('promptOptimize.mode')}
                    </div>
                    {OPTIMIZE_MODE_OPTIONS.map(({ key, label, hint, costHint, Icon: ModeIcon }) => (
                      <button
                        key={key}
                        onClick={() => {
                          setOptimizeMode(key)
                          if (key === 'deep' && !localStorage.getItem('polaris.promptOptimize.privacyNoticeSeen')) {
                            setOptimizePrivacyNotice(true)
                          }
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs transition-colors rounded-md hover:bg-background-hover text-text-secondary hover:text-text-primary"
                      >
                        <ModeIcon className="w-3.5 h-3.5" />
                        <span className="flex-1 text-left flex flex-col gap-0.5">
                          <span className="text-xs flex items-center gap-1.5">
                            {t(label)}
                            {key === 'deep' && costHint && (
                              <span className="text-[10px] text-warning/70 font-normal">{t(costHint)}</span>
                            )}
                          </span>
                          <span className="text-[10px] text-text-tertiary">{t(hint)}</span>
                        </span>
                        {optimizeMode === key && <Check className="w-3 h-3 text-primary" />}
                      </button>
                    ))}

                    {/* 方向选择 */}
                    <div className="my-1.5 border-t border-border" />
                    <div className="px-2 pb-1 text-[11px] font-medium text-text-tertiary">
                      {t('promptOptimize.direction')}
                    </div>
                    <div className="flex flex-wrap gap-1 px-2 pb-1">
                      {OPTIMIZE_DIRECTION_OPTIONS.map(({ key, label }) => (
                        <button
                          key={key}
                          onClick={() => setOptimizeDirection(key)}
                          className={`px-2 py-1 text-[11px] rounded-md border transition-colors ${
                            optimizeDirection === key
                              ? 'bg-primary text-white border-primary'
                              : 'border-border text-text-secondary hover:bg-background-hover hover:text-text-primary'
                          }`}
                        >
                          {t(label)}
                        </button>
                      ))}
                    </div>
                    {/* 自定义方向输入框（仅 custom 选中时展开） */}
                    {optimizeDirection === 'custom' && (
                      <div className="px-2 pb-1">
                        <textarea
                          value={optimizeCustomText}
                          onChange={(e) => setOptimizeCustomText(e.target.value)}
                          placeholder={t('promptOptimize.customDirectionPlaceholder')}
                          rows={2}
                          className={`w-full px-2 py-1.5 text-[11px] rounded-md bg-background border rounded-md resize-none focus:outline-none transition-colors ${
                            !optimizeCustomText.trim()
                              ? 'border-danger/50'
                              : 'border-border focus:border-primary'
                          }`}
                        />
                        {!optimizeCustomText.trim() && (
                          <p className="text-[10px] text-danger mt-0.5">{t('promptOptimize.customDirectionRequired')}</p>
                        )}
                      </div>
                    )}

                    {/* 轮次选择 */}
                    <div className="my-1 border-t border-border" />
                    <div className="px-2 pb-1 text-[11px] font-medium text-text-tertiary">
                      {t('promptOptimize.iterations')}
                    </div>
                    <div className="flex flex-wrap gap-1 px-2 pb-1">
                      {OPTIMIZE_ITERATION_OPTIONS.map((n) => (
                        <button
                          key={n}
                          onClick={() => setOptimizeIterations(n)}
                          className={`px-2 py-1 text-[11px] rounded-md border transition-colors ${
                            optimizeIterations === n
                              ? 'bg-primary text-white border-primary'
                              : 'border-border text-text-secondary hover:bg-background-hover hover:text-text-primary'
                          }`}
                        >
                          {n === 1 ? t('promptOptimize.singleRound') : String(n)}
                        </button>
                      ))}
                    </div>
                    {optimizeIterations > 1 && (
                      <p className="px-2 pb-1 text-[10px] text-text-tertiary leading-relaxed">
                        {t('promptOptimize.iterationHint')}
                      </p>
                    )}

                    {/* 折叠高级选项：供应商 / 模型 */}
                    <div className="my-1 border-t border-border" />
                    <button
                      onClick={() => setShowOptimizeAdvanced((v) => !v)}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs text-text-secondary hover:text-text-primary hover:bg-background-hover transition-colors"
                    >
                      <span>{t('promptOptimize.advanced')}</span>
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showOptimizeAdvanced ? 'rotate-180' : ''}`} />
                    </button>
                    {showOptimizeAdvanced && (
                      <>
                        <div className="px-3 py-1">
                          <span className="text-[10px] text-text-tertiary block mb-1">
                            {t('promptOptimize.profile')}
                          </span>
                          {optimizeProfileOptions.length > 0 ? (
                            optimizeProfileOptions.map((p) => (
                              <button
                                key={p.value}
                                onClick={() => { setOptimizeProfileId(p.value); setOptimizeModel('') }}
                                className="w-full flex items-center justify-between px-1 py-0.5 text-xs rounded hover:bg-background-hover text-text-secondary hover:text-text-primary"
                              >
                                <span className="truncate">{p.label}</span>
                                {optimizeProfileId === p.value && <Check className="w-3 h-3 text-primary shrink-0" />}
                              </button>
                            ))
                          ) : (
                            <span className="text-[10px] text-text-tertiary italic px-1">
                              {t('promptOptimize.noProfiles')}
                            </span>
                          )}
                        </div>
                        {optimizeProfileId && optimizeModelOptions.length > 0 && (
                          <div className="px-3 py-1 pb-1.5">
                            <span className="text-[10px] text-text-tertiary block mb-1">
                              {t('promptOptimize.model')}
                            </span>
                            {optimizeModelOptions.map((m) => (
                              <button
                                key={m.value}
                                onClick={() => setOptimizeModel(m.value)}
                                className="w-full flex items-center justify-between px-1 py-0.5 text-xs rounded hover:bg-background-hover text-text-secondary hover:text-text-primary"
                              >
                                <span className="truncate">{m.label}</span>
                                {optimizeModel === m.value && <Check className="w-3 h-3 text-primary shrink-0" />}
                              </button>
                            ))}
                          </div>
                        )}
                      </>
                    )}
                    </div>

                    {/* 执行按钮（黏底） */}
                    <div className="sticky bottom-0 bg-background-elevated border-t border-border px-2 py-2 rounded-b-lg">
                      <button
                        onClick={handleOptimizeWithConfig}
                        disabled={!canOptimize}
                        className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-md bg-primary text-white text-xs font-medium hover:bg-primary-hover transition-colors disabled:opacity-45 disabled:cursor-not-allowed"
                      >
                        {optimizeMode === 'deep' && <Loader2 className="w-3 h-3" />}
                        <span>
                          {optimizeMode === 'deep'
                            ? (optimizeIterations > 1
                                ? t('promptOptimize.optimizeDeepIter', { defaultValue: '深度优化(迭代 {{n}} 轮)', n: optimizeIterations })
                                : t('promptOptimize.optimizeDeep'))
                            : (optimizeIterations > 1
                                ? t('promptOptimize.optimizeIter', { defaultValue: '优化(迭代 {{n}} 轮)', n: optimizeIterations })
                                : t('promptOptimize.optimize'))}
                        </span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
              {/* 版本控件：回滚 / 版本指示 / 重做 */}
              {showVersionControls && (
                <div className="flex items-center gap-0.5 shrink-0 text-text-tertiary">
                  <button
                    onClick={handleUndoOptimize}
                    disabled={!canUndoVersion}
                    className="p-1 rounded-md hover:text-text-primary hover:bg-background-hover transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    title={t('promptOptimize.undo')}
                  >
                    <Undo2 size={14} />
                  </button>
                  {(() => {
                    const v = promptOptimize.history[promptOptimize.cursor]
                    const total = (v?.totalIterations ?? 1)
                    const iter = total > 1 ? ` · ${t('promptOptimize.iterationBadge', { defaultValue: '第 {{cur}}/{{total}} 轮', cur: v?.iteration ?? 1, total })}` : ''
                    const dirLabel = v?.direction && v.direction !== 'structured'
                      ? ` · ${t(`promptOptimize.dir${v.direction.charAt(0).toUpperCase()}${v.direction.slice(1)}`)}`
                      : ''
                    const engineLabel = v?.engineId ? ` · ${getEngineFullName(v.engineId)}` : ''
                    const originLabel = v?.origin === 'original'
                      ? t('promptOptimize.versionOriginal')
                      : v?.origin === 'edited'
                        ? t('promptOptimize.versionEdited')
                        : `${t('promptOptimize.versionOptimized')}${iter}${dirLabel}${engineLabel}`
                    return (
                      <span className="text-[10px] tabular-nums px-0.5 select-none cursor-default" title={originLabel}>
                        {promptOptimize.cursor + 1}/{promptOptimize.history.length}
                      </span>
                    )
                  })()}
                  <button
                    onClick={handleRedoOptimize}
                    disabled={!canRedoVersion}
                    className="p-1 rounded-md hover:text-text-primary hover:bg-background-hover transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    title={t('promptOptimize.redo')}
                  >
                    <Redo2 size={14} />
                  </button>
                </div>
              )}
            </div>

            {/* 中段：嵌入式状态栏（会话配置/语音区等） */}
            {statusBarSlot && (
              <div className="flex-1 min-w-0 flex items-center px-0.5">
                {statusBarSlot}
              </div>
            )}
            {/* 无 statusBarSlot 时占位撑开右侧 */}
            {!statusBarSlot && <div className="flex-1" />}

            {/* 右侧：字数 + 发送/中断 */}
            <div className="flex items-center gap-1 shrink-0">
              {/* 字数（仅 statusBarSlot 模式下显示） */}
              {statusBarSlot && value.length > 0 && (
                <span className="hidden sm:inline-flex text-[11px] text-text-tertiary tabular-nums px-1">{value.length}</span>
              )}
              {/* 发送/中断/停止按钮
                  状态机（对齐 ZCode showStopControl = canStop && !hasDraftToSubmit）：
                  - 流式 + 有草稿 → 停止键与发送键并排（发送键走 handleSend 的 isStreaming 分支自动入队）
                  - 流式 + 空输入 → 中断键
                  - 空闲 + 有内容 → 发送键（直接发送） */}
              {interruptButton && !hasDraftToSubmit ? (
                interruptButton
              ) : (
                <button
                  onClick={handleSend}
                  disabled={!canSend}
                  className="shrink-0 p-1.5 rounded-full bg-primary text-white hover:bg-primary-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-soft"
                  title={isStreaming ? t('input.sendQueued') : t('input.send')}
                >
                  <IconSend size={16} />
                </button>
              )}
              {/* U2：流式+有草稿时停止键常驻——原三元把中断键整体替换为发送键后，
                  紧急出口只剩无 UI 提示的 ESC；此处并排补回，直连同一
                  onInterrupt/isInterrupting 中断链路，不改队列入队语义 */}
              {interruptButton && hasDraftToSubmit ? interruptButton : null}
            </div>
          </div>
        </div>
      </div>

      {/* 统一建议浮窗 */}
      {showSuggestions && suggestionItems.length > 0 && (
        <UnifiedSuggestion
          items={suggestionItems}
          selectedIndex={selectedIndex}
          onSelect={selectSuggestion}
          onHover={setSelectedIndex}
          position={suggestionPosition}
          currentWorkspaceId={currentWorkspaceId}
        />
      )}

      {/* 深度优化隐私提示（首次使用） */}
      {optimizePrivacyNotice && (
        <div className="fixed inset-0 z-modal flex items-center justify-center bg-black/40" onClick={() => setOptimizePrivacyNotice(false)}>
          <div className="w-[380px] max-w-[92vw] rounded-lg border border-border bg-background-surface p-4 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-medium text-text-primary mb-2">{t('promptOptimize.privacyNoticeTitle')}</div>
            <p className="text-xs text-text-secondary leading-relaxed mb-4">{t('promptOptimize.privacyNoticeBody')}</p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setOptimizePrivacyNotice(false)}
                className="rounded border border-border-subtle px-3 py-1.5 text-xs"
              >
                {t('promptOptimize.privacyNoticeCancel')}
              </button>
              <button
                type="button"
                onClick={() => {
                  localStorage.setItem('polaris.promptOptimize.privacyNoticeSeen', '1')
                  setOptimizePrivacyNotice(false)
                  // 确认后立即触发优化
                  handleOptimizeWithConfig()
                }}
                className="rounded bg-primary px-3 py-1.5 text-xs text-white"
              >
                {t('promptOptimize.privacyNoticeConfirm')}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* 底部安全区：iOS 刘海屏/Home indicator 遮挡补偿（桌面浏览器 env() 无定义→0，零副作用） */}
      <div className="h-[env(safe-area-inset-bottom)]" aria-hidden="true" />
    </div>
  )
}
