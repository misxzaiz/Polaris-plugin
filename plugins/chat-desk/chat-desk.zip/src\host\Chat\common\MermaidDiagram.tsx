/**
 * Mermaid 图表渲染组件
 *
 * 功能：
 * - 懒加载 mermaid 库，减少首屏体积
 * - IntersectionObserver：只在可见时渲染图表
 * - 支持暗色主题（匹配项目配色）
 * - 错误处理和友好提示
 * - 加载状态显示
 * - 图表缩放功能（鼠标滚轮 + 按钮）
 * - 源码/图表切换
 * - 复制源码功能
 */

import { memo, useEffect, useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { sanitizeMermaidSvg } from '@/utils/sanitizeMermaidSvg';
import { getMermaidConfig } from '@/utils/mermaid-config';
import { useThemeStore } from '@/stores/themeStore';
import { modKey } from '@/utils/path';
import { createLogger } from '@/utils/logger';
import {
  type ViewMode,
  type DiagramState,
  SCALE_CONFIG,
  getDiagramState,
  saveDiagramState,
  removeDiagramState,
} from '../messages/diagramState';

const log = createLogger('MermaidDiagram');

interface MermaidDiagramProps {
  /** Mermaid 图表代码 */
  code: string;
  /** 唯一标识符（用于生成图表 ID） */
  id: string;
  /** 是否启用自动渲染（performance.mermaidDiagrams 开关）。
   *  默认 true（向后兼容）。false 时不自动加载 mermaid.js，
   *  显示"点击渲染"占位，用户点击后触发渲染。 */
  enabled?: boolean;
}

/**
 * 可见性检测阈值配置
 */
const INTERSECTION_OPTIONS: IntersectionObserverInit = {
  root: null,
  rootMargin: '100px', // 提前 100px 开始加载
  threshold: 0.1,      // 10% 可见时触发
};

/** 图表容器最大高度样式 */
const CHART_MAX_HEIGHT_STYLE: React.CSSProperties = { maxHeight: '600px' };

/**
 * Mermaid 渲染状态
 */
type RenderState = 'idle' | 'loading' | 'success' | 'error';

/**
 * MermaidDiagram 组件
 *
 * @example
 * ```tsx
 * <MermaidDiagram
 *   code="graph TD\n  A --> B"
 *   id="mermaid-1"
 * />
 * ```
 */
export const MermaidDiagram = memo(function MermaidDiagram({ code, id, enabled = true }: MermaidDiagramProps) {
  const { t } = useTranslation('chat');
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [renderState, setRenderState] = useState<RenderState>('idle');
  const [svg, setSvg] = useState<string>('');
  const [isVisible, setIsVisible] = useState(false); // 是否在视口中可见
  const hasRenderedRef = useRef(false); // 是否已渲染过（避免重复渲染）

  // 组件卸载时清理全局状态，防止内存泄漏
  useEffect(() => {
    return () => removeDiagramState(id);
  }, [id]);

  // 图表交互状态
  const [diagramState, setDiagramState] = useState<DiagramState>(() => getDiagramState(id));
  const [copySuccess, setCopySuccess] = useState(false);

  // 更新状态并持久化
  const updateState = useCallback((updates: Partial<DiagramState>) => {
    setDiagramState(prev => {
      const newState = { ...prev, ...updates };
      saveDiagramState(id, newState);
      return newState;
    });
  }, [id]);

  // ===== 可见性检测 =====
  // enabled=false（performance.mermaidDiagrams 关闭）时不启动自动渲染，
  // 显示"点击渲染"占位，由用户手动触发（避免加载 mermaid.js ~1.5MB）。
  useEffect(() => {
    if (!enabled) return;
    const container = containerRef.current;
    if (!container || hasRenderedRef.current) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !hasRenderedRef.current) {
          setIsVisible(true);
          hasRenderedRef.current = true;
          observer.disconnect();
        }
      });
    }, INTERSECTION_OPTIONS);

    observer.observe(container);

    return () => {
      observer.disconnect();
    };
  }, [enabled]);

  // ===== Mermaid 渲染逻辑（只在可见时执行）=====
  useEffect(() => {
    // 只在可见时才渲染
    if (!isVisible) return;

    let mounted = true;
    let mermaidInstance: any = null;

    const renderDiagram = async () => {
      // 空代码不渲染
      if (!code || !code.trim()) {
        return;
      }

      setRenderState('loading');

      try {
        // 动态导入 mermaid（懒加载）
        const mermaidModule = await import('mermaid');
        mermaidInstance = mermaidModule.default;

        // 检查是否已初始化
        if (!mermaidInstance.isInitialized?.()) {
          const theme = useThemeStore.getState().activeThemeId;
          const config = getMermaidConfig(theme);
          mermaidInstance.initialize(config);
        }

        // 生成唯一 ID（避免多个图表冲突）
        const uniqueId = `mermaid-${id}`;

        // 渲染图表
        const { svg } = await mermaidInstance.render(uniqueId, code);

        if (mounted) {
          setSvg(svg);
          setRenderState('success');
        }
      } catch (err) {
        if (mounted) {
          log.error('Mermaid render error', err instanceof Error ? err : new Error(String(err)));
          setRenderState('error');
          setSvg('');
        }
      }
    };

    renderDiagram();

    return () => {
      mounted = false;
    };
  }, [isVisible, code, id]);

  // ===== 事件处理函数 =====

  // 手动触发渲染（enabled=false 时用户点击"渲染图表"按钮调用）。
  // 复用 isVisible → effect renderDiagram 路径，无需重复实现渲染逻辑。
  const handleRequestRender = useCallback(() => {
    if (hasRenderedRef.current) return;
    hasRenderedRef.current = true;
    setIsVisible(true);
  }, []);

  // 放大
  const handleZoomIn = useCallback(() => {
    updateState({
      scale: Math.min(diagramState.scale + SCALE_CONFIG.step, SCALE_CONFIG.max)
    });
  }, [diagramState.scale, updateState]);

  // 缩小
  const handleZoomOut = useCallback(() => {
    updateState({
      scale: Math.max(diagramState.scale - SCALE_CONFIG.step, SCALE_CONFIG.min)
    });
  }, [diagramState.scale, updateState]);

  // 重置
  const handleReset = useCallback(() => {
    updateState({ scale: SCALE_CONFIG.default });
  }, [updateState]);

  // 鼠标滚轮缩放
  const handleWheel = useCallback((e: React.WheelEvent) => {
    // 只在图表模式且按住 Ctrl/Cmd 时缩放
    if (diagramState.viewMode !== 'chart') return;
    if (!e.ctrlKey && !e.metaKey) return;

    e.preventDefault();
    const delta = e.deltaY > 0 ? -SCALE_CONFIG.step : SCALE_CONFIG.step;
    updateState({
      scale: Math.max(
        SCALE_CONFIG.min,
        Math.min(diagramState.scale + delta, SCALE_CONFIG.max)
      )
    });
  }, [diagramState.viewMode, diagramState.scale, updateState]);

  // 切换视图模式
  const handleToggleView = useCallback((mode: ViewMode) => {
    updateState({ viewMode: mode });
  }, [updateState]);

  // 复制源码
  const handleCopySource = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = code;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  }, [code]);

  // ===== 渲染状态 =====

  // 1. 错误状态
  if (renderState === 'error') {
    return (
      <div className="my-4 p-4 bg-danger-faint border border-danger/30 rounded-lg overflow-auto">
        <div className="flex items-start gap-2">
          {/* 错误图标 */}
          <svg
            className="w-5 h-5 text-danger shrink-0 mt-0.5"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>

          <div className="flex-1 min-w-0">
            <p className="text-sm text-danger font-medium">{t('mermaid.renderFailed')}</p>
            <details className="mt-2">
              <summary className="text-xs text-text-tertiary cursor-pointer hover:text-text-secondary transition-colors">
                {t('mermaid.viewSource')}
              </summary>
              <pre className="mt-2 text-xs text-text-secondary bg-background-base p-3 rounded border border-border-subtle overflow-auto">
                <code>{code}</code>
              </pre>
            </details>
          </div>
        </div>
      </div>
    );
  }

  // 2. 加载状态
  if (renderState === 'loading') {
    return (
      <div className="my-4 p-6 bg-background-surface border border-border-subtle rounded-lg">
        <div className="flex items-center gap-3">
          {/* 加载动画 */}
          <div className="flex gap-1">
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
          <p className="text-sm text-text-tertiary">{t('mermaidStream.generating')}</p>
        </div>
      </div>
    );
  }

  // 3. 成功状态
  if (renderState === 'success' && svg) {
    return (
      <div
        ref={containerRef}
        className="my-4 bg-background-surface border border-border-subtle rounded-lg overflow-hidden"
        onWheel={handleWheel}
      >
        {/* 工具栏 */}
        <div className="flex items-center gap-2 px-3 py-2 bg-background-elevated border-b border-border-subtle">
          {/* 视图切换 Tab */}
          <div className="flex items-center gap-1 bg-background-base rounded-lg p-1">
            <button
              className={`px-3 py-1 text-xs rounded-md transition-all ${
                diagramState.viewMode === 'chart'
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-text-tertiary hover:text-text-secondary hover:bg-background-hover'
              }`}
              onClick={() => handleToggleView('chart')}
            >
              {t('mermaid.chart')}
            </button>
            <button
              className={`px-3 py-1 text-xs rounded-md transition-all ${
                diagramState.viewMode === 'source'
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-text-tertiary hover:text-text-secondary hover:bg-background-hover'
              }`}
              onClick={() => handleToggleView('source')}
            >
              {t('mermaid.source')}
            </button>
          </div>

          {/* 分隔线 */}
          <div className="w-px h-4 bg-border-subtle" />

          {/* 图表模式：缩放控制 */}
          {diagramState.viewMode === 'chart' && (
            <>
              {/* 缩小按钮 */}
              <button
                className="p-1.5 rounded-md hover:bg-background-hover text-text-secondary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleZoomOut}
                disabled={diagramState.scale <= SCALE_CONFIG.min}
                title={t('mermaid.zoomOut')}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                </svg>
              </button>

              {/* 缩放比例显示 */}
              <span className="text-xs text-text-tertiary min-w-[3rem] text-center">
                {Math.round(diagramState.scale * 100)}%
              </span>

              {/* 放大按钮 */}
              <button
                className="p-1.5 rounded-md hover:bg-background-hover text-text-secondary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleZoomIn}
                disabled={diagramState.scale >= SCALE_CONFIG.max}
                title={t('mermaid.zoomIn')}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </button>

              {/* 分隔线 */}
              <div className="w-px h-4 bg-border-subtle" />

              {/* 重置按钮 */}
              <button
                className="px-2 py-1 text-xs rounded-md hover:bg-background-hover text-text-tertiary transition-colors"
                onClick={handleReset}
                disabled={diagramState.scale === SCALE_CONFIG.default}
                title={t('mermaid.resetZoom')}
              >
                {t('mermaid.reset')}
              </button>
            </>
          )}

          {/* 源码模式：复制按钮 */}
          {diagramState.viewMode === 'source' && (
            <button
              className={`px-3 py-1.5 text-xs rounded-md transition-all flex items-center gap-1.5 ${
                copySuccess
                  ? 'bg-success text-white'
                  : 'hover:bg-background-hover text-text-tertiary'
              }`}
              onClick={handleCopySource}
              title={t('mermaid.copySource')}
            >
              {copySuccess ? (
                <>
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  {t('mermaid.copied')}
                </>
              ) : (
                <>
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  {t('mermaid.copy')}
                </>
              )}
            </button>
          )}

          {/* 提示文本 */}
          <div className="ml-auto text-xs text-text-muted">
            {diagramState.viewMode === 'chart' && t('mermaid.wheelZoom', { modKey })}
          </div>
        </div>

        {/* 内容区域 */}
        <div className="p-4">
          {diagramState.viewMode === 'chart' ? (
            /* 图表视图 */
            <div
              ref={contentRef}
              className="overflow-auto"
              style={CHART_MAX_HEIGHT_STYLE}
            >
              <div
                style={{
                  transform: `scale(${diagramState.scale})`,
                  transformOrigin: 'top left',  // 修改：从左上角开始缩放，避免左边被遮挡
                  transition: 'transform 0.2s ease-out',
                  willChange: 'transform',
                  // 补充：设置最小宽度确保容器能随缩放扩展
                  minWidth: `${diagramState.scale * 100}%`,
                }}
              >
                <div dangerouslySetInnerHTML={{ __html: sanitizeMermaidSvg(svg) }} />
              </div>
            </div>
          ) : (
            /* 源码视图 */
            <div className="bg-background-base rounded-lg p-4 overflow-auto max-h-[600px]">
              <pre className="text-sm">
                <code className="text-text-secondary font-mono whitespace-pre-wrap">{code}</code>
              </pre>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 4. 空状态/未可见状态
  //    enabled=false：显示"点击渲染"占位（与 DeferredMermaidDiagram 一致），
  //    不自动加载 mermaid.js；用户点击后触发渲染。
  //    enabled=true 但未可见：纯占位（IntersectionObserver 将触发）。
  if (!enabled) {
    return (
      <div
        ref={containerRef}
        className="my-4 bg-background-surface border border-border-subtle rounded-lg overflow-hidden"
      >
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-text-tertiary">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span className="text-sm">{t('mermaid.diagram', '图表')}</span>
            </div>
            <button
              onClick={handleRequestRender}
              className="px-3 py-1.5 text-xs bg-primary/10 hover:bg-primary/20 text-primary rounded-md transition-colors flex items-center gap-1.5"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {t('mermaid.clickToRender', '渲染图表')}
            </button>
          </div>
          <details className="mt-3">
            <summary className="text-xs text-text-quaternary cursor-pointer hover:text-text-tertiary transition-colors">
              {t('mermaid.viewSourceCode', '查看源代码')}
            </summary>
            <pre className="mt-2 text-xs text-text-secondary bg-background-base p-2 rounded border border-border-subtle overflow-auto max-h-[200px]">
              <code className="font-mono whitespace-pre-wrap">{code}</code>
            </pre>
          </details>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="my-4 p-6 bg-background-surface border border-border-subtle rounded-lg"
    >
      <div className="flex items-center justify-center gap-3">
        <svg className="w-5 h-5 text-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <span className="text-sm text-text-tertiary">{t('mermaid.deferredRender')}</span>
      </div>
    </div>
  );
}, (prevProps, nextProps) => {
  // 自定义比较：在 code / id / enabled 变化时重新渲染
  // （enabled 加入比较维度，确保 performance.mermaidDiagrams 开关切换时组件重渲染）
  return (
    prevProps.code === nextProps.code &&
    prevProps.id === nextProps.id &&
    prevProps.enabled === nextProps.enabled
  );
});
