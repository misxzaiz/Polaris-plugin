/**
 * 思考过程块渲染器 - 呼吸光晕风格
 *
 * 设计：
 * - 蓝色调边框 + 微光呼吸动画
 * - 脉冲小圆点指示器
 * - 流式打字光标
 * - 流式结束后自动折叠，展示内容预览
 */

import { memo, useState, useEffect, useRef } from 'react';
import { Brain, ChevronDown } from 'lucide-react';
import { clsx } from 'clsx';
import type { ThinkingBlock } from '@/types';

export const ThinkingBlockRenderer = memo(function ThinkingBlockRenderer({
  block,
  isStreaming = false,
  compact = false,
}: {
  block: ThinkingBlock;
  isStreaming?: boolean;
  /** 精炼模式：供补充卡片段落列表使用，去掉呼吸光晕卡片壳，保留折叠/预览/展开逻辑 */
  compact?: boolean;
}) {
  // 流式期间展开显示思考内容，结束后折叠
  const [isCollapsed, setIsCollapsed] = useState(() => {
    if (block.collapsed !== undefined) return block.collapsed;
    return !isStreaming;
  });

  // 流式结束时自动折叠
  useEffect(() => {
    if (!isStreaming) {
      setIsCollapsed(true);
    }
  }, [isStreaming]);

  // store 标记思考完成（collapsed=true）时自动折叠。
  // 触发时机：正文/tool_call 开始出现或整条消息归档（见 createConversationStore.foldThinkingBlocks）。
  useEffect(() => {
    if (block.collapsed === true) {
      setIsCollapsed(true);
    }
  }, [block.collapsed]);

  // 展开态内容容器：限高滚动 + 流式期间"钉在底部才自动滚"（用户上滑回溯时不被拉走）
  const bodyRef = useRef<HTMLDivElement>(null);
  const [pinnedToBottom, setPinnedToBottom] = useState(true);

  // 用户滚动展开区时重新判定是否在底部（24px 容差）
  const handleBodyScroll = () => {
    const el = bodyRef.current;
    if (!el) return;
    setPinnedToBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 24);
  };

  // 流式内容增长：仅在用户仍钉在底部时跟随滚动
  useEffect(() => {
    if (!isStreaming || !pinnedToBottom) return;
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [block.content, isStreaming, pinnedToBottom]);

  // 折叠时预览文本（内容前 60 字）
  const previewText = block.content.length > 60
    ? block.content.slice(0, 60) + '...'
    : block.content;

  return (
    <>
      <div
        className={
          compact
            ? 'border-b border-border last:border-b-0'
            : `my-2 rounded-lg overflow-hidden border transition-colors bg-background-surface ${
                isStreaming
                  ? 'bg-background-base thinking-streaming'
                  : 'border-border bg-background-elevated'
              }`
        }
        style={!compact && isStreaming ? {
          borderColor: 'rgba(59, 130, 246, 0.15)',
        } : {}}
      >
        {/* 头部 - 可点击折叠 */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={clsx(
            'w-full flex items-center gap-2 text-left hover:bg-white/[0.03] transition-colors',
            compact ? 'px-3 py-2 min-h-[44px]' : 'px-3 py-2'
          )}
        >
          {/* 脉冲圆点 */}
          {isStreaming && (
            <span
              className="w-[7px] h-[7px] rounded-full shrink-0 bg-primary/60"
              style={{ animation: 'think-dot 1.5s ease-in-out infinite' }}
            />
          )}

          <Brain className="w-4 h-4 text-primary/60 shrink-0" />

          {/* 流式中显示「思考中」，完成后显示「已思考」——此前无条件显示「思考中」，
              历史消息里已完成的思考块让用户误以为还在想（审计 5.11） */}
          <span className="text-xs font-medium text-primary/70">
            {isStreaming ? '思考中' : '已思考'}
          </span>

          {/* 展开/折叠箭头 */}
          <ChevronDown
            className={`ml-auto w-3.5 h-3.5 text-text-muted transition-transform duration-200 ${
              !isCollapsed ? 'rotate-180' : ''
            }`}
          />
        </button>

        {/* 折叠时显示预览 */}
        {isCollapsed && previewText && (
          <div className="px-3 pb-2 pl-9">
            <p className="text-xs text-text-tertiary truncate leading-relaxed">
              {previewText}
            </p>
          </div>
        )}

        {/* 展开时显示完整内容（限高滚动） */}
        {!isCollapsed && (
          <div className="px-3 pb-2.5 pl-9 border-t border-white/5 pt-2">
            <div
              ref={bodyRef}
              onScroll={handleBodyScroll}
              onWheel={(e) => e.stopPropagation()}
              className="max-h-[40vh] overflow-y-auto overscroll-contain pr-1 text-sm text-text-secondary whitespace-pre-wrap break-words leading-relaxed"
            >
              {block.content}
              {/* 流式打字光标 */}
              {isStreaming && (
                <span className="inline-block w-[2px] h-[15px] bg-primary/60 ml-0.5 align-text-bottom animate-pulse" />
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
});