import { generateUUID } from '@/utils/uuid';
/**
 * SessionStoreManager 实现
 *
 * 管理多个会话 Store 实例，支持：
 * - 会话创建、删除、切换
 * - 事件路由（按 sessionId）
 * - 后台运行管理
 */

import { createStore, useStore } from 'zustand'
import type { AIEvent } from '@/ai-runtime'
import type {
  ConversationStore,
  ConversationStoreInstance,
  SessionManagerState,
  SessionManagerActions,
  SessionMetadata,
  CreateSessionOptions,
  StoreDeps,
} from './types'
import { createConversationStore } from './createConversationStore'
import { getEventRouter } from '@/services/eventRouter'
import { useConfigStore } from '../../shims/stores'
import { getEventBus } from '@/ai-runtime'
import { useWorkspaceStore } from '../../shims/stores'
import { useViewStore } from '../../shims/stores'
import { createLogger } from '@/utils/logger'
import { normalizeEngineId } from '@/utils/engineDisplay'
import { useSessionConfig } from '../../shims/stores'
import { OFFICIAL_API_PROFILE } from '@/types/modelProfile'

const log = createLogger('SessionStoreManager')

// ============================================================================
// 受保护会话（AI-1 驱逐豁免 · 规范先于事实）
// ============================================================================
//
// master-plan AI-1 / C12 预防性修复：本管理器**目前没有**任何 LRU 或数量上限
// 驱逐策略（会话只在 deleteSession 显式删除时销毁）。这是当前事实，不是设计
// 保障。未来任何引入「按数量驱逐 / 后台超时回收 / store 数量上限」的改动，
// 必须先查询 isProtectedSession —— 受保护 kind（面向 GitPanel 等功能面板的
// 挂载型会话）被静默回收会直接破坏「回流锚点」订阅（建议条失效、用户视角的
// AI 输出丢失），属于不可接受的隐性故障。
//
// 新增受保护 kind 时在此登记；新增驱逐逻辑时必须消费本函数。

const PROTECTED_SESSION_KINDS: ReadonlySet<NonNullable<SessionMetadata['kind']>> = new Set([
  'commit-message',
  'git-atomic',
])

/** 该会话是否受驱逐豁免保护（未来任何回收策略前必查） */
export function isProtectedSession(metadata: SessionMetadata | undefined): boolean {
  return !!metadata && !!metadata.kind && PROTECTED_SESSION_KINDS.has(metadata.kind)
}

/**
 * 实体渲染事件白名单（单一权威，EventRouter 同款语义引用本常量）：
 * 外部入口（MCP bridge 经 cap.ui.render 等调用）的这类事件不承载
 * 会话主体逻辑，只驱动卡片渲染 / 回答回写——路由 miss 或无路由 ID 时允许兜底投递
 * 到当前活跃会话。其余事件保持丢弃语义，避免重新引入「回退 activeSessionId」的
 * 历史根因（见对不准窗口/新开窗口旧 bug）。
 */
export const RENDER_EVENT_TYPES: ReadonlySet<string> = new Set(['plugin_card', 'plugin_card_answered'])

// ============================================================================
// Manager Store Type
// ============================================================================

type SessionManagerStore = SessionManagerState & SessionManagerActions

// ============================================================================
// Manager Store 创建
// ============================================================================

/**
 * 创建 SessionStoreManager store
 */
function createSessionManagerStore() {
  return createStore<SessionManagerStore>((set, get) => ({
    // ===== 状态 =====
    stores: new Map<string, ConversationStoreInstance>(),
    activeSessionId: null,
    sessionMetadata: new Map<string, SessionMetadata>(),
    backgroundSessionIds: [],
    completedNotifications: [],
    isInitialized: false,

    // ===== 会话生命周期 =====

    createSession: (options: CreateSessionOptions) => {
      // 使用指定的 ID 或生成新的 UUID
      const sessionId = options.id || generateUUID()
      const timestamp = new Date().toISOString()

      log.info('createSession 调用', { sessionId, optionsWorkspaceId: options.workspaceId, optionsType: options.type, optionsTitle: options.title, engineId: options.engineId })

      // 检查会话是否已存在
      if (get().stores.has(sessionId)) {
        log.info('会话已存在', { sessionId })
        return sessionId
      }

      // 创建元数据
      const configEngineId = useConfigStore.getState().config?.defaultEngine
      const metadata: SessionMetadata = {
        id: sessionId,
        title: options.title || `新对话 ${get().stores.size + 1}`,
        type: options.type,
        engineId: normalizeEngineId(options.engineId || configEngineId),
        workspaceId: options.workspaceId || null,
        contextWorkspaceIds: options.contextWorkspaceIds || [],
        workspaceLocked: options.workspaceLocked ?? (!!options.workspaceId),
        status: 'idle',
        silentMode: options.silentMode || false, // 设置静默模式
        createdAt: timestamp,
        updatedAt: timestamp,
        forkFromId: options.forkFromId,
        modelProfileId: options.modelProfileId,
        model: options.model,
        profileMode: options.profileMode,
        agent: options.agent,
        effort: options.effort,
        permissionMode: options.permissionMode,
        kind: options.kind,
        commitWorkspaceId: options.commitWorkspaceId,
      }

      log.info('创建会话元数据', { sessionId, metadataWorkspaceId: metadata.workspaceId, metadataType: metadata.type, engineId: metadata.engineId })

      // 构建依赖注入
      const contextId = `session-${sessionId}`
      const deps: StoreDeps = {
        getConfig: () => {
          const state = useConfigStore.getState()
          return state.config as { defaultEngine?: string } | null
        },
        getWorkspace: () => {
          // 获取【当前会话】的工作区
          // 优先级：metadata.workspaceId（支持用户后续更新）> 初始 options.workspaceId
          // 注意：这里使用创建时绑定的 sessionId，而不是 activeSessionId
          // 确保每个会话使用自己的工作区，不受会话切换影响
          const workspaceState = useWorkspaceStore.getState()

          // 优先从 metadata 获取（支持用户通过 WorkspaceMenu 等更新工作区）
          const managerState = get()
          const metadata = managerState.sessionMetadata.get(sessionId)

          // 确定要使用的 workspaceId：优先 metadata，其次初始值
          // 这避免了竞态问题：metadata 不存在时用初始值，存在时用更新后的值
          const targetWorkspaceId = metadata?.workspaceId || options.workspaceId

          if (targetWorkspaceId) {
            const workspace = workspaceState.workspaces.find(w => w.id === targetWorkspaceId)
            if (workspace) {
              return workspace
            }
          }

          // 自由会话（无显式绑定）不静默回退全局工作区：
          // 全局工作区是"行为与展示不一致"的漂移源（UI 标签显示无工作区，实际却注入全局 workDir + 系统提示词）。
          // free 会话应语义上就是"无工作区"。有显式绑定的会话（project）已在上方命中返回。
          // 历史恢复（createSessionFromHistory）的 free 会话本质上仍是自由会话语义，同样不回退。
          if (metadata?.type === 'free') {
            return null
          }

          // 回退到全局工作区（仅非 free 会话，如默认会话/旧数据）
          return workspaceState.getCurrentWorkspace()
        },
        getContextWorkspaceIds: () => {
          // 获取当前会话的关联工作区 ID 列表
          const managerState = get()
          const metadata = managerState.sessionMetadata.get(sessionId)
          return metadata?.contextWorkspaceIds || []
        },
        getAllWorkspaces: () => {
          return useWorkspaceStore.getState().workspaces
        },
        getEventRouter: () => getEventRouter(),
        contextId,
      }

      // 创建独立的 ConversationStore（注入依赖）
      const conversationStore = createConversationStore(sessionId, deps)

      set((state) => {
        const newStores = new Map(state.stores)
        newStores.set(sessionId, conversationStore)

        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, metadata)

        return {
          stores: newStores,
          sessionMetadata: newMetadata,
          // 静默会话不自动激活
          activeSessionId: options.silentMode ? state.activeSessionId : sessionId,
        }
      })

      // 同步 ConversationStore 的 workspaceId（与 updateSessionWorkspace 行为对齐）。
      // createInitialState 硬编码 workspaceId: null，若不在这里同步，
      // useActiveSessionWorkspace() 对任何新建会话恒返回 null，
      // 会话级工作区感知（ChatInput 内嵌等）从创建起就是失效的。
      conversationStore.setState({ workspaceId: metadata.workspaceId })

      log.info('创建会话', { sessionId })

      // 非静默模式时自动加入多窗口视图
      if (!options.silentMode) {
        useViewStore.getState().addToMultiView(sessionId)
      }

      return sessionId
    },

    createSessionFromHistory: (messages, conversationId, metadata) => {
      // 创建新会话
      const sessionId = get().createSession({
        type: metadata?.workspaceId ? 'project' : 'free',
        workspaceId: metadata?.workspaceId,
        title: metadata?.title || `历史会话 ${get().stores.size + 1}`,
        forkFromId: metadata?.forkFromId,
        engineId: metadata?.engineId,
      })

      // 获取新创建的 Store 并设置历史消息（paging 非空 = 尾部优先分页恢复）
      const store = get().stores.get(sessionId)
      if (store) {
        store.getState().setMessagesFromHistory(messages, conversationId, metadata?.paging)
        log.info('从历史创建会话', { sessionId, messageCount: messages.length, conversationId, forkFromId: metadata?.forkFromId })
      }

      return sessionId
    },

    deleteSession: (sessionId: string) => {
      const state = get()
      const store = state.stores.get(sessionId)

      if (!store) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // B1.f（审计 2.8/2.2）：销毁内存的同时清理磁盘——此前只销毁内存，
      // JSONL 与后端消息库不删：一次性静默会话残留为历史垃圾条目；
      // 流式中的会话被后端 turn_persist 重建「复活」。best-effort，
      // 失败仅告警（磁盘残留可由用户从历史面板再删）。
      const conversationId = store.getState().conversationId
      if (conversationId) {
        void (async () => {
          try {
            const { dialogStorageService } = await import('@/services/dialogStorage')
            await dialogStorageService.deleteConversation(conversationId)
          } catch (e) {
            log.warn('删除会话 JSONL 失败', { conversationId, error: String(e) })
          }
          try {
            const { invoke } = await import('@/services/transport')
            await invoke('message_delete_by_conversation', { conversationId })
          } catch (e) {
            log.warn('删除后端会话消息失败', { conversationId, error: String(e) })
          }
        })()
      }

      // 清理资源
      store.getState().dispose()

      set((state) => {
        const newStores = new Map(state.stores)
        newStores.delete(sessionId)

        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.delete(sessionId)

        const newBackgroundSessionIds = state.backgroundSessionIds.filter(
          (id) => id !== sessionId
        )
        const newCompletedNotifications = state.completedNotifications.filter(
          (id) => id !== sessionId
        )

        // 如果删除的是当前活跃会话，需要切换
        let newActiveSessionId = state.activeSessionId
        if (state.activeSessionId === sessionId) {
          // 尝试切换到最近一个会话
          const remainingIds = Array.from(newStores.keys())
          newActiveSessionId = remainingIds.length > 0 ? remainingIds[remainingIds.length - 1] : null
        }

        return {
          stores: newStores,
          sessionMetadata: newMetadata,
          backgroundSessionIds: newBackgroundSessionIds,
          completedNotifications: newCompletedNotifications,
          activeSessionId: newActiveSessionId,
        }
      })

      // 同步从多窗口视图移除
      useViewStore.getState().removeFromMultiView(sessionId)

      log.info('删除会话', { sessionId })
    },

    switchSession: (sessionId: string) => {
      const state = get()
      const store = state.stores.get(sessionId)

      if (!store) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // 当前活跃会话如果正在 streaming，移入后台（单路径：本地快照）。
      // 删除原异步 kernel 复核：它引入竞态（切换完成后异步回调仍用旧 prevActiveId）。
      const currentStore = state.activeSessionId
        ? state.stores.get(state.activeSessionId)
        : null

      if (currentStore && currentStore.getState().isStreaming && state.activeSessionId) {
        get().addToBackground(state.activeSessionId)
      }

      // 切换到新会话
      set({ activeSessionId: sessionId })

      // 如果新会话在后台运行列表中，移出（用户主动切换回来了）
      get().removeFromBackground(sessionId)

      // 多窗口模式协调：确保目标会话在网格中，并请求滚动
      const viewState = useViewStore.getState()
      viewState.addToMultiView(sessionId)
      viewState.requestScrollToSession(sessionId)

      // P1: 切换会话时，把该会话的生效 Profile 与模型同步到状态栏镜像。
      // 生效值 = 会话覆盖 ?? 全局默认；这样无覆盖会话显示并使用全局默认，与发送逻辑一致。
      const targetMetadata = get().sessionMetadata.get(sessionId)
      if (targetMetadata) {
        const globalDefault = useConfigStore.getState().config?.activeModelProfileId
        // 会话明确选官方（哨兵）→ 镜像置空串（状态栏高亮「官方 API」项，且不把哨兵写入镜像）；
        // 有具体覆盖 → 原样；未设置(undefined) → 跟随全局默认。
        const sessionOverride = targetMetadata.modelProfileId
        const mirror = sessionOverride === OFFICIAL_API_PROFILE
          ? ''
          : (sessionOverride ?? globalDefault ?? '')
        useSessionConfig.getState().setModelProfileId(mirror)

        // 全局供应商模式默认（此时镜像尚未被 setProfileMode 覆盖）。
        // 注意不要在 profileMode 镜像时再读已覆盖后的 config，语义会串。
        const globalProfileMode = useSessionConfig.getState().config.profileMode ?? 'profile'

        // 会话级模型镜像：有覆盖时用之，未设置时清空（让状态栏反映全局默认）。
        useSessionConfig.getState().setModel(targetMetadata.model ?? '')

        // 会话级专家镜像：有覆盖时用之，未设置时清空（让状态栏反映无专家）。
        useSessionConfig.getState().setAgent(targetMetadata.agent ?? '')

        // P2: 会话级供应商模式镜像：有会话级覆盖时用之；未设置时回退全局默认。
        // 与 modelProfileId 二态（会话覆盖 > 镜像 > 全局默认）一致。
        // 注意：必须先读全局默认（此时 setProfileMode 尚未覆盖镜像）。
        useSessionConfig.getState().setProfileMode(
          targetMetadata.profileMode ?? globalProfileMode,
        )
      }

      log.info('切换会话', { sessionId })
    },

    updateSessionTitle: (sessionId: string, title: string) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // 更新元数据标题
      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          title,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话标题', { sessionId, title })
    },

    updateSessionEngine: (sessionId, engineId) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return false
      }

      const store = get().stores.get(sessionId)?.getState()
      if (store && (store.isStreaming || store.conversationId || store.messages.length > 0)) {
        log.warn('已有内容的会话不允许切换引擎', {
          sessionId,
          isStreaming: store.isStreaming,
          hasConversationId: Boolean(store.conversationId),
          messageCount: store.messages.length,
        })
        return false
      }

      const normalizedEngineId = normalizeEngineId(engineId)
      if (normalizeEngineId(metadata.engineId) === normalizedEngineId) {
        return true
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          engineId: normalizedEngineId,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话引擎', { sessionId, engineId: normalizedEngineId })
      return true
    },

    updateSessionModelProfile: (sessionId, modelProfileId) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          // null = 清除会话级覆盖（→ 跟随全局默认）；字符串（含官方哨兵）原样保留。
          // 用 ?? 而非 ||：只把 null/undefined 当「清除」，避免误伤有意义的值。
          modelProfileId: modelProfileId ?? undefined,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话 Profile', { sessionId, modelProfileId })
    },

    updateSessionProfileMode: (sessionId, profileMode) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          // null/undefined = 清除会话级覆盖（→ 跟随全局默认）；二态值原样写入。
          profileMode: profileMode ?? undefined,
          // official 不绑定单 Profile：同步清掉会话级 Profile 覆盖，避免残留穿透。
          ...((profileMode === 'official')
            ? { modelProfileId: undefined }
            : {}),
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话供应商模式', { sessionId, profileMode })
    },

    updateSessionModel: (sessionId, model) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          // null = 清除会话级覆盖（→ 跟随全局默认）；字符串（含空串）原样保留。
          // 用 ?? 而非 ||：只把 null/undefined 当「清除」，避免误伤有意义的值。
          model: model ?? undefined,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话模型', { sessionId, model })
    },

    updateSessionAgent: (sessionId, agent) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          // null / 空串 = 清除会话级专家覆盖；非空字符串原样保留。
          agent: agent && agent.length > 0 ? agent : undefined,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      log.info('更新会话专家', { sessionId, agent })
    },

    makeSessionVisible: (sessionId: string) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // 如果已经是可见会话，直接切换
      if (!metadata.silentMode) {
        get().switchSession(sessionId)
        return
      }

      // 更新元数据，移除静默模式标志
      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, {
          ...metadata,
          silentMode: false,
          updatedAt: new Date().toISOString(),
        })
        return { sessionMetadata: newMetadata }
      })

      // 切换到该会话
      get().switchSession(sessionId)

      log.info('会话已转为可见', { sessionId })
    },

    // ===== Store 访问 =====

    getStore: (sessionId: string) => {
      return get().stores.get(sessionId)?.getState()
    },

    getActiveStore: () => {
      const sessionId = get().activeSessionId
      if (!sessionId) return undefined
      return get().stores.get(sessionId)?.getState()
    },

    getActiveSessionId: () => {
      return get().activeSessionId
    },

    // ===== 事件分发 =====

    dispatchEvent: (event: AIEvent & { sessionId?: string; _routeSessionId?: string; _turnId?: string }) => {
      // 单一路由路径：_routeSessionId 是前端 sessionId（由 EventRouter 从 contextId 解析注入）。
      // 不再用 event.sessionId（后端 conversationId）兜底，不再回退 activeSessionId，
      // 不再"找不到 store 就自动建会话"——这三条正是"对不准窗口/新开窗口"的根因。
      // 例外：实体渲染事件白名单（RENDER_EVENT_TYPES）不承载会话主体逻辑，允许兜底。
      let targetSessionId: string
      const routeSessionId = event._routeSessionId
      if (!routeSessionId) {
        // 无路由 ID：仅渲染白名单放行——cap.ui.render sessionId 可不填（不填 = 「未路由」
        // 显式语义，spec cap-ui-render-sessionid-optional），直接投递到当前活跃会话。
        // 空 sessionId 永不参与 conversationId 反查，消除乱填撞上真实会话误投的隐患。
        // 其余事件保持丢弃语义不变。
        if (!RENDER_EVENT_TYPES.has(event.type)) {
          log.warn('事件缺少 _routeSessionId，丢弃', { type: event.type })
          return
        }
        const activeId = get().activeSessionId
        const activeStore = activeId ? get().stores.get(activeId) : undefined
        if (!activeId || !activeStore) {
          log.warn('渲染事件无路由 ID 且无活跃会话，丢弃', { type: event.type })
          return
        }
        log.info('渲染事件无路由 ID（sessionId 未填），投递到活跃会话', {
          target: activeId,
          type: event.type,
        })
        targetSessionId = activeId
      } else {
        const store = get().stores.get(routeSessionId)
        // 实际投递目标 sessionId（未兜底 = routeSessionId；兜底 = 活跃会话）
        targetSessionId = routeSessionId
        if (!store) {
          if (RENDER_EVENT_TYPES.has(event.type)) {
            // 渲染卡片事件：优先 conversationId 精确反查；查不到才活跃会话兜底
            // （批 5 收敛：外部入口卡片优先回到来源会话，跨端不再误投活跃会话）
            const conversationId = (event as { sessionId?: string }).sessionId
            const entry = conversationId
              ? [...get().stores.entries()].find(
                  ([, s]) => s.getState().conversationId === conversationId,
                )
              : undefined
            if (entry) {
              log.info('渲染事件按 conversationId 反查投递', {
                routeSessionId,
                target: entry[0],
                type: event.type,
              })
              targetSessionId = entry[0]
            } else {
              const activeId = get().activeSessionId
              const activeStore = activeId ? get().stores.get(activeId) : undefined
              if (activeId && activeStore) {
                log.warn('渲染事件未匹配到原始会话，兜底投递到活跃会话', {
                  routeSessionId,
                  fallback: activeId,
                  type: event.type,
                })
                targetSessionId = activeId
              } else {
                log.warn('渲染事件未匹配到会话且无活跃会话，丢弃', { routeSessionId, type: event.type })
                return
              }
            }
          } else {
            // 批 5（审计 1.1 根因 / 裁决方案 M4）：跨端事件路由。事件的 contextId
            // 是**发起端**的本地 UUID（对不上本端键），但 payload.sessionId 是引擎
            // conversationId（跨端同构）——按其反查本端持有该会话的 store 精确投递。
            // 两端从历史恢复同一会话后，任一端发起的流式双方都能渲染。
            // 语义安全：只在「确有会话持有该 conversationId」时投递（精确匹配，
            // 不触碰「回退 activeSessionId」旧根因）；无 sessionId 或查不到才丢弃。
            const conversationId = (event as { sessionId?: string }).sessionId
            const entry = conversationId
              ? [...get().stores.entries()].find(
                  ([, s]) => s.getState().conversationId === conversationId,
                )
              : undefined
            if (entry) {
              targetSessionId = entry[0]
            } else {
              // store 不存在 = 前端尚未创建该会话（用户从未打开 / 已删除）。
              // 事件丢弃，由前端主动创建会话后再发起新一轮对话。
              log.warn('事件未匹配到会话，丢弃', { routeSessionId, type: event.type })
              return
            }
          }
        }
      }

      const targetStore = get().stores.get(targetSessionId)
      if (!targetStore) {
        // 理论不可达（非白名单事件在此前已 return，白名单兜底已确认 activeStore 存在），防御性丢弃
        log.warn('事件投递失败：目标会话 store 不存在', { targetSessionId, type: event.type })
        return
      }

      // 轮次代际过滤（spec F1）：后端信封 turnId 标识事件所属轮次，store.activeTurnId
      // 随最新非终态事件推进。终态事件（session_end/error）的 turnId 落后于 activeTurnId
      // = 旧轮迟到终态（典型：中断兜底超时后新一轮已开跑，旧轮才真正退出并发
      // SessionEnd）——整事件丢弃，防止误杀新轮流式态与翻转元数据 status。
      // 仅在事件带 _turnId 时过滤：scheduler/dispatch 直投与测试无此字段，语义不变。
      const turnId = (event as { _turnId?: string })._turnId
      if (turnId && !targetStore.getState().observeTurnEvent(turnId, event.type)) {
        log.info('旧轮次迟到的终态事件已丢弃', { targetSessionId, type: event.type, turnId })
        return
      }

      targetStore.getState().handleAIEvent(event)

      // B3b（审计 1.6）：session_start 到达时把会话注册进后端 sessions_index 投影
      // （该表已有刷新机制但此前零注册方——孤儿资产）。投影是批 5 跨端会话列表
      // 的数据底座；workspace_key 暂用 default 桶（分桶属 B5）。静默会话不注册
      // （不进任何列表）。fire-and-forget，失败不阻断。
      if (event.type === 'session_start') {
        const meta = get().sessionMetadata.get(targetSessionId)
        if (meta && !meta.silentMode) {
          const conversationId = (event as { sessionId?: string }).sessionId
          void import('@/services/transport')
            .then(({ invoke }) =>
              invoke('session_index_register', {
                workspaceKey: 'default',
                record: {
                  id: targetSessionId,
                  conversationId: conversationId ?? null,
                  title: meta.title ?? '',
                  engineId: meta.engineId ?? '',
                  workspaceId: meta.workspaceId ?? null,
                  contextWorkspaceIds: meta.contextWorkspaceIds ?? [],
                  type: meta.type ?? 'free',
                  silentMode: false,
                  messageIds: [],
                  version: 1,
                  createdAt: Date.now(),
                  updatedAt: Date.now(),
                },
              }),
            )
            .catch(() => { /* 投影注册失败不阻断会话；批 5 接列表消费时再上报告警 */ })
        }
      }

      // 补发到 EventBus，确保 DeveloperPanel 等订阅者能收到事件
      try {
        getEventBus().emit(event)
      } catch (e) {
        log.warn('EventBus emit 失败', { error: String(e) })
      }

      // 更新元数据状态（仅在 status 实际变化时创建新 Map，避免高频事件下无谓重建）
      // 兜底投递时用 targetSessionId（活跃会话）；正常路径 targetSessionId === routeSessionId，语义不变。
      const metadata = get().sessionMetadata.get(targetSessionId)
      if (metadata) {
        let newStatus: SessionMetadata['status'] = metadata.status

        if (event.type === 'session_start') {
          newStatus = 'running'
        } else if (event.type === 'session_end') {
          newStatus = 'idle'

          // 如果是后台运行的会话，添加通知
          if (get().backgroundSessionIds.includes(targetSessionId)) {
            get().addToNotifications(targetSessionId)
            get().removeFromBackground(targetSessionId)

            // 触发 Toast 通知
            const sessionMetadata = get().sessionMetadata.get(targetSessionId)
            if (sessionMetadata) {
              // 动态导入 toastStore 避免循环依赖
              import('@/stores/toastStore').then(({ useToastStore }) => {
                useToastStore.getState().sessionComplete(
                  sessionMetadata.title,
                  targetSessionId,
                  () => get().switchSession(targetSessionId)
                )
              })
            }
          }
        } else if (event.type === 'error') {
          // 批 4d（审计 4.11）：用户主动中断时后端 fallback 会发 error 事件，
          // eventHandler 已按 isInterrupting 静默处理；元数据侧同步判定——
          // 否则会话列表/标签显示「错误」徽标而聊天区无任何错误提示，自相矛盾。
          const isUserInterrupt =
            get().stores.get(targetSessionId)?.getState().isInterrupting === true
          newStatus = isUserInterrupt ? 'idle' : 'error'
        }

        if (newStatus !== metadata.status) {
          set((state) => {
            const newMetadata = new Map(state.sessionMetadata)
            newMetadata.set(targetSessionId, { ...metadata, status: newStatus, updatedAt: new Date().toISOString() })
            return { sessionMetadata: newMetadata }
          })
        }
      }
    },

    // ===== 后台运行管理 =====

    addToBackground: (sessionId: string) => {
      set((state) => {
        if (state.backgroundSessionIds.includes(sessionId)) {
          return state
        }
        return {
          backgroundSessionIds: [...state.backgroundSessionIds, sessionId],
        }
      })

      // 更新元数据状态
      const metadata = get().sessionMetadata.get(sessionId)
      if (metadata) {
        set((state) => {
          const newMetadata = new Map(state.sessionMetadata)
          newMetadata.set(sessionId, { ...metadata, status: 'background-running' })
          return { sessionMetadata: newMetadata }
        })
      }

      log.info('会话进入后台', { sessionId })
    },

    removeFromBackground: (sessionId: string) => {
      set((state) => ({
        backgroundSessionIds: state.backgroundSessionIds.filter((id) => id !== sessionId),
      }))
    },

    addToNotifications: (sessionId: string) => {
      set((state) => {
        if (state.completedNotifications.includes(sessionId)) {
          return state
        }
        return {
          completedNotifications: [...state.completedNotifications, sessionId],
        }
      })
    },

    removeFromNotifications: (sessionId: string) => {
      set((state) => ({
        completedNotifications: state.completedNotifications.filter((id) => id !== sessionId),
      }))
    },

    // ===== 批量操作 =====

    interruptSession: async (sessionId: string) => {
      const store = get().stores.get(sessionId)
      if (!store) {
        log.warn('interruptSession: 会话不存在', { sessionId })
        return
      }

      const state = store.getState()
      log.info('interruptSession', { frontendSessionId: sessionId, backendConversationId: state.conversationId, isStreaming: state.isStreaming })

      try {
        await state.interrupt()
      } catch (e) {
        log.error('打断会话失败', e instanceof Error ? e : new Error(String(e)), { sessionId })
      }
    },

    // ===== 工作区管理 =====

    updateSessionWorkspace: (sessionId: string, workspaceId: string | null) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      log.info('updateSessionWorkspace 调用', { sessionId, newWorkspaceId: workspaceId, oldWorkspaceId: metadata.workspaceId })

      // 获取工作区名称
      let workspaceName: string | undefined
      if (workspaceId) {
        const workspace = useWorkspaceStore.getState().workspaces.find(w => w.id === workspaceId)
        workspaceName = workspace?.name
        log.info('找到工作区', { workspaceId, workspaceName, workspacePath: workspace?.path })
      }

      // 更新 SessionMetadata
      const updatedMetadata: SessionMetadata = {
        ...metadata,
        workspaceId,
        workspaceName,
        type: workspaceId ? 'project' : 'free',
        // 解除主工作区 = 解锁（转为自由会话，允许再次绑定）
        workspaceLocked: workspaceId === null ? false : metadata.workspaceLocked,
        updatedAt: new Date().toISOString(),
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, updatedMetadata)
        return { sessionMetadata: newMetadata }
      })

      // 更新 ConversationStore
      const store = get().stores.get(sessionId)
      if (store) {
        store.setState({ workspaceId })
      }

      log.info('更新会话工作区完成', { sessionId, workspaceId })
    },

    addContextWorkspace: (sessionId: string, workspaceId: string) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // 防止重复添加
      if (metadata.contextWorkspaceIds.includes(workspaceId)) {
        return
      }

      // 更新 SessionMetadata
      const updatedMetadata: SessionMetadata = {
        ...metadata,
        contextWorkspaceIds: [...metadata.contextWorkspaceIds, workspaceId],
        updatedAt: new Date().toISOString(),
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, updatedMetadata)
        return { sessionMetadata: newMetadata }
      })

      log.info('添加关联工作区', { sessionId, workspaceId })
    },

    removeContextWorkspace: (sessionId: string, workspaceId: string) => {
      const metadata = get().sessionMetadata.get(sessionId)
      if (!metadata) {
        log.warn('会话不存在', { sessionId })
        return
      }

      // 更新 SessionMetadata
      const updatedMetadata: SessionMetadata = {
        ...metadata,
        contextWorkspaceIds: metadata.contextWorkspaceIds.filter(id => id !== workspaceId),
        updatedAt: new Date().toISOString(),
      }

      set((state) => {
        const newMetadata = new Map(state.sessionMetadata)
        newMetadata.set(sessionId, updatedMetadata)
        return { sessionMetadata: newMetadata }
      })

      log.info('移除关联工作区', { sessionId, workspaceId })
    },

    // ===== 初始化 =====

    initialize: async () => {
      const state = get()

      // 如果没有会话，创建默认会话
      if (state.stores.size === 0) {
        // 有全局工作区时，默认会话绑定全局工作区（project 语义）；
        // 无全局工作区时创建自由会话（free，不强制工作区）。
        const currentWorkspace = useWorkspaceStore.getState().getCurrentWorkspace()
        get().createSession(
          currentWorkspace
            ? {
                type: 'project',
                title: '新对话',
                workspaceId: currentWorkspace.id,
                workspaceLocked: false,
              }
            : {
                type: 'free',
                title: '新对话',
              }
        )
        log.info('已创建默认会话')
      }

      set({ isInitialized: true })
      log.info('初始化完成')
    },
  }))
}

// ============================================================================
// 全局单例
// ============================================================================

/**
 * 全局 SessionStoreManager store 实例
 */
export const sessionStoreManager = createSessionManagerStore()

/**
 * 缓存的 actions 对象，确保引用稳定
 */
const cachedActions = {
  get createSession() { return sessionStoreManager.getState().createSession },
  get deleteSession() { return sessionStoreManager.getState().deleteSession },
  get switchSession() { return sessionStoreManager.getState().switchSession },
  get updateSessionTitle() { return sessionStoreManager.getState().updateSessionTitle },
  get updateSessionEngine() { return sessionStoreManager.getState().updateSessionEngine },
  get updateSessionModelProfile() { return sessionStoreManager.getState().updateSessionModelProfile },
  get updateSessionProfileMode() { return sessionStoreManager.getState().updateSessionProfileMode },
  get updateSessionModel() { return sessionStoreManager.getState().updateSessionModel },
  get updateSessionAgent() { return sessionStoreManager.getState().updateSessionAgent },
  get makeSessionVisible() { return sessionStoreManager.getState().makeSessionVisible },
  get addToBackground() { return sessionStoreManager.getState().addToBackground },
  get removeFromBackground() { return sessionStoreManager.getState().removeFromBackground },
  get addToNotifications() { return sessionStoreManager.getState().addToNotifications },
  get removeFromNotifications() { return sessionStoreManager.getState().removeFromNotifications },
  get interruptSession() { return sessionStoreManager.getState().interruptSession },
  get updateSessionWorkspace() { return sessionStoreManager.getState().updateSessionWorkspace },
  get addContextWorkspace() { return sessionStoreManager.getState().addContextWorkspace },
  get removeContextWorkspace() { return sessionStoreManager.getState().removeContextWorkspace },
}

/**
 * 通过后端 conversationId 查找前端 store。
 * 用于权限/提问等事件的 block 携带后端 conversationId 的场景。
 * 简化实现：遍历 stores（会话数通常 ≤10，O(n) 可接受），不再维护反向索引。
 */
export function findStoreByConversationId(conversationId: string): ConversationStore | undefined {
  const stores = sessionStoreManager.getState().stores
  for (const store of stores.values()) {
    if (store.getState().conversationId === conversationId) return store.getState()
  }
  return undefined
}

// ============================================================================
// React Hooks
// ============================================================================

// Cache variables for useSessionMetadataList to prevent infinite render loops
let cachedMetadataMap: Map<string, SessionMetadata> | null = null
let cachedMetadataArray: SessionMetadata[] | null = null

/**
 * 获取当前活跃会话的 Store
 *
 * 注意：此 hook 返回的 store 实例不会自动触发重渲染
 * 如需响应状态变化，请使用：
 * - useActiveSessionMessages() - 订阅消息列表
 * - useActiveSessionStreaming() - 订阅流式状态
 * - useActiveSessionActions() - 获取操作方法
 */
export function useActiveConversationStore(): ConversationStore | undefined {
  const sessionId = useStore(sessionStoreManager, (state) => state.activeSessionId)
  const stores = useStore(sessionStoreManager, (state) => state.stores)

  if (!sessionId) return undefined
  return stores.get(sessionId)?.getState()
}

/**
 * 获取指定会话的 Store
 */
export function useConversationStore(sessionId: string | null): ConversationStore | undefined {
  const stores = useStore(sessionStoreManager, (state) => state.stores)

  if (!sessionId) return undefined
  return stores.get(sessionId)?.getState()
}

/**
 * 获取所有会话元数据列表
 * 使用缓存避免数组实例变化导致的无限更新
 */
export function useSessionMetadataList(): SessionMetadata[] {
  return useStore(
    sessionStoreManager,
    (state) => {
      // Implement caching logic to prevent infinite render loops
      // If the Map reference hasn't changed, return the cached array
      if (state.sessionMetadata === cachedMetadataMap && cachedMetadataArray !== null) {
        return cachedMetadataArray
      }
      
      // Map reference has changed, create new array and update cache
      const newArray = Array.from(state.sessionMetadata.values())
      cachedMetadataMap = state.sessionMetadata
      cachedMetadataArray = newArray
      
      return newArray
    }
  )
}

/**
 * 获取当前活跃会话 ID
 */
export function useActiveSessionId(): string | null {
  return useStore(sessionStoreManager, (state) => state.activeSessionId)
}

/**
 * 获取 Manager 操作方法
 * 
 * 注意：返回缓存的 actions 对象，引用永远不变
 */
export function useSessionManagerActions() {
  return cachedActions
}

// 导出创建函数（用于测试）
export { createSessionManagerStore }
