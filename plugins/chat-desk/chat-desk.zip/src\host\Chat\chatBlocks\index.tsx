/**
 * 内容块渲染器 - 统一路由
 * 每个块都有错误边界保护
 */

import React from 'react';
import type { ContentBlock } from '@/types';
import { ContentBlockErrorBoundary } from '../common/ContentBlockErrorBoundary';
import { AskQuestionCard } from '../tool-calls/AskQuestionCard';
import { FormCard } from './FormCard';
import { PlanModeBlockRenderer } from '../tool-calls/PlanModeBlockRenderer';
import { AgentRunBlockRenderer } from '../tool-calls/AgentRunBlockRenderer';
import { TaskBoardRenderer } from './TaskBoardRenderer';
import { PermissionRequestRenderer } from '../tool-calls/PermissionRequestRenderer';
import { TextBlockRenderer } from './TextBlockRenderer';
import { ThinkingBlockRenderer } from './ThinkingBlockRenderer';
import { ToolCallBlockRenderer } from './ToolCallBlockRenderer';
import { PluginCardHost } from './PluginCardHost';
import { ContextCompactRenderer } from './ContextCompactRenderer';
import { AssaultResultCard } from '../tool-calls/AssaultResultCard';
import { WorkflowCard } from '../tool-calls/WorkflowCard';
import { parseWorkflowResult } from '../tool-calls/workflowParsers';
import { chatCardRegistry } from '@/plugin-system/chatCardRegistry';
import type { CardEntry } from '@/plugin-system/chatCardRegistry';
import { BlockCardOverrideHost } from './BlockCardOverrideHost';

/** workflow 工具块(SDK 内置多 agent 编排)。按 name 小写规范化匹配,同时命中
 * 'workflow' 与 'Workflow'。解析器注册表(parseWorkflowResult)自协商三路分发:
 * 攻坚格式→AssaultResultCard,通用 workflow→WorkflowCard,全失败→降级工具块。 */
const WORKFLOW_TOOL_NAME = 'workflow';

/** 块类型 → 插件覆盖卡片的匹配 key 缓存查询。命中返回注册条目，未命中走宿主默认。 */
function resolveBlockOverride(
  block: ContentBlock
): { entry: CardEntry; key: string } | undefined {
  // plugin_card 走 PluginCardHost 既有路径（其内部已做注册表分发），不在此列。
  if (block.type === 'plugin_card') return undefined
  return chatCardRegistry.resolveBlockCard(block)
}

export function renderContentBlock(
  block: ContentBlock,
  isStreaming?: boolean
): React.ReactNode {
  // 创建带有错误边界的内容块包装器
  const wrapWithErrorBoundary = (content: React.ReactNode, blockId?: string) => (
    <ContentBlockErrorBoundary key={blockId || `block-${block.type}`} blockType={block.type} blockId={blockId}>
      {content}
    </ContentBlockErrorBoundary>
  );

  // 插件覆盖渲染：非 plugin_card 块若被插件注册了同名 key（block:/tool: 前缀），
  // 用插件组件渲染，宿主默认（下方 switch 原生路径）作未命中兜底。
  // 插件崩溃由 BlockCardOverrideHost 内部 ErrorBoundary 兜住（不拖垮整条对话）。
  const override = resolveBlockOverride(block)
  if (override) {
    return wrapWithErrorBoundary(
      <BlockCardOverrideHost block={block} entry={override.entry} cardKey={override.key} />,
      `override-${override.key}`
    )
  }

  switch (block.type) {
    case 'text':
      // spec 协议输出（已移除）
      return wrapWithErrorBoundary(
        <TextBlockRenderer block={block} isStreaming={isStreaming} />,
        `text-${block.content.slice(0, 20)}`
      );
    case 'thinking':
      return wrapWithErrorBoundary(
        <ThinkingBlockRenderer block={block} isStreaming={isStreaming} />,
        `thinking-${block.content.slice(0, 20)}`
      );
    case 'tool_call':
      if (block.name.toLowerCase() === WORKFLOW_TOOL_NAME) {
        // 解析器注册表自协商:攻坚格式→AssaultResultCard,通用 workflow→WorkflowCard,
        // 全失败→降级通用工具块。避免误捕获 deep-research / code-review 等非攻坚 workflow。
        const parsed = parseWorkflowResult(block.output);
        if (parsed.kind === 'assault') {
          return wrapWithErrorBoundary(
            <AssaultResultCard block={block} />,
            block.id
          );
        }
        if (parsed.kind === 'generic') {
          return wrapWithErrorBoundary(
            <WorkflowCard block={block} data={parsed.data} />,
            block.id
          );
        }
        // kind === 'none':降级通用工具块
      }
      return wrapWithErrorBoundary(
        <ToolCallBlockRenderer block={block} isStreaming={isStreaming} />,
        block.id
      );
    case 'question':
      // 问答块：宿主原生渲染（AskQuestionCard）。曾短期委托交互组件插件渲染
      // （块委托试验），因插件 bundle 加载链路脆弱（react shim 导出受限导致
      // blob 模块整体加载失败）于 2026-11-08 回退宿主原生；语义层 ask 管线
      // 始终在宿主，此处只还原渲染面。
      return wrapWithErrorBoundary(
        <AskQuestionCard block={block} />,
        block.id
      );
    case 'form':
      // 表单工具（schema 驱动面板）：form 拉起事件 → FormCard，提交走 form_submit。
      // 同 question：块委托试验已回退，渲染回归宿主原生。
      return wrapWithErrorBoundary(
        <FormCard block={block} />,
        block.id
      );
    case 'plan_mode':
      return wrapWithErrorBoundary(
        <PlanModeBlockRenderer block={block} />,
        block.id
      );
    case 'agent_run':
      return wrapWithErrorBoundary(
        <AgentRunBlockRenderer block={block} />,
        block.id
      );
    case 'task_board':
      return wrapWithErrorBoundary(
        <TaskBoardRenderer block={block} />,
        block.id
      );
    case 'permission_request':
      return wrapWithErrorBoundary(
        <PermissionRequestRenderer block={block} />,
        block.id
      );
    case 'plugin_card':
      return wrapWithErrorBoundary(
        <PluginCardHost block={block} />,
        block.id
      );
    case 'context_compact':
      return wrapWithErrorBoundary(
        <ContextCompactRenderer block={block} />,
        block.id
      );
    default:
      return null;
  }
}
