import { generateUUID } from '@/utils/uuid';
/**
 * ConversationStore 工厂函数
 *
 * 每个会话创建独立的 Store 实例。
 *
 * 职责声明（批 5，裁决方案确立的终态方向，吸收自方案丙）：
 * 本 store 是**后端投影的渲染缓存**——消息真相在后端（turn_persist →
 * session_messages SQLite + JSONL 归档），本 store 只负责本端渲染态的即时
 * 维护与用户交互；恢复/对账以 kernel.resyncSession 读后端为准。新能力
 * 不在本文件增加持久化语义（持久化统一走后端命令）。
 */

import { create, StoreApi, UseBoundStore } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import { aiChatDispatch, aiChatDispatchStream } from '@/services/aiChatDispatch'
import { detectClientDescriptor } from '@/services/transport/detector'
import type { ConversationStore, ConversationState, StoreDeps } from './types'
import type { ContentBlock, EngineId, ChatMessage, TaskBoardBlock, TaskBoardItem } from '@/types'
import { handleAIEvent } from './eventHandler'
import { sessionStoreManager } from './sessionStoreManager'
import { parseWorkspaceReferences } from '@/services/workspaceReference'
import i18n from 'i18next'
import { MessageCompactor, isCompacted } from '@/utils/messageCompactor'
import { isEditTool, extractEditDiff } from '@/utils/diffExtractor'
import { getSessionConfig } from '../../shims/stores'
import { getActiveModelProfile, getModelProfileById } from '../../shims/misc'
import { normalizeModelForProfile } from '@/types/modelProfile'
import { createLogger } from '@/utils/logger'
import {
  resolveSessionEngine,
  resolveRuntimeConfigForEngine,
  getDisabledPluginMcpServers,
  generateTitleFromMessage,
  buildWorkspacePrompts,
  normalizeForInvoke,
  resolveChatError,
  resolveEffectiveProfileId,
  resolveEffectiveProfileMode,
  isProfileModeWithoutProfile,
} from './conversationStoreUtils'
import { dialogStorageService } from '@/services/dialogStorage'
import { eventBus } from '@/services/eventBus'
import { dedupeMessagesById, normalizeRecoveredMessages } from './dedupMessages'
import { useDispatchStore } from '@/stores/dispatchStore'
import { useConfigStore } from '../../shims/stores'

const log = createLogger('ConversationStore')

/**
 * 取走本会话的待注入派发报告并格式化为一次性系统提示段。
 * 无报告返回空串；配置关闭结果注入（dispatch.autoInjectReports=false）时
 * 报告留在队列（仅卡片可见，不消费）。
 */
function formatPendingDispatchReports(sessionId: string): string {
  try {
    const dispatchStore = useDispatchStore.getState()
    if (!dispatchStore.hasReports(sessionId)) return ''
    if (!isDispatchReportInjectionEnabled()) return ''
    const reports = dispatchStore.takeReports(sessionId)
    if (reports.length === 0) return ''
    const lines = reports.map((r) => {
      const status = r.status === 'completed'
        ? i18n.t('chat:dispatch.reportDone', '已完成')
        : i18n.t('chat:dispatch.reportFailed', '失败')
      const summary = r.summary?.trim()
        ? `\n${r.summary.trim()}`
        : ''
      return `- 「${r.title}」${status}${summary}`
    })
    return i18n.t('chat:dispatch.reportPreamble', {
      defaultValue: '你先前派发的后台任务已有结果，请结合以下报告继续当前工作：\n{{reports}}',
      reports: lines.join('\n'),
      interpolation: { escapeValue: false },
    })
  } catch (e) {
    log.warn('派发报告注入失败', { error: String(e) })
    return ''
  }
}

/** 结果注入开关：读取应用配置 dispatch.autoInjectReports，缺省开启 */
function isDispatchReportInjectionEnabled(): boolean {
  try {
    const config = useConfigStore.getState().config as
      | { dispatch?: { autoInjectReports?: boolean } }
      | null
    return config?.dispatch?.autoInjectReports !== false
  } catch {
    return true
  }
}

/**
 * ConversationStore 实例类型（包含 getState 方法）
 */
export type ConversationStoreInstance = UseBoundStore<StoreApi<ConversationStore>>

/**
 * 重算任务板统计（completed/inProgress/blocked/total），返回新 block（不可变）
 */
function recomputeTaskBoard(block: TaskBoardBlock, items: TaskBoardItem[]): TaskBoardBlock {
  const completed = items.filter(i => i.status === 'completed').length
  const inProgress = items.filter(i => i.status === 'in_progress').length
  const blocked = items.filter(i => i.status === 'blocked').length
  return {
    ...block,
    items,
    completed,
    inProgress,
    blocked,
    total: items.length,
    updatedAt: new Date().toISOString(),
  }
}

/**
 * 轮询等待条件成立（100ms 间隔，超时兜底返回）。
 * 用于 sendPendingNow 等待中断后的 session_end 收尾（服务端异步，无法 await）。
 */
function waitFor(cond: () => boolean, timeoutMs: number): Promise<void> {
  return new Promise((resolve) => {
    const start = Date.now()
    const tick = () => {
      if (cond() || Date.now() - start > timeoutMs) resolve()
      else setTimeout(tick, 100)
    }
    tick()
  })
}

/**
 * 初始状态工厂
 */
function createInitialState(sessionId: string): ConversationState {
  return {
    // 消息状态
    messages: [],
    archivedMessages: [],
    currentMessage: null,

    // 流式构建映射
    toolBlockMap: new Map(),
    questionBlockMap: new Map(),
    formBlockMap: new Map(),
    planBlockMap: new Map(),
    activePlanId: null,
    agentRunBlockMap: new Map(),
    activeTaskId: null,
    // TaskBoard: boardId → blocks 索引，run 级单板
    taskBoardBlockMap: new Map(),
    activeTaskBoardId: null,
    pendingTaskCreates: [],
    permissionRequestBlockMap: new Map(),
    activePermissionRequestId: null,
    pluginCardBlockMap: new Map(),
    sessionAllowedTools: [],
    streamingUpdateCounter: 0,

    // 会话状态
    conversationId: null,
    currentConversationSeed: null,
    isStreaming: false,
    isInterrupting: false,
    turnEpoch: 0,
    activeTurnId: null,
    error: null,
    progressMessage: null,
    promptSuggestion: null,
    usageStats: null,
    streamRate: null,
    // 会话运行累计时长（纯运行时，不落库）：初始为 0，无活动轮
    sessionElapsedMs: 0,
    runStartAtMs: null,
    // 最近完成一轮时长：初始 0（从未对话）；session_end / settle 时写入
    lastTurnMs: 0,

    // 输入草稿
    inputDraft: {
      text: '',
      attachments: [],
      contextBlocks: [],
    },

    // 待发送简报（压缩交接产物）
    pendingBriefing: null,

    // 待发送队列（流式预输入 / 多行拆分入队）
    pendingQueue: [],
    queueDispatching: false,

    // 提示词优化（版本栈内存态，不持久化）
    promptOptimize: {
      status: 'idle',
      history: [],
      cursor: -1,
      sourceSnapshot: null,
      pendingResult: null,
      pendingMeta: null,
      optimizeSessionId: null,
      error: null,
    },

    // 工作区关联
    workspaceId: null,

    // 可见区域追踪
    visibleRange: null,

    // 增量落盘水位（WAL 崩溃保护）
    persistedSeq: 0,
    persistedConversationId: null,

    // 历史分页（尾部优先恢复）
    historyPaging: null,

    // 元数据
    sessionId,
  }
}

// ============================================================================
// 批 4a（审计 4.2/4.3）：块级终态统一回写。
//
// 根因：session_end 与 tool_call_end / plugin_card_answered / agent_run_end
// 乱序到达（桌面直发+广播双通道）时，currentMessage 已被 finishMessage 归档，
// updateXxxBlock 的 `if (!currentMessage) return` 把终态丢弃——历史消息里的
// 卡片永久 running，且随轮末 saveDialog 写入 JSONL 永久化。
// question / form 已各自修复跨 messages 搜索；此 helper 把同一范式收敛为
// 唯一实现，append 侧幂等同样全局查重（防归档后重发产生幽灵双卡）。
// ============================================================================

type AnyContentBlock = import('../../types/chat').ContentBlock

/** 判断某 id 的某类型块是否已存在于 currentMessage 或任何归档消息 */
function hasBlockAnywhere(
  state: ConversationState,
  type: string,
  id: string,
): boolean {
  if (state.currentMessage?.blocks.some((b) => b.type === type && 'id' in b && b.id === id)) {
    return true
  }
  return state.messages.some(
    (m) =>
      m.type === 'assistant' &&
      m.blocks?.some((b) => b.type === type && 'id' in b && b.id === id),
  )
}

/**
 * 按 match 定位块并回写 patch：先查 currentMessage，miss 则跨 messages[] 回写。
 * @returns 是否命中并写入
 */
function updateBlockAcrossSession(
  get: () => ConversationState,
  set: (partial: Partial<ConversationState>) => void,
  match: (b: AnyContentBlock) => boolean,
  patch: (b: AnyContentBlock) => AnyContentBlock,
): boolean {
  const { currentMessage, messages } = get()
  if (currentMessage) {
    const idx = currentMessage.blocks.findIndex(match)
    if (idx >= 0) {
      const blocks = [...currentMessage.blocks]
      blocks[idx] = patch(blocks[idx])
      set({ currentMessage: { ...currentMessage, blocks } })
      return true
    }
  }
  let touched = false
  const newMessages = messages.map((msg) => {
    if (msg.type !== 'assistant' || !msg.blocks) return msg
    const idx = msg.blocks.findIndex(match)
    if (idx < 0) return msg
    touched = true
    const blocks = [...msg.blocks]
    blocks[idx] = patch(blocks[idx])
    return { ...msg, blocks }
  })
  if (touched) set({ messages: newMessages })
  return touched
}

/**
 * 创建单个会话的 Store 实例
 *
 * 每个会话独立拥有：
 * - 消息状态和操作方法
 * - 流式构建状态
 * - 会话 ID 和错误状态
 * - 事件处理能力
 *
 * @param sessionId 会话唯一标识（前端生成）
 * @param deps 外部依赖注入
 */
export function createConversationStore(
  sessionId: string,
  deps: StoreDeps
): ConversationStoreInstance {
  const initialState = createInitialState(sessionId)

  const getCurrentEngineId = (): EngineId => {
    return resolveSessionEngine(sessionId, deps.getConfig()?.defaultEngine)
  }

  const createCurrentAssistantMessage = (blocks: ContentBlock[]) => {
    // adopt 预生成的 id（sendMessage 时分配，与后端 turn_persist 一致）；
    // 无预生成时回退到 generateUUID（兼容旧路径 / 非发送触发的创建）
    const id = _pendingAssistantMessageId ?? generateUUID()
    _pendingAssistantMessageId = null // adopt 后清空，避免泄漏到下一轮
    return {
      id,
      engineId: getCurrentEngineId(),
      blocks,
      isStreaming: true as const,
    }
  }

  // ===== 流式文本缓冲区 =====
  // 段落级缓冲策略：
  // 1. 首段立即显示（快速响应）
  // 2. 后续段落等待 \n\n（段落结束）才 flush
  // 3. 超时保护：STREAM_FLUSH_INTERVAL 内没有段落结束也 flush
  let _textBuffer = ''
  let _paragraphTimer: ReturnType<typeof setTimeout> | null = null
  // thinking 缓冲：与 _textBuffer 严格对称（C2 spec plans/c2-thinking-buffer-spec.md §二）。
  // 根因：原 appendThinkingBlock 逐 delta 执行 set() 全量 blocks 数组拷贝 +
  // `content: lastBlock.content + content` 全量字符串重拼（O(n²)），长思考流
  // （≥1000 delta）是流式渲染卡顿主因。修法：delta 期间只做 O(1) 缓冲追加，
  // 由 50ms 定时 / 类型切换点 / 收束点一次性落块（触发点全部对齐 text 范式）。
  let _thinkingBuffer = ''
  // 预生成的 assistant 消息 id（sendMessage 时分配，传给后端 + createCurrentAssistantMessage adopt）。
  // 消除 id 漂移：同一轮回复在前端 currentMessage 和后端 turn_persist 用同一个 id。
  let _pendingAssistantMessageId: string | null = null
  // 上一次压缩操作的可见范围，用于防止反馈循环（压缩→高度变化→新 range→再压缩）
  let _lastCompactionRange: { start: number; end: number } | null = null
  // 磁盘分页加载锁：防止向上滚动连续触发重复读盘
  let _loadingOlderPage = false
  // 流式 flush 超时间隔（ms）。
  // 取舍说明：该值决定段落内部文字更新帧率（1000/interval fps）。
  // - 曾为 200ms：渲染成本低，但文字以 5fps "一坨坨"跳出，观感卡顿（详见 temp/streaming-mvp）
  // - 现为 50ms：20fps 更新，观感平滑；末段走轻量渲染路径，成本可承受
  // 不要在未实测观感的情况下调大此值。
  const STREAM_FLUSH_INTERVAL = 50

  // ===== 消息压缩器 =====
  // 模块级实例，管理消息快照的 LRU 缓存
  // 不放入 Zustand state（内部可变状态，不需要触发渲染）
  const compactor = new MessageCompactor()

  // 思考阶段结束标记：把 blocks 中已有的 thinking 块全部折叠。
  // 触发时机：正文(text)、工具(tool_call) 或连续新思考块出现，意味着上一个思考已完成。
  // 不改动已是 true 的 collapsed（避免覆盖用户手动展开后又被拉回）。
  const foldThinkingBlocks = (blocks: ContentBlock[]): ContentBlock[] => {
    let touched = false
    const next = blocks.map((b) => {
      if (b.type === 'thinking' && !b.collapsed) {
        touched = true
        return { ...b, collapsed: true }
      }
      return b
    })
    return touched ? next : blocks
  }

  const store = create<ConversationStore>()(
    subscribeWithSelector((set, get) => ({
      ...initialState,

      // ===== 消息操作 =====
      addMessage: (message) => {
        set((state) => {
          const newMessages = [...state.messages, message]
          return { messages: newMessages }
        })
      },

      deleteMessage: (messageId) => {
        set((state) => {
          const newMessages = state.messages.filter((m) => m.id !== messageId)
          return { messages: newMessages }
        })
      },

      editMessage: (messageId, newContent) => {
        set((state) => {
          const newMessages = state.messages.map((m) =>
            m.id === messageId && m.type === 'user' ? { ...m, content: newContent } : m
          )
          return { messages: newMessages }
        })
      },

      clearMessages: () => {
        set({
          messages: [],
          archivedMessages: [],
          currentMessage: null,
          toolBlockMap: new Map(),
          questionBlockMap: new Map(),
          formBlockMap: new Map(),
          planBlockMap: new Map(),
          activePlanId: null,
          agentRunBlockMap: new Map(),
          activeTaskId: null,
          taskBoardBlockMap: new Map(),
          activeTaskBoardId: null,
          pendingTaskCreates: [],
          permissionRequestBlockMap: new Map(),
          activePermissionRequestId: null,
          pluginCardBlockMap: new Map(),
          // 清空会话消息时同步清空待发送队列（语义一致：都视为会话内容重置）
          pendingQueue: [],
        })
      },

      finishMessage: () => {
        // 先 flush 所有缓冲内容（thinking + text）：收束点兜底，缓冲不丢字。
        // 中断场景同样覆盖——中断终止统一经 session_end → finishMessage
        // （C2 spec §二；session_end 处理序：finishMessage 先于 isStreaming=false）。
        // flush 顺序 thinking→text 与 50ms 定时回调一致，保持块时序。
        if (_thinkingBuffer) get()._flushThinkingBuffer()
        if (_textBuffer) get()._flushTextBuffer()

        // 清除定时器
        if (_paragraphTimer) {
          clearTimeout(_paragraphTimer)
          _paragraphTimer = null
        }
        // 清除预生成的 assistant id（本轮结束，无论是否被 adopt 都不再需要）
        _pendingAssistantMessageId = null

        const { currentMessage, messages } = get()
        if (currentMessage) {
          const completedMessage = {
            id: currentMessage.id,
            type: 'assistant' as const,
            engineId: currentMessage.engineId,
            blocks: foldThinkingBlocks(currentMessage.blocks),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }
          // 同 id 已在 messages 中（客户端重开后从后端消息库恢复了「进行中轮次」的局部内容，
          // 又被 live token 续写）：续接而非追加重复条，避免同 id 分裂、归档只剩尾部内容。
          const existingIdx = messages.findIndex((m) => m.id === completedMessage.id)
          if (existingIdx >= 0 && messages[existingIdx].type === 'assistant') {
            const prev = messages[existingIdx] as typeof completedMessage
            const merged = {
              ...completedMessage,
              blocks: foldThinkingBlocks([...prev.blocks, ...completedMessage.blocks]),
            }
            const next = [...messages]
            next[existingIdx] = merged
            set({ messages: next, currentMessage: null })
            return merged
          }
          set({
            messages: [...messages, completedMessage],
            currentMessage: null,
          })
          return completedMessage
        }
        return null
      },

      // ===== 输入草稿 =====
      updateInputDraft: (draft) => {
        set({ inputDraft: draft })
      },

      clearInputDraft: () => {
        set({
          inputDraft: {
            text: '',
            attachments: [],
            contextBlocks: [],
          },
        })
      },

      // ===== 临时上下文块（TCB） =====
      addContextBlock: (block) => {
        log.info('[TCB] addContextBlock 被调用', {
          id: block?.id,
          kind: block?.kind,
          title: block?.title,
          hasSession: !!get().sessionId,
          curBlocks: (block ? block.id : '') ? (get().inputDraft.contextBlocks ?? []).length : -1,
        })
        // 校验：缺 id/kind/title 拒绝（保证渲染/格式化/发送契约可用）
        if (!block || !block.id || !block.kind || !block.title) return false
        const cur = get().inputDraft
        const blocks = cur.contextBlocks ?? []
        // 按 source + dedupeKey 去重：同源同 key 覆盖旧块（保留原位置），否则追加
        const dupIdx = block.source && block.dedupeKey
          ? blocks.findIndex(
              (b) => b.source === block.source && b.dedupeKey === block.dedupeKey
            )
          : -1
        if (dupIdx >= 0) {
          const next = [...blocks]
          next[dupIdx] = block
          set({ inputDraft: { ...cur, contextBlocks: next } })
          return false
        }
        set({ inputDraft: { ...cur, contextBlocks: [...blocks, block] } })
        return true
      },

      removeContextBlock: (blockId) => {
        const cur = get().inputDraft
        const blocks = (cur.contextBlocks ?? []).filter((b) => b.id !== blockId)
        if (blocks.length === (cur.contextBlocks ?? []).length) return // 未找到，无变更
        set({ inputDraft: { ...cur, contextBlocks: blocks } })
      },

      clearContextBlocks: () => {
        const cur = get().inputDraft
        if ((cur.contextBlocks ?? []).length === 0) return
        set({ inputDraft: { ...cur, contextBlocks: [] } })
      },

      updateContextBlockNote: (blockId, note) => {
        const cur = get().inputDraft
        const blocks = cur.contextBlocks ?? []
        const idx = blocks.findIndex((b) => b.id === blockId)
        if (idx < 0) return
        const next = [...blocks]
        next[idx] = { ...next[idx], userNote: note }
        set({ inputDraft: { ...cur, contextBlocks: next } })
      },

      setPendingBriefing: (briefing) => {
        set({ pendingBriefing: briefing && briefing.trim() ? briefing : null })
      },

      // ===== 提示词优化（版本栈） =====
      beginPromptOptimize: (sourceText, meta) => {
        const po = get().promptOptimize
        if (po.status === 'running') return

        let history = po.history
        let cursor = po.cursor
        if (history.length === 0) {
          history = [{ text: sourceText, origin: 'original', createdAt: Date.now() }]
          cursor = 0
        } else {
          // 丢弃 redo 分支；输入被手改则手改文本先入栈（保留可回滚）
          history = history.slice(0, cursor + 1)
          if (history[cursor].text !== sourceText) {
            history = [...history, { text: sourceText, origin: 'edited', createdAt: Date.now() }]
            cursor = history.length - 1
          }
        }

        set({
          promptOptimize: {
            status: 'running',
            history,
            cursor,
            sourceSnapshot: sourceText,
            pendingResult: null,
            pendingMeta: {
              engineId: meta.engineId,
              model: meta.model,
              mode: meta.mode,
              direction: meta.direction,
              customDirection: meta.customDirection,
              iteration: meta.iteration,
              totalIterations: meta.totalIterations,
            },
            optimizeSessionId: meta.optimizeSessionId,
            error: null,
          },
        })
      },

      completePromptOptimize: (resultText) => {
        const state = get()
        const po = state.promptOptimize
        if (po.status !== 'running') return

        const text = resultText.trim()
        if (!text) {
          set({
            promptOptimize: {
              ...po,
              status: 'idle',
              sourceSnapshot: null,
              pendingMeta: null,
              optimizeSessionId: null,
              // i18n 未初始化（测试环境等）时兜底，保证错误提示非空
              error: i18n.t('chat:promptOptimize.errorEmpty', '优化结果为空，请重试') || '优化结果为空，请重试',
            },
          })
          return
        }

        // 输入被手改（与触发快照不一致）→ 不覆盖，转待应用
        if ((po.sourceSnapshot ?? '') !== state.inputDraft.text) {
          set({ promptOptimize: { ...po, status: 'ready', pendingResult: text } })
          return
        }

        const history = [
          ...po.history,
          {
            text,
            origin: 'optimized' as const,
            engineId: po.pendingMeta?.engineId,
            model: po.pendingMeta?.model,
            mode: po.pendingMeta?.mode,
            direction: po.pendingMeta?.direction,
            customDirection: po.pendingMeta?.customDirection,
            iteration: po.pendingMeta?.iteration,
            totalIterations: po.pendingMeta?.totalIterations,
            createdAt: Date.now(),
          },
        ]
        set({
          promptOptimize: {
            status: 'idle',
            history,
            cursor: history.length - 1,
            sourceSnapshot: null,
            pendingResult: null,
            pendingMeta: null,
            optimizeSessionId: null,
            error: null,
          },
          inputDraft: { text, attachments: state.inputDraft.attachments, contextBlocks: state.inputDraft.contextBlocks },
        })
      },

      continuePromptOptimize: (resultText) => {
        const state = get()
        const po = state.promptOptimize
        if (po.status !== 'running') return

        const text = resultText.trim()
        if (!text) {
          // 空结果按失败收口（不进入下一轮）
          set({
            promptOptimize: {
              ...po,
              status: 'idle',
              sourceSnapshot: null,
              pendingMeta: null,
              optimizeSessionId: null,
              error: i18n.t('chat:promptOptimize.errorEmpty', '优化结果为空，请重试') || '优化结果为空，请重试',
            },
          })
          return
        }

        // 多轮迭代中间轮：跳过冲突检测，结果直接入栈并写回 inputDraft。
        // 下一轮基线恒为上一轮 AI 结果（非用户手改），故无冲突判定必要。
        const history = [
          ...po.history,
          {
            text,
            origin: 'optimized' as const,
            engineId: po.pendingMeta?.engineId,
            model: po.pendingMeta?.model,
            mode: po.pendingMeta?.mode,
            direction: po.pendingMeta?.direction,
            customDirection: po.pendingMeta?.customDirection,
            iteration: po.pendingMeta?.iteration,
            totalIterations: po.pendingMeta?.totalIterations,
            createdAt: Date.now(),
          },
        ]
        set({
          promptOptimize: {
            status: 'idle',
            history,
            cursor: history.length - 1,
            sourceSnapshot: null,
            pendingResult: null,
            pendingMeta: null,
            optimizeSessionId: null,
            error: null,
          },
          inputDraft: { text, attachments: state.inputDraft.attachments, contextBlocks: state.inputDraft.contextBlocks },
        })
      },

      applyPendingPromptOptimize: () => {
        const state = get()
        const po = state.promptOptimize
        if (po.status !== 'ready' || !po.pendingResult) return

        const currentInput = state.inputDraft.text
        let history = po.history.slice(0, po.cursor + 1)
        // 当前手改文本先入栈保留（可回滚回来）
        if (history.length > 0 && history[history.length - 1].text !== currentInput && currentInput.trim()) {
          history = [...history, { text: currentInput, origin: 'edited' as const, createdAt: Date.now() }]
        }
        const next = [
          ...history,
          {
            text: po.pendingResult,
            origin: 'optimized' as const,
            engineId: po.pendingMeta?.engineId,
            model: po.pendingMeta?.model,
            mode: po.pendingMeta?.mode,
            direction: po.pendingMeta?.direction,
            customDirection: po.pendingMeta?.customDirection,
            iteration: po.pendingMeta?.iteration,
            totalIterations: po.pendingMeta?.totalIterations,
            createdAt: Date.now(),
          },
        ]
        set({
          promptOptimize: {
            status: 'idle',
            history: next,
            cursor: next.length - 1,
            sourceSnapshot: null,
            pendingResult: null,
            pendingMeta: null,
            optimizeSessionId: null,
            error: null,
          },
          inputDraft: { text: po.pendingResult, attachments: state.inputDraft.attachments, contextBlocks: state.inputDraft.contextBlocks },
        })
      },

      failPromptOptimize: (error) => {
        const po = get().promptOptimize
        set({
          promptOptimize: {
            ...po,
            status: 'idle',
            sourceSnapshot: null,
            pendingResult: null,
            pendingMeta: null,
            optimizeSessionId: null,
            error,
          },
        })
      },

      undoPromptOptimize: () => {
        const state = get()
        const po = state.promptOptimize
        if (po.status !== 'idle' || po.history.length === 0 || po.cursor < 0) return

        let history = po.history
        let cursor = po.cursor
        // 当前文本有未入栈的手改 → 先入栈（截断 redo 分支），undo 后可 redo 回来
        if (state.inputDraft.text !== history[cursor].text) {
          history = [...history.slice(0, cursor + 1), { text: state.inputDraft.text, origin: 'edited' as const, createdAt: Date.now() }]
          cursor = history.length - 1
        }
        if (cursor <= 0) return
        cursor -= 1
        set({
          promptOptimize: { ...po, history, cursor },
          inputDraft: { text: history[cursor].text, attachments: state.inputDraft.attachments, contextBlocks: state.inputDraft.contextBlocks },
        })
      },

      redoPromptOptimize: () => {
        const state = get()
        const po = state.promptOptimize
        if (po.status !== 'idle' || po.cursor >= po.history.length - 1) return
        // 当前文本被手改（与栈内当前版本不符）→ redo 会覆盖手改内容，直接忽略
        if (state.inputDraft.text !== po.history[po.cursor].text) return

        const cursor = po.cursor + 1
        set({
          promptOptimize: { ...po, cursor },
          inputDraft: { text: po.history[cursor].text, attachments: state.inputDraft.attachments, contextBlocks: state.inputDraft.contextBlocks },
        })
      },

      resetPromptOptimize: () => {
        set({
          promptOptimize: {
            status: 'idle',
            history: [],
            cursor: -1,
            sourceSnapshot: null,
            pendingResult: null,
            pendingMeta: null,
            optimizeSessionId: null,
            error: null,
          },
        })
      },

      // ===== 流式构建 =====
      // 段落级缓冲策略：
      // 1. 首次创建消息时立即 flush（保证首 token 响应速度）
      // 2. 后续更新等待 \n\n（段落结束）才 flush
      // 3. 超时保护：200ms 内没有段落结束也 flush
      // 效果：渲染更像"事件级"，一个段落一次渲染，减少视觉跳动
      appendTextBlock: (content) => {
        // 类型切换点：thinking 缓冲先落块（C2 spec §二——正文到达即思考阶段结束，
        // 缓冲中的思考内容必须在 text 落块前完整落块；下方 fold 检查随后自然看到
        // 已落块的 thinking 并折叠，与既有 fold 行为无缝衔接）
        if (_thinkingBuffer) get()._flushThinkingBuffer()

        // 正文开始出现：若此前有 thinking 且尚未折叠，立即折叠（思考阶段结束）。
        // 首段正文 token 一到即收起思考面板；fold 幂等，仅在有未折叠 thinking 时产出新数组并 set。
        const preState = get()
        if (preState.currentMessage) {
          const hasUncollapsed = preState.currentMessage.blocks.some((b) => b.type === 'thinking' && !b.collapsed)
          if (hasUncollapsed) {
            const folded = foldThinkingBlocks(preState.currentMessage.blocks)
            if (folded !== preState.currentMessage.blocks) {
              set({
                currentMessage: { ...preState.currentMessage, blocks: folded },
                streamingUpdateCounter: preState.streamingUpdateCounter + 1,
              })
            }
          }
        }

        // 追加到闭包级 buffer（O(1），不触发 Zustand）
        _textBuffer += content

        const state = get()

        // 首次创建消息时立即 flush（保证首 token 响应速度）
        if (!state.currentMessage) {
          // 防御：session_end 已到达但迟到的 token 仍在写入
          // 此时 isStreaming=false 且 currentMessage=null，说明 finishMessage 已执行
          // 迟到的内容应追加到最后一条助手消息，而非创建孤儿消息
          if (!state.isStreaming) {
            const bufferContent = _textBuffer
            _textBuffer = ''
            if (bufferContent) {
              const { messages } = get()
              const lastIdx = messages.length - 1
              if (lastIdx >= 0 && messages[lastIdx].type === 'assistant') {
                const lastMsg = messages[lastIdx]
                const blocks = [...lastMsg.blocks]
                const lastBlock = blocks[blocks.length - 1]
                if (lastBlock?.type === 'text') {
                  blocks[blocks.length - 1] = { ...lastBlock, content: lastBlock.content + bufferContent }
                } else {
                  blocks.push({ type: 'text', content: bufferContent })
                }
                const newMessages = [...messages]
                newMessages[lastIdx] = { ...lastMsg, blocks }
                set({ messages: newMessages })
              }
            }
            return
          }
          get()._flushTextBuffer()
          return
        }

        // 段落级模式：检测缓冲区中的段落结束
        // 注意：需要检查 _textBuffer 而非 content，因为 \n\n 可能跨两个 token
        if (_textBuffer.includes('\n\n')) {
          // 段落结束，立即 flush
          if (_paragraphTimer) {
            clearTimeout(_paragraphTimer)
            _paragraphTimer = null
          }
          get()._flushTextBuffer()
        } else if (!_paragraphTimer) {
          // 启动超时保护定时器（thinking 与 text 共享同一节拍：一次 flush 先 thinking
          // 后 text，保持块时序——C2 spec §二；缓冲为空的一侧 flush 内部 no-op）
          _paragraphTimer = setTimeout(() => {
            _paragraphTimer = null
            get()._flushThinkingBuffer()
            get()._flushTextBuffer()
          }, STREAM_FLUSH_INTERVAL)
        }
      },

      /** 内部方法：将缓冲区文本 flush 到 Zustand store */
      _flushTextBuffer: () => {
        // 清除超时定时器
        if (_paragraphTimer) {
          clearTimeout(_paragraphTimer)
          _paragraphTimer = null
        }

        // 取出缓冲区内容并重置
        const bufferToFlush = _textBuffer
        _textBuffer = ''

        const state = get()
        if (!bufferToFlush && state.currentMessage) return

        if (!state.currentMessage) {
          if (bufferToFlush) {
            if (!state.isStreaming) {
              // session_end 已到达，定时器 flush 的迟到内容追加到最后一条消息
              const { messages } = get()
              const lastIdx = messages.length - 1
              if (lastIdx >= 0 && messages[lastIdx].type === 'assistant') {
                const lastMsg = messages[lastIdx]
                const blocks = [...lastMsg.blocks]
                const lastBlock = blocks[blocks.length - 1]
                if (lastBlock?.type === 'text') {
                  blocks[blocks.length - 1] = { ...lastBlock, content: lastBlock.content + bufferToFlush }
                } else {
                  blocks.push({ type: 'text', content: bufferToFlush })
                }
                const newMessages = [...messages]
                newMessages[lastIdx] = { ...lastMsg, blocks }
                set({ messages: newMessages })
              }
            } else {
              // 首次创建消息
              set({
                currentMessage: createCurrentAssistantMessage([{ type: 'text', content: bufferToFlush }]),
                streamingUpdateCounter: state.streamingUpdateCounter + 1,
              })
            }
          }
        } else {
          // 更新最后一个文本块（思考阶段结束 → 正文开始出现，折叠此前的思考块）
          let blocks = [...state.currentMessage.blocks]
          const lastBlock = blocks[blocks.length - 1]
          if (lastBlock?.type === 'text') {
            blocks[blocks.length - 1] = { ...lastBlock, content: lastBlock.content + bufferToFlush }
          } else if (bufferToFlush) {
            blocks = foldThinkingBlocks(blocks)
            blocks.push({ type: 'text', content: bufferToFlush })
          }
          set({
            currentMessage: { ...state.currentMessage, blocks },
            streamingUpdateCounter: state.streamingUpdateCounter + 1,
          })
        }

        // 段落级策略：不需要自动重新调度
        // flush 时机由 appendTextBlock 中的段落检测 (\n\n) 或超时保护触发
      },

      /**
       * 内部方法：将缓冲区 thinking 内容一次性 flush 到 Zustand store。
       * 与 _flushTextBuffer 严格对称（C2 spec §二）：原 appendThinkingBlock 的块操纵
       * 逻辑（fold/merge/create currentMessage）整体迁入此处，仅把入参从每 delta
       * content 改为 flush 时一次性 buffer 内容；streamingUpdateCounter 仍由 flush
       * 触发 +1，delta 期间不再逐条自增。
       * 注意：不清 _paragraphTimer——定时器为 thinking/text 共享，清空是
       * _flushTextBuffer 的职责（thinking 落块后同窗 text 仍可能待落块）。
       */
      _flushThinkingBuffer: () => {
        // 取出缓冲区内容并重置（delta 期间仅 O(1) 追加，此处一次性落块）
        const bufferToFlush = _thinkingBuffer
        _thinkingBuffer = ''
        if (!bufferToFlush) return

        const state = get()
        if (!state.currentMessage) {
          if (!state.isStreaming) {
            // session_end 已到达，迟到的 thinking delta 追加到最后一条助手消息
            // （与 _flushTextBuffer 的迟到防御同等处理，不允许静默丢弃——C2 spec §二复核红线）。
            // 迟到新增块直接置 collapsed：消息已归档收束，不得再以展开态重开思考面板。
            const { messages } = get()
            const lastIdx = messages.length - 1
            if (lastIdx >= 0 && messages[lastIdx].type === 'assistant') {
              const lastMsg = messages[lastIdx]
              const blocks = [...lastMsg.blocks]
              const lastBlock = blocks[blocks.length - 1]
              if (lastBlock?.type === 'thinking') {
                blocks[blocks.length - 1] = { ...lastBlock, content: lastBlock.content + bufferToFlush }
              } else {
                blocks.push({ type: 'thinking', content: bufferToFlush, collapsed: true })
              }
              const newMessages = [...messages]
              newMessages[lastIdx] = { ...lastMsg, blocks }
              set({ messages: newMessages })
            }
          } else {
            // 首次创建消息（首 token 立即落块，思考首响不延迟）
            set({
              currentMessage: createCurrentAssistantMessage([{ type: 'thinking', content: bufferToFlush }]),
              streamingUpdateCounter: state.streamingUpdateCounter + 1,
            })
          }
        } else {
          const blocks = (() => {
            const lastBlock = state.currentMessage.blocks[state.currentMessage.blocks.length - 1]
            if (lastBlock?.type === 'thinking') {
              // 同一思考流：合并内容，保持自身展开
              const merged = [...state.currentMessage.blocks]
              merged[merged.length - 1] = { ...lastBlock, content: lastBlock.content + bufferToFlush }
              return merged
            }
            // 新增思考块 = 上一阶段已完成，折叠此前的思考块
            return [...foldThinkingBlocks(state.currentMessage.blocks), { type: 'thinking' as const, content: bufferToFlush }]
          })()
          set({
            currentMessage: { ...state.currentMessage, blocks },
            streamingUpdateCounter: state.streamingUpdateCounter + 1,
          })
        }
      },

      appendThinkingBlock: (content) => {
        // 类型切换点：先 flush 文本缓冲区，确保正文先落块（保持 text→thinking 块时序）。
        // 注意：此处不做 thinking 缓冲 flush——thinking delta 逐条到达，入口 flush 会
        // 退化为逐 delta set，破坏缓冲节奏；缓冲内容由 flush 时的 merge 逻辑合并。
        if (_textBuffer) get()._flushTextBuffer()

        // 追加到闭包级缓冲（O(1)，不触发 set）——与 _textBuffer 严格对称。
        // 50ms 丢失窗口语义与 _textBuffer 完全一致（已被接受的风险面：
        // 进程崩溃/页面关闭时窗口内内容丢失，磁盘归档由后端 turn_persist 兜底）。
        _thinkingBuffer += content

        const state = get()

        // 首 token 立即落块（首响不延迟，与 appendTextBlock 首段立即 flush 对称）。
        // 同时覆盖迟到 token 防御：isStreaming=false 时 currentMessage 必为 null，
        // _flushThinkingBuffer 内部走「追加到最后一条助手消息」分支，不静默丢弃。
        if (!state.currentMessage) {
          get()._flushThinkingBuffer()
          return
        }

        // 50ms 超时保护（与 text 共享 _paragraphTimer 与 STREAM_FLUSH_INTERVAL）：
        // 一次 flush 先 thinking 后 text，保持块时序；定时器挂起中则无需重复调度
        if (!_paragraphTimer) {
          _paragraphTimer = setTimeout(() => {
            _paragraphTimer = null
            get()._flushThinkingBuffer()
            get()._flushTextBuffer()
          }, STREAM_FLUSH_INTERVAL)
        }
      },

      appendToolCallBlock: (toolId, toolName, input) => {
        // 类型切换点：thinking 缓冲先落块（工具卡到达 = 思考阶段结束，缓冲内容不得
        // 滞后到工具卡之后），再 flush 文本缓冲区——保持 thinking→text→tool_call
        // 块时序（C2 spec §二：现只 flush text，须补 thinking）
        if (_thinkingBuffer) get()._flushThinkingBuffer()
        // 先 flush 文本缓冲区
        if (_textBuffer) get()._flushTextBuffer()

        const { currentMessage, toolBlockMap, streamingUpdateCounter } = get()

        // 幂等守卫：流式与快照双路径会对同一 toolId 重发 ToolCallStart，
        // 已存在时仅回填缺失的 input，不追加重复块
        const existingIdx = toolBlockMap.get(toolId)
        if (existingIdx !== undefined && currentMessage) {
          const existing = currentMessage.blocks[existingIdx]
          if (existing?.type === 'tool_call') {
            const hasInput = existing.input && Object.keys(existing.input).length > 0
            if (!hasInput && input && Object.keys(input).length > 0) {
              const blocks = [...currentMessage.blocks]
              blocks[existingIdx] = { ...existing, input }
              set({ currentMessage: { ...currentMessage, blocks } })
            }
          }
          return
        }
        // 批 4a：map 命中但 currentMessage 已归档——块在历史消息里，重发
        // 不追加（否则开新消息装重复工具卡，且无 end 永久 running）
        if (existingIdx !== undefined && !currentMessage) {
          return
        }
        // map miss（快照/恢复路径）：全局查重兜底
        if (hasBlockAnywhere(get(), 'tool_call', toolId)) {
          return
        }

        const block = {
          type: 'tool_call' as const,
          id: toolId,
          name: toolName,
          input,
          status: 'running' as const,
          startedAt: new Date().toISOString(),
        }
        const newMap = new Map(toolBlockMap)
        if (!currentMessage) {
          newMap.set(toolId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            toolBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          // 新增工具块 = 思考阶段结束，折叠此前的思考块
          const blocks = [...foldThinkingBlocks(currentMessage.blocks), block]
          newMap.set(toolId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            toolBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updateToolCallBlock: (toolId, status, output?, error?) => {
        const { currentMessage, toolBlockMap } = get()
        const completedAt = status === 'completed' || status === 'failed' ? new Date().toISOString() : undefined
        const patch = (b: AnyContentBlock): AnyContentBlock => {
          if (b.type !== 'tool_call') return b
          return {
            ...b,
            status,
            output: output ?? b.output,
            error: error ?? b.error,
            completedAt: completedAt ?? b.completedAt,
          }
        }
        if (currentMessage) {
          const idx = toolBlockMap.get(toolId)
          if (idx === undefined) {
            // map miss（快照/恢复路径未登记）：跨会话回写兜底
            updateBlockAcrossSession(
              get, set,
              (b) => b.type === 'tool_call' && b.id === toolId,
              patch,
            )
            return
          }
          const blocks = [...currentMessage.blocks]
          const block = blocks[idx]
          if (block?.type !== 'tool_call') return
          blocks[idx] = patch(block)
          set({ currentMessage: { ...currentMessage, blocks } })
          return
        }
        // 批 4a（审计 4.2）：归档后到达的终态——跨 messages[] 回写，
        // 不再丢弃（否则历史工具卡永久 running 且写入 JSONL 永久化）
        updateBlockAcrossSession(
          get, set,
          (b) => b.type === 'tool_call' && b.id === toolId,
          patch,
        )
      },

      updateToolCallTaskId: (toolId, taskId) => {
        const apply = () =>
          updateBlockAcrossSession(
            get, set,
            (b): b is AnyContentBlock => b.type === 'tool_call' && b.id === toolId && !('taskId' in b && b.taskId),
            (b) => (b.type === 'tool_call' && !b.taskId ? { ...b, taskId } : b),
          )
        const { currentMessage, toolBlockMap } = get()
        if (!currentMessage) {
          apply()
          return
        }
        const idx = toolBlockMap.get(toolId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'tool_call') return
        // 幂等：已有 taskId 则不动（start 先写入，end 后到不覆盖）
        if (block.taskId) return
        blocks[idx] = { ...block, taskId }
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      updateToolCallBlockDiff: (toolId, diffData) => {
        const { currentMessage, toolBlockMap } = get()
        if (!currentMessage) return
        const idx = toolBlockMap.get(toolId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        if (blocks[idx]?.type === 'tool_call') {
          blocks[idx] = { ...blocks[idx], diffData }
          set({ currentMessage: { ...currentMessage, blocks } })
        }
      },

      updateToolCallBlockPatch: (toolId, patchData) => {
        const { currentMessage, toolBlockMap } = get()
        if (!currentMessage) return
        const idx = toolBlockMap.get(toolId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        if (blocks[idx]?.type === 'tool_call') {
          blocks[idx] = { ...blocks[idx], patchData }
          set({ currentMessage: { ...currentMessage, blocks } })
        }
      },

      updateCurrentAssistantMessage: (blocks) => {
        const { currentMessage } = get()
        if (currentMessage) {
          set({ currentMessage: { ...currentMessage, blocks } })
        }
      },

      // ===== 问题块 =====
      appendQuestionBlock: (questionId, sessionId, questions) => {
        // 幂等守卫：桌面模式 ask 事件经直发 + 广播中继双通道送达，同一 questionId
        // 可能收到两次（ask 拉起帧与快照/重连双路径也可能重发 `question` 事件）。
        // 重复追加会让消息流出现两张相同的 AskQuestionCard，且 questionBlockMap 只
        // 指向最后一张导致前一张无法置为已答。与 form / plugin_card 的同 id 守卫一致。
        //
        // 注意：必须跨 messages[] + currentMessage 全局查重——若首帧已随本轮回复
        // 归档到 messages（finishMessage），重连/快照补发的同 id 帧会落到新的
        // currentMessage，只查 currentMessage 会再次追加一张卡片（实测复现双卡）。
        const { currentMessage, messages, questionBlockMap, streamingUpdateCounter } = get()
        const alreadyExists = !!currentMessage?.blocks.some(
          (b) => b.type === 'question' && b.id === questionId,
        ) || messages.some(
          (m) => m.type === 'assistant' && m.blocks?.some(
            (b) => b.type === 'question' && b.id === questionId,
          ),
        )
        if (alreadyExists) {
          return
        }

        // 兼容字段：填充首题摘要供旧消费方使用
        const first = questions[0]
        const block = {
          type: 'question' as const,
          id: questionId,
          sessionId,
          questions,
          status: 'pending' as const,
          // 兼容字段
          header: first?.question || first?.header,
          options: first?.options,
          multiSelect: first?.multiSelect,
          allowCustomInput: first?.allowCustomInput,
          categoryLabel: first && first.question && first.header ? first.header : undefined,
        }
        const newMap = new Map(questionBlockMap)
        if (!currentMessage) {
          newMap.set(questionId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            questionBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(questionId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            questionBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updateQuestionBlock: (questionId, payload) => {
        const { currentMessage, messages, questionBlockMap } = get()
        if (!currentMessage && messages.length === 0) return

        // 优先走 questionBlockMap 定位（question 事件在 currentMessage 中追加时记录）
        // 但 question 卡片若已随本轮回复归档到 messages（finishMessage 后用户才提交），
        // questionBlockMap 里的 idx 已失效；此时需跨 messages[] 搜索更新，
        // 与 updateFormBlock 的归档后回填模式一致。
        const applyToBlocks = (
          blocks: import('../../types/chat').ContentBlock[]
        ): { next: typeof blocks; changed: boolean } => {
          const next = blocks.map((b) => {
            if (b.type === 'question' && b.id === questionId) {
              const existing = b as import('../../types/chat').QuestionBlock
              const first = payload.answers?.[0]
              return {
                ...existing,
                // 只有 payload 显式传入时才覆盖，避免回滚时把既有 answers 抹成 undefined
                answers: payload.answers ?? existing.answers,
                declined: payload.declined ?? existing.declined,
                status: payload.status ?? ('answered' as const),
                // 兼容字段：首题摘要
                answer: first
                  ? {
                      selected: first.selected,
                      customInput: first.customInput,
                    }
                  : existing.answer,
              } as typeof b
            }
            return b
          })
          const changed = next.some((b, i) => b !== blocks[i])
          return { next, changed }
        }

        // 先查 currentMessage（含 map 定位与全文搜索兜底）
        if (currentMessage) {
          const idx = questionBlockMap.get(questionId)
          if (
            idx !== undefined &&
            currentMessage.blocks[idx]?.type === 'question' &&
            currentMessage.blocks[idx]?.id === questionId
          ) {
            const blocks = [...currentMessage.blocks]
            blocks[idx] = applyToBlocks(blocks).next[idx]!
            set({ currentMessage: { ...currentMessage, blocks } })
            return
          }
          const { next, changed } = applyToBlocks(currentMessage.blocks)
          if (changed) {
            set({ currentMessage: { ...currentMessage, blocks: next } })
            return
          }
        }

        // 跨 messages[] 搜索（卡片归档后用户提交的常见路径）
        let touched = false
        const newMessages = messages.map((msg) => {
          if (msg.type !== 'assistant' || !msg.blocks) return msg
          const { next, changed } = applyToBlocks(msg.blocks)
          if (!changed) return msg
          touched = true
          return { ...msg, blocks: next }
        })
        if (touched) {
          set({ messages: newMessages })
        }
      },

      // ===== Form（表单工具） =====
      appendFormBlock: (block) => {
        // 类型切换点：thinking 缓冲先落块再落卡片类块，保持块时序（C2 spec §二，
        // 与本入口既有的 text flush 同范式）
        if (_thinkingBuffer) get()._flushThinkingBuffer()
        if (_textBuffer) get()._flushTextBuffer()

        const { currentMessage, formBlockMap, streamingUpdateCounter } = get()
        const newMap = new Map(formBlockMap)

        // 幂等：同 id 表单不重复追加（拉起帧与历史恢复可能并发）。
        // 批 4a：查重范围扩到归档消息（session_end 后重发不再产生幽灵双卡，
        // 对齐 question 已修范式）
        if (hasBlockAnywhere(get(), 'form', block.id)) {
          return
        }

        if (!currentMessage) {
          newMap.set(block.id, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            formBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(block.id, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            formBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updateFormBlock: (formId, updates) => {
        const { currentMessage, messages, formBlockMap } = get()
        if (!currentMessage && messages.length === 0) return

        // 优先走 formBlockMap 定位（form 事件在 currentMessage 中追加时记录）
        // 但 form 事件若在流结束后到达（AI 回复已完成 → currentMessage 归档到 messages），
        // formBlockMap 里的 idx 已失效；此时需跨 messages[] + currentMessage 搜索。
        const applyToBlocks = (
          blocks: import('../../types/chat').ContentBlock[]
        ): { next: typeof blocks; changed: boolean } => {
          const next = blocks.map((b) => {
            if (b.type === 'form' && b.id === formId) {
              return { ...b, ...updates } as typeof b
            }
            return b
          })
          const changed = next.some((b, i) => b !== blocks[i])
          return { next, changed }
        }

        // 先查 currentMessage
        if (currentMessage) {
          const idx = formBlockMap.get(formId)
          if (
            idx !== undefined &&
            currentMessage.blocks[idx]?.type === 'form' &&
            currentMessage.blocks[idx]?.id === formId
          ) {
            const blocks = [...currentMessage.blocks]
            const existing = blocks[idx] as import('../../types/chat').FormBlock
            blocks[idx] = { ...existing, ...updates }
            set({ currentMessage: { ...currentMessage, blocks } })
            return
          }
          // currentMessage 里没有，但表单可能已归档到 messages
          const { next, changed } = applyToBlocks(currentMessage.blocks)
          if (changed) {
            set({ currentMessage: { ...currentMessage, blocks: next } })
            return
          }
        }

        // 跨 messages[] 搜索（消息归档后常见路径）
        let touched = false
        const newMessages = messages.map((msg) => {
          if (msg.type !== 'assistant' || !msg.blocks) return msg
          const { next, changed } = applyToBlocks(msg.blocks)
          if (!changed) return msg
          touched = true
          return { ...msg, blocks: next }
        })
        if (touched) {
          set({ messages: newMessages })
        }
      },

      // ===== PluginCard =====
      appendPluginCardBlock: (block) => {
        // 类型切换点：thinking 缓冲先落块再落卡片类块，保持块时序（C2 spec §二，
        // 与本入口既有的 text flush 同范式）
        if (_thinkingBuffer) get()._flushThinkingBuffer()
        if (_textBuffer) get()._flushTextBuffer()

        const { currentMessage, pluginCardBlockMap, streamingUpdateCounter } = get()
        const newMap = new Map(pluginCardBlockMap)

        // 幂等：同 id 卡片不重复追加（tool_call_end 与 plugin_card 事件可能并发到达）。
        // 批 4a：查重范围扩到归档消息（同 form/question 范式）
        if (hasBlockAnywhere(get(), 'plugin_card', block.id)) {
          return
        }

        if (!currentMessage) {
          newMap.set(block.id, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            pluginCardBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(block.id, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            pluginCardBlockMap: newMap,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updatePluginCardBlock: (id, updates) => {
        const { currentMessage, pluginCardBlockMap } = get()
        const patch = (b: AnyContentBlock): AnyContentBlock =>
          b.type === 'plugin_card'
            ? ({ ...b, ...updates } as typeof b)
            : b
        if (currentMessage) {
          const idx = pluginCardBlockMap.get(id)
          if (idx !== undefined && currentMessage.blocks[idx]?.type === 'plugin_card') {
            const blocks = [...currentMessage.blocks]
            blocks[idx] = patch(blocks[idx])
            set({ currentMessage: { ...currentMessage, blocks } })
            return
          }
        }
        // 批 4a（审计 4.2）：归档后到达的 plugin_card_answered——跨 messages[]
        // 回写，不再丢弃
        updateBlockAcrossSession(
          get, set,
          (b) => b.type === 'plugin_card' && b.id === id,
          patch,
        )
      },

      appendContextCompactBlock: (trigger, preTokens, postTokens) => {
        // 类型切换点：thinking 缓冲先落块再落卡片类块，保持块时序（C2 spec §二，
        // 与本入口既有的 text flush 同范式）
        if (_thinkingBuffer) get()._flushThinkingBuffer()
        if (_textBuffer) get()._flushTextBuffer()

        const block: import('../../types/chat').ContextCompactBlock = {
          type: 'context_compact',
          id: generateUUID(),
          trigger,
          preTokens,
          postTokens,
          createdAt: new Date().toISOString(),
        }

        const { currentMessage, streamingUpdateCounter } = get()
        if (!currentMessage) {
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          set({
            currentMessage: { ...currentMessage, blocks: [...currentMessage.blocks, block] },
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      // ===== PlanMode =====
      appendPlanModeBlock: (planId, sessionId, title?, description?, stages?) => {
        const { currentMessage, planBlockMap, streamingUpdateCounter } = get()
        const block = {
          type: 'plan_mode' as const,
          id: planId,
          sessionId,
          title: title ?? '执行计划',
          description,
          stages: stages ?? [],
          status: 'drafting' as const,
        }
        const newMap = new Map(planBlockMap)
        if (!currentMessage) {
          newMap.set(planId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            planBlockMap: newMap,
            activePlanId: planId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(planId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            planBlockMap: newMap,
            activePlanId: planId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updatePlanModeBlock: (planId, updates) => {
        const { currentMessage, planBlockMap } = get()
        if (!currentMessage) return
        const idx = planBlockMap.get(planId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        if (blocks[idx]?.type === 'plan_mode') {
          blocks[idx] = { ...blocks[idx], ...updates }
          set({ currentMessage: { ...currentMessage, blocks } })
        }
      },

      updatePlanStageStatus: (planId, stageId, status, tasks?) => {
        const { currentMessage, planBlockMap } = get()
        if (!currentMessage) return
        const idx = planBlockMap.get(planId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'plan_mode') return
        const stages = block.stages?.map((s) => (s.stageId === stageId ? { ...s, status, tasks: tasks ?? s.tasks } : s))
        blocks[idx] = { ...block, stages }
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      setActivePlan: (planId) => set({ activePlanId: planId }),

      // ===== AgentRun =====
      appendAgentRunBlock: (taskId, agentType, capabilities?) => {
        const { currentMessage, agentRunBlockMap, streamingUpdateCounter } = get()

        // 幂等守卫：流式与快照双路径会对同一 taskId 重发 AgentRunStart，不追加重复块
        if (agentRunBlockMap.has(taskId)) {
          return
        }

        const block = {
          type: 'agent_run' as const,
          id: taskId,
          agentType,
          capabilities: capabilities ?? [],
          status: 'running' as const,
          toolCalls: [],
          startedAt: new Date().toISOString(),
        }
        const newMap = new Map(agentRunBlockMap)
        if (!currentMessage) {
          newMap.set(taskId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            agentRunBlockMap: newMap,
            activeTaskId: taskId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(taskId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            agentRunBlockMap: newMap,
            activeTaskId: taskId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updateAgentRunBlock: (taskId, updates) => {
        const { currentMessage, agentRunBlockMap } = get()
        const patch = (b: AnyContentBlock): AnyContentBlock =>
          b.type === 'agent_run' ? ({ ...b, ...updates } as typeof b) : b
        if (currentMessage) {
          const idx = agentRunBlockMap.get(taskId)
          if (idx !== undefined && currentMessage.blocks[idx]?.type === 'agent_run') {
            const blocks = [...currentMessage.blocks]
            blocks[idx] = patch(blocks[idx])
            set({ currentMessage: { ...currentMessage, blocks } })
            return
          }
        }
        // 批 4a（审计 4.2）：归档后到达的 agent_run_end——跨 messages[] 回写
        updateBlockAcrossSession(
          get, set,
          (b) => b.type === 'agent_run' && b.id === taskId,
          patch,
        )
      },

      appendAgentToolCall: (taskId, toolId, toolName) => {
        const { currentMessage, agentRunBlockMap } = get()
        if (!currentMessage) return
        const idx = agentRunBlockMap.get(taskId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'agent_run') return
        blocks[idx] = {
          ...block,
          toolCalls: [...(block.toolCalls ?? []), { id: toolId, name: toolName, status: 'running' as const }],
        }
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      updateAgentToolCallStatus: (taskId, toolId, status, summary?) => {
        const { currentMessage, agentRunBlockMap } = get()
        if (!currentMessage) return
        const idx = agentRunBlockMap.get(taskId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'agent_run') return
        blocks[idx] = {
          ...block,
          toolCalls: block.toolCalls?.map((tc) =>
            tc.id === toolId ? { ...tc, status, summary } : tc
          ),
        }
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      setActiveTask: (taskId) => set({ activeTaskId: taskId }),

      // ===== TaskBoard（TaskCreate/Update/List 聚合，run 级单板幂等合并） =====
      ensureTaskBoard: (callId) => {
        const { currentMessage, taskBoardBlockMap, activeTaskBoardId, streamingUpdateCounter } = get()
        // 已有活动板则复用
        if (activeTaskBoardId && taskBoardBlockMap.has(activeTaskBoardId)) {
          return activeTaskBoardId
        }
        const boardId = callId
        const block: TaskBoardBlock = {
          type: 'task_board',
          id: boardId,
          items: [],
          completed: 0,
          inProgress: 0,
          blocked: 0,
          total: 0,
          updatedAt: new Date().toISOString(),
        }
        const newMap = new Map(taskBoardBlockMap)
        if (!currentMessage) {
          newMap.set(boardId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            taskBoardBlockMap: newMap,
            activeTaskBoardId: boardId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(boardId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            taskBoardBlockMap: newMap,
            activeTaskBoardId: boardId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
        return boardId
      },

      upsertTaskBoardItem: (boardId, item) => {
        const { currentMessage, taskBoardBlockMap } = get()
        if (!currentMessage) return
        const idx = taskBoardBlockMap.get(boardId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'task_board') return
        const items = [...block.items]
        const existingIdx = items.findIndex(it => it.id === item.id)
        if (existingIdx >= 0) {
          // 幂等合并：保留已有 updateCount/description，patch 新字段
          const prev = items[existingIdx]
          items[existingIdx] = {
            ...prev,
            ...item,
            updateCount: (prev.updateCount ?? 0) + 1,
            description: item.description ?? prev.description,
          }
        } else {
          items.push({ ...item, updateCount: 0 })
        }
        blocks[idx] = recomputeTaskBoard(block, items)
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      patchTaskBoardItem: (boardId, taskId, patch) => {
        const { currentMessage, taskBoardBlockMap } = get()
        if (!currentMessage) return
        const idx = taskBoardBlockMap.get(boardId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'task_board') return
        const items = [...block.items]
        const existingIdx = items.findIndex(it => it.id === taskId)
        if (existingIdx >= 0) {
          const prev = items[existingIdx]
          items[existingIdx] = {
            ...prev,
            ...patch,
            updateCount: (prev.updateCount ?? 0) + 1,
          }
        } else {
          // 未知 id：降级新建为 pending（PRD 验收 E1）
          items.push({
            id: taskId,
            subject: patch.subject ?? patch.activeForm ?? taskId,
            status: patch.status ?? 'pending',
            ...patch,
            updateCount: 0,
          })
        }
        blocks[idx] = recomputeTaskBoard(block, items)
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      syncTaskBoardFromList: (boardId, snapshotItems) => {
        const { currentMessage, taskBoardBlockMap } = get()
        if (!currentMessage) return
        const idx = taskBoardBlockMap.get(boardId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        const block = blocks[idx]
        if (block?.type !== 'task_board') return
        // 校准：不覆盖已有更精确状态（in_progress/completed 优先于快照）
        const items = [...block.items]
        for (const snap of snapshotItems) {
          const existingIdx = items.findIndex(it => it.id === snap.id)
          if (existingIdx >= 0) {
            // 仅在快照状态更靠后时才更新
            items[existingIdx] = { ...items[existingIdx], ...snap }
          } else {
            items.push({ ...snap, updateCount: 0 })
          }
        }
        blocks[idx] = recomputeTaskBoard(block, items)
        set({ currentMessage: { ...currentMessage, blocks } })
      },

      queueTaskCreate: (boardId, entry) => {
        const { pendingTaskCreates } = get()
        set({ pendingTaskCreates: [...pendingTaskCreates, { boardId, entry }] })
      },

      flushTaskCreate: (boardId, taskId) => {
        const { pendingTaskCreates } = get()
        if (!pendingTaskCreates.length) return
        const idx = pendingTaskCreates.findIndex(e => e.boardId === boardId)
        if (idx < 0) return
        const entry = pendingTaskCreates[idx]
        set({ pendingTaskCreates: pendingTaskCreates.filter((_, i) => i !== idx) })
        // 无真实 id 时降级为 uuid（PRD 验收 E1 健壮性）
        const item: TaskBoardItem = {
          id: taskId || generateUUID(),
          subject: entry.entry.subject,
          activeForm: entry.entry.activeForm,
          description: entry.entry.description,
          status: 'pending',
        }
        get().upsertTaskBoardItem(boardId, item)
      },

      // ===== PermissionRequest =====
      appendPermissionRequestBlock: (requestId, sessionId, denials) => {
        const { currentMessage, permissionRequestBlockMap, streamingUpdateCounter } = get()
        // 归一化每个 denial：兼容后端 flatten 的 snake_case（tool_input/tool_use_id），
        // 提取为 toolInput/toolUseId，并初始化逐项决策状态为 pending。
        // 空 denials（plan 审批复用此方法）天然为空数组，行为不变。
        const normalizedDenials = denials.map(d => {
          const raw = d as Record<string, unknown>
          return {
            toolName: d.toolName,
            reason: d.reason,
            toolInput: (d.toolInput ?? raw.tool_input) as Record<string, unknown> | undefined,
            toolUseId: (d.toolUseId ?? raw.tool_use_id) as string | undefined,
            status: 'pending' as const,
            extra: d.extra,
          }
        })
        const block = {
          type: 'permission_request' as const,
          id: requestId,
          sessionId,
          denials: normalizedDenials,
          status: 'pending' as const,
        }
        const newMap = new Map(permissionRequestBlockMap)
        if (!currentMessage) {
          newMap.set(requestId, 0)
          set({
            currentMessage: createCurrentAssistantMessage([block]),
            permissionRequestBlockMap: newMap,
            activePermissionRequestId: requestId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        } else {
          const blocks = [...currentMessage.blocks, block]
          newMap.set(requestId, blocks.length - 1)
          set({
            currentMessage: { ...currentMessage, blocks },
            permissionRequestBlockMap: newMap,
            activePermissionRequestId: requestId,
            streamingUpdateCounter: streamingUpdateCounter + 1,
          })
        }
      },

      updatePermissionRequestBlock: (requestId, status, decision?) => {
        const { currentMessage, permissionRequestBlockMap } = get()
        if (!currentMessage) return
        const idx = permissionRequestBlockMap.get(requestId)
        if (idx === undefined) return
        const blocks = [...currentMessage.blocks]
        if (blocks[idx]?.type === 'permission_request') {
          blocks[idx] = { ...blocks[idx], status, decision }
          set({ currentMessage: { ...currentMessage, blocks }, activePermissionRequestId: status === 'pending' ? requestId : null })
        }
      },

      setActivePermissionRequest: (requestId) => set({ activePermissionRequestId: requestId }),

      resolvePermissionRequest: (requestId, perItem) => {
        // 逐项落库决策（status/scope），并据此推导整卡状态：任一批准→approved，否则 denied。
        // 同时扫描当前流式消息与已归档消息（块可能已被 session_end 归档），保证刷新/重载一致。
        const applyToBlocks = (blocks: import('../../types/chat').ContentBlock[]) => {
          let changed = false
          const next = blocks.map(b => {
            if (b.type === 'permission_request' && b.id === requestId && b.status === 'pending') {
              changed = true
              const denials = b.denials.map((d, i) => {
                const dec = perItem[i]
                return dec ? { ...d, status: dec.status, scope: dec.scope } : d
              })
              const anyApproved = denials.some(d => d.status === 'approved')
              return {
                ...b,
                denials,
                status: (anyApproved ? 'approved' : 'denied') as 'approved' | 'denied',
                decision: { approved: anyApproved, timestamp: new Date().toISOString() },
              }
            }
            return b
          })
          return changed ? next : null
        }

        const { currentMessage, messages } = get()
        const nextCurrent = currentMessage ? applyToBlocks(currentMessage.blocks) : null
        let messagesChanged = false
        const nextMessages = messages.map(m => {
          if (m.type === 'assistant' && m.blocks) {
            const nb = applyToBlocks(m.blocks)
            if (nb) { messagesChanged = true; return { ...m, blocks: nb } }
          }
          return m
        })

        if (nextCurrent || messagesChanged) {
          set({
            ...(nextCurrent && currentMessage ? { currentMessage: { ...currentMessage, blocks: nextCurrent } } : {}),
            ...(messagesChanged ? { messages: nextMessages } : {}),
            activePermissionRequestId: null,
          })
        }
      },

      expireStalePermissionRequests: () => {
        // 失效仍待处理的「工具权限请求」：仅 status==='pending' 且有真实 denials 的块。
        // 跳过 plan 审批复用的空 denials 块（不影响其原流程）。
        // 触发时机：用户发新消息 / 历史会话恢复——卡片绑定的后端等待点已不再有效。
        const expireInBlocks = (blocks: import('../../types/chat').ContentBlock[]) => {
          let changed = false
          const next = blocks.map(b => {
            if (b.type === 'permission_request' && b.status === 'pending' && b.denials.length > 0) {
              changed = true
              return { ...b, status: 'expired' as const }
            }
            return b
          })
          return changed ? next : null
        }

        const { currentMessage, messages } = get()
        const nextCurrent = currentMessage ? expireInBlocks(currentMessage.blocks) : null
        let messagesChanged = false
        const nextMessages = messages.map(m => {
          if (m.type === 'assistant' && m.blocks) {
            const nb = expireInBlocks(m.blocks)
            if (nb) { messagesChanged = true; return { ...m, blocks: nb } }
          }
          return m
        })

        if (nextCurrent || messagesChanged) {
          set({
            ...(nextCurrent && currentMessage ? { currentMessage: { ...currentMessage, blocks: nextCurrent } } : {}),
            ...(messagesChanged ? { messages: nextMessages } : {}),
            ...(get().activePermissionRequestId ? { activePermissionRequestId: null } : {}),
          })
        }
      },

      addSessionAllowedTools: (tools) => {
        if (!tools || tools.length === 0) return
        const cur = get().sessionAllowedTools
        const merged = [...new Set([...cur, ...tools])]
        // 仅在确有新增时 set，避免无意义的状态更新触发重渲染
        if (merged.length !== cur.length) set({ sessionAllowedTools: merged })
      },

      // ===== 会话控制 =====
      setConversationId: (id) => set({ conversationId: id }),
      setStreaming: (streaming) => set({ isStreaming: streaming }),
      setError: (error) => set({ error }),
      setProgressMessage: (message) => set({ progressMessage: message }),
      setPromptSuggestion: (suggestion) => set({ promptSuggestion: suggestion }),

      // ===== 历史恢复 =====
      setMessagesFromHistory: (messages, conversationId, paging) => {
        // 清除旧会话的压缩快照，避免快照与消息不匹配
        compactor.clearSnapshots()
        _lastCompactionRange = null // 重置压缩范围，防止旧范围阻止新会话首次压缩

        // checkpoint 残留归一：历史恢复后已无流式，将 isStreaming 快照统一归一为
        // 中断态（isStreaming:false + interrupted:true），避免末条半条被当成"进行中"
        const baseMessages = normalizeRecoveredMessages(messages)

        // 为已完成的 Edit 工具回填 diffData（历史消息可能缺失）
        const processedMessages = baseMessages.map(msg => {
          if (msg.type !== 'assistant' || !msg.blocks) return msg
          let modified = false
          const blocks = msg.blocks.map(block => {
            if (
              block.type === 'tool_call' &&
              block.status === 'completed' &&
              !block.diffData &&
              isEditTool(block.name)
            ) {
              const diff = extractEditDiff(block)
              if (diff) {
                modified = true
                return { ...block, diffData: diff }
              }
            }
            // 历史恢复：仍待处理的「工具权限请求」一律失效（后端那一轮已结束，不可再授权）。
            // 仅作用于有真实 denials 的块，跳过 plan 审批复用的空 denials 块。
            if (
              block.type === 'permission_request' &&
              block.status === 'pending' &&
              block.denials.length > 0
            ) {
              modified = true
              return { ...block, status: 'expired' as const }
            }
            // 历史恢复：仍 pending 的交互型插件卡片一律置为 declined
            // （后端 oneshot 已随进程退出而 drop，无法再回填 tool_result）
            if (
              block.type === 'plugin_card' &&
              block.mode === 'interaction' &&
              block.status === 'pending'
            ) {
              modified = true
              return { ...block, status: 'declined' as const }
            }
            // 历史恢复：仍 pending 的表单一律置为已跳过（进程重启后 form_holds
            // 已清空，迟到的 form_submit/form_skip 会被服务端拒绝）。展示为只读
            // 跳过回执，提示重新发起。
            if (block.type === 'form' && block.status === 'pending') {
              modified = true
              return {
                ...block,
                status: 'skipped' as const,
                ok: false,
                receipt: '表单已失效（会话中断或超时），请让 AI 重新发起',
              }
            }
            return block
          })
          return modified ? { ...msg, blocks } : msg
        })

        set({
          messages: processedMessages,
          archivedMessages: [],
          conversationId,
          isStreaming: false,
          error: null,
          currentMessage: null,
          progressMessage: null,
          visibleRange: null,
          // 加载新会话历史时重置用量水位，避免沿用上一会话的数字
          usageStats: null,
          streamRate: null,
          // 恢复的消息本就来自磁盘 → 水位直接对齐，避免下轮 session_start 全量重刷；
          // Fork（conversationId=null）水位归零，首轮 session_start 把完整历史写入新文件
          persistedSeq: conversationId ? processedMessages.length : 0,
          persistedConversationId: conversationId,
          // 尾部优先恢复：记录向上翻页游标（无分页信息 = 已全量在内存）
          historyPaging: paging ?? null,
          // 历史恢复 = 会话内容重置，清空待发送队列（避免上一会话残留）
          pendingQueue: [],
        })
      },

      /**
       * 流式接续（跨端加入/断线恢复）：把快照末条 assistant 接续为 currentMessage，
       * 后续实时 token 走正常流式追加。见 types.ts 方法注释（不接续会卡死页面）。
       */
      resumeStreamingFromLastAssistant: () => {
        const { messages } = get()
        const last = messages[messages.length - 1]
        if (last && last.type === 'assistant') {
          // 重建 toolBlockMap：流式工具块更新按 id 定位依赖它
          const newMap = new Map<string, number>()
          ;(last.blocks ?? []).forEach((b, idx) => {
            if (b.type === 'tool_call') newMap.set(b.id, idx)
          })
          set({
            messages: messages.slice(0, -1),
            currentMessage: { ...last, isStreaming: true },
            toolBlockMap: newMap,
            isStreaming: true,
          })
        } else {
          // 末条是 user（已发消息未回）：token 到达走正常新建路径
          set({ isStreaming: true })
        }
      },

      // ===== 事件处理 =====
      handleAIEvent: (event) => handleAIEvent(event, set, get),

      // 轮次代际观测（spec F1）：见 types.ts observeTurnEvent 注释。
      // 由 sessionStoreManager 在事件入口调用，返回 false 时整事件丢弃——
      // 修复「旧轮迟到的 session_end/error 落在新轮流式期间，误杀新一轮」。
      observeTurnEvent: (turnId, eventType) => {
        const isTerminal = eventType === 'session_end' || eventType === 'error'
        const current = get().activeTurnId
        if (!isTerminal) {
          if (current !== turnId) {
            // 新轮首事件到达即重挂流式态：超时兜底路径下旧轮 session_end 可能
            // 先于新轮事件到达（activeTurnId 仍指旧轮 → 未被过滤）而把
            // isStreaming 置 false；新轮事件继续流入时据此恢复真实流式态。
            set({
              activeTurnId: turnId,
              ...(get().isStreaming ? {} : { isStreaming: true }),
            })
          }
          return true
        }
        // 终态：activeTurnId 未观测过（null）时无法判定新旧，放行保持旧语义
        return current === null || current === turnId
      },

      // ===== 主动操作 =====

      // ===== 待发送队列（流式预输入 / 多行拆分入队） =====
      // 纯前端内存态、绑定会话生命周期。AI 流式回复期间用户提交的消息入队，
      // session_end 后由 dispatchNextPending 自动逐条发送；不落盘、不进入 messages 流。
      enqueuePending: (message) => {
        set((state) => ({ pendingQueue: [...state.pendingQueue, message] }))
      },
      removePending: (id) => {
        set((state) => ({ pendingQueue: state.pendingQueue.filter((m) => m.id !== id) }))
      },
      clearPendingQueue: () => {
        set({ pendingQueue: [] })
      },
      dispatchNextPending: async () => {
        const st = get()
        // 幂等守卫：正在流式 / 已有队列消息在派发（互斥锁）/ 队列为空时直接返回
        if (st.isStreaming || st.queueDispatching || st.pendingQueue.length === 0) return

        const [next, ...rest] = st.pendingQueue
        // 派发中置 status='sending' 供 UI 展示（正在发的条目锁定编辑/删除）
        set({
          pendingQueue: rest,
          queueDispatching: true,
        })
        let accepted = false
        try {
          // 走真实发送链路（内部会 set isStreaming=true，启动新一轮流式）。
          // 返回值：true 已受理 / false 发送失败（sendMessage catch 已置 error + isStreaming=false）
          accepted = await get().sendMessage(next.text, undefined, next.attachments)
        } finally {
          set({ queueDispatching: false })
        }
        if (!accepted) {
          // 失败：队首放回（保留消息，不静默丢失），并终止本轮派发。
          // 不加自动重试——失败可能是引擎不可用/会话丢失，交给用户手动重发
          // （点「立即发送」或下次 session_end 再触发）。
          set((state) => ({
            pendingQueue: [{ ...next, status: 'queued' }, ...state.pendingQueue],
          }))
          try {
            const { useToastStore } = await import('../../shims/stores')
            useToastStore.getState().error(
              i18n.t('chat:input.sendFailedQueued', '发送失败，已保留在待发队列，可点击「立即发送」重试')
            )
          } catch (toastErr) {
            log.warn('Toast 提示失败', { error: String(toastErr) })
          }
          return
        }
        // 发送成功（已受理）且队列中还有剩余且当前已空闲，继续发送下一条
        const after = get()
        if (after.pendingQueue.length > 0 && !after.isStreaming) {
          void get().dispatchNextPending()
        }
      },

      // 立即发送队列中的指定条目（PendingQueueCard 点击「立即发送」）。
      // 从队列取出该条；若正在流式则先中断并等待本轮收尾（session_end / 5s 兜底），
      // 再走 sendMessage 开启新一轮。与自动派发（dispatchNextPending）互补，可随时提前发。
      sendPendingNow: async (id) => {
        const st = get()
        const target = st.pendingQueue.find((m) => m.id === id)
        if (!target || st.queueDispatching) return
        // 补丁 C：占用互斥锁（贯穿中断等待），防止中断兜底路径的 dispatchNextPending
        // 趁机派发下一条造成双发/乱序；与 dispatchNextPending 的 queueDispatching 互斥。
        set({ queueDispatching: true })
        try {
          // 补丁 B：发起时捕获 conversationId 代际标记，等待中断期间用户可能切会话。
          // 移除动作后移到「校验通过后」执行，消除「先移除后校验失败 → 消息丢」的窗口。
          const originConversationId = st.conversationId
          // 流式中：先中断当前回复并等待本轮回流真正结束。
          // 批 4d（审计 4.9）：interrupt 已有 8s invoke 超时 + 5s 定时器兜底，
          // 外层再设 16s 硬界——后端彻底死亡时不再无限持锁卡死整个待发队列。
          // spec F3：interrupt() 现已内置「等 session_end 复位」的有界等待，
          // 此处二级等待仅为衔接性兜底（如 session_end 事件在传输中延迟）。
          if (st.isStreaming) {
            await Promise.race([
              get().interrupt().catch(() => undefined),
              new Promise((r) => setTimeout(r, 16000)),
            ])
            await waitFor(() => !get().isStreaming, 2000)
            if (get().isStreaming) {
              // 有界等待仍未复位：本地强制收尾（等价 interrupt 兜底路径），解锁队列。
              // 引擎侧正确性由后端轮次互斥（spec B1）与本端终态代际过滤（F1）保证。
              set({ isStreaming: false, isInterrupting: false, progressMessage: null })
              get().finishMessage()
            }
          }
          // 代际校验：中断等待期间用户切换会话 / 开新会话 → 不把旧会话的消息发到新会话。
          const after = get()
          if (after.conversationId !== originConversationId) {
            // 尊重用户显式取消：若期间队列已被 clear/remove 该条，则丢弃不恢复；
            // 否则放回队首，等待用户在新会话下自行处理。
            const stillQueued = after.pendingQueue.some((m) => m.id === id)
            if (stillQueued) {
              set((state) => ({
                pendingQueue: [{ ...target, status: 'queued' }, ...state.pendingQueue],
              }))
            }
            return
          }
          // 校验通过：从队列移除（此刻才真正出队，防止上面校验失败时消息已丢）
          set({ pendingQueue: after.pendingQueue.filter((m) => m.id !== id) })
          await get().sendMessage(target.text, undefined, target.attachments)
        } finally {
          set({ queueDispatching: false })
        }
      },

      // 撤回队列项到输入框草稿（PendingQueueCard 点击「编辑」）。
      // 语义（对齐 ZCode handleEditQueueItem）：
      //   ① 草稿冲突守卫：输入框已有内容/busy → 拒绝（避免覆盖用户正在写的消息）；
      //   ② 从队列移除该条（纯前端队列删除即成功，无后端 ACK 等待）；
      //   ③ 恢复原文到 inputDraft —— ChatInput 的 inputDraft effect 自动同步到输入框，
      //      再触发 'chat:focus-input' 事件聚焦。
      editPending: (id) => {
        const st = get()
        const target = st.pendingQueue.find((m) => m.id === id)
        if (!target) return
        // 正在发送的条目不可撤回（避免与派发中状态冲突）
        if (target.status === 'sending') return
        const draft = st.inputDraft
        if ((draft.text?.trim() ?? '') || (draft.attachments?.length ?? 0) > 0) {
          // 草稿冲突守卫：不覆盖用户正在编辑的内容
          try {
            void import('../../shims/stores').then(({ useToastStore }) => {
              useToastStore.getState().error(
                i18n.t('chat:input.editPendingDraftConflict', '输入框已有内容，请先清空或发送后再撤回队列消息')
              )
            })
          } catch (toastErr) {
            log.warn('Toast 提示失败', { error: String(toastErr) })
          }
          return
        }
        // 移除队列项 + 恢复草稿
        set((state) => ({
          pendingQueue: state.pendingQueue.filter((m) => m.id !== id),
          inputDraft: {
            text: target.text,
            attachments: target.attachments ?? [],
            contextBlocks: [],
          },
        }))
        // 聚焦输入框（复用 ChatInput 现有 'chat:focus-input' 监听）
        try {
          eventBus.emit('chat:focus-input', undefined)
        } catch {
          // eventBus 不可用则跳过聚焦（草稿已恢复，输入框 effect 仍会同步）
        }
      },

      sendMessage: async (content, workspaceDir?, attachments?, sendOptions?) => {
        const { conversationId, sessionId, messages } = get()
        const config = deps.getConfig()
        const engine = resolveSessionEngine(sessionId, config?.defaultEngine)

        // 失效收口：用户发出新消息时，将仍待处理的工具权限请求标记为已失效
        // （卡片绑定上一轮后端等待点，新消息推进后不再可授权）。
        get().expireStalePermissionRequests()

        // 如果存在未完成的流式消息（如 AI 提问等待回答），先归档到 messages
        if (get().currentMessage) {
          get().finishMessage()
        }

        const currentWorkspace = deps.getWorkspace()
        const actualWorkspaceDir = workspaceDir || currentWorkspace?.path

        // 构建工作区提示词
        const { workspacePrompt, userPrompt, contextWorkspaces, allWorkspaces } =
          buildWorkspacePrompts(deps.getWorkspace, deps.getContextWorkspaceIds, deps.getAllWorkspaces)

        // 解析工作区引用
        const { processedMessage } = parseWorkspaceReferences(
          content,
          allWorkspaces,
          contextWorkspaces,
          currentWorkspace?.id || null
        )

        log.info('sendMessage debug', {
          sessionId,
          conversationId,
          providedWorkspaceDir: workspaceDir,
          actualWorkspaceDir,
          currentWorkspace: currentWorkspace ? { id: currentWorkspace.id, name: currentWorkspace.name, path: currentWorkspace.path } : null,
          workspacePromptLength: workspacePrompt.length,
          userPromptLength: userPrompt?.length ?? 0,
        })

        // 构建用户消息
        const userMessage = {
          id: generateUUID(),
          type: 'user' as const,
          content,
          timestamp: new Date().toISOString(),
          attachments: attachments?.map(a => ({
            id: a.id,
            type: a.type,
            fileName: a.fileName,
            fileSize: a.fileSize,
            mimeType: a.mimeType,
          })),
        }
        // 预生成本轮 assistant 消息 id：前端 currentMessage 与后端 turn_persist 共用，
        // 从源头消除 id 漂移（同一轮回复不再被赋予不同 id）。
        const assistantMessageId = generateUUID()
        _pendingAssistantMessageId = assistantMessageId
        get().addMessage(userMessage)

        if (messages.length === 0) {
          // 首轮用户消息：用本地截断标题（取前 16 字符），即时可见。
          // AI 自动标题生成已停用（避免无限递归：标题生成会话自身也会触发标题生成）。
          const placeholder = generateTitleFromMessage(content)
          sessionStoreManager.getState().updateSessionTitle(sessionId, placeholder)
        }

        get().clearInputDraft()

        set({
          isStreaming: true,
          error: null,
          currentMessage: null,
          toolBlockMap: new Map(),
          taskBoardBlockMap: new Map(),
          activeTaskBoardId: null,
          pendingTaskCreates: [],
          // 乐观计时起点（spec：续聊兜底）。SimpleAI 等引擎续聊不发 session_start
          // 事件，若等它来录起点，后续轮次将永远不计时；此处以发送时刻乐观起算，
          // 真实 session_start 到达后由其 receivedAtMs 覆盖（同一轮，不双计）。
          // 静默会话（标题生成/压缩交接触发的 sendMessage）不计入用户可见时长，
          // 与 eventHandler session_start/session_end 的 silentMode 守卫保持一致。
          runStartAtMs: (() => {
            try {
              const meta = sessionStoreManager.getState().sessionMetadata.get(sessionId)
              return meta?.silentMode ? null : Date.now()
            } catch {
              return Date.now()
            }
          })(),
          // 批 4b（审计 4.1）：轮次代际 +1——interrupt 兜底定时器等跨轮回调
          // 据此识别旧轮次，不再误杀新一轮流式
          turnEpoch: get().turnEpoch + 1,
        })

        try {
          const router = deps.getEventRouter()
          await router.initialize()

          const attachmentsForBackend = attachments?.map(a => ({
            type: a.type,
            fileName: a.fileName,
            mimeType: a.mimeType,
            content: a.content,
            textContent: a.textContent,
          }))

          const sessionConfig = getSessionConfig()
          const runtimeConfig = resolveRuntimeConfigForEngine(sessionConfig, engine)
          // P1: 会话级 Profile 绑定（三态解析）— 会话覆盖（含「明确官方」哨兵）优先，
          // 降级状态栏镜像，再降级设置页激活的全局默认；返回 undefined 表示走官方端点。
          const sessionMeta = sessionStoreManager.getState().sessionMetadata.get(get().sessionId)
          const modelProfileId = resolveEffectiveProfileId(
            sessionMeta?.modelProfileId,
            sessionConfig.modelProfileId,
            getActiveModelProfile()?.id,
          )
          // P2: 供应商模式解析（官方/指定 Profile 二态）。
          // 与 modelProfileId 成对解析；official 时防御性清空 modelProfileId
          // （即使残留旧 Profile，也绝不向官方请求携带，防穿透）。
          const profileMode = resolveEffectiveProfileMode(
            sessionMeta?.profileMode,
            sessionConfig.profileMode,
          )
          const effectiveProfileId = isProfileModeWithoutProfile(profileMode)
            ? undefined
            : modelProfileId
          // 当前生效 Profile 的完整配置，用于归一化模型名（见 normalizeModelForProfile）
          const effectiveProfile = getModelProfileById(effectiveProfileId)
          // 会话级模型优先，未设置时降级到全局 sessionConfig 解析结果（resolveRuntimeConfigForEngine）。
          // Profile 归一化：选了 Profile 但模型是它不认的 Claude 别名（opus/sonnet/haiku）时清空，
          // 回退 profile.model 默认；官方 API 路径 effectiveProfile 为空，别名不受影响。
          const resolvedModel = normalizeModelForProfile(
            sessionMeta?.model ?? runtimeConfig.model,
            effectiveProfile,
          )
          const disabledMcpServers = getDisabledPluginMcpServers()

          // 一次性系统提示（语音伙伴人格等）：经 appendSystemPrompt 通道注入，
          // 仅本次请求生效，不出现在消息流中
          // 待发送简报（压缩交接产物）也经此通道作为一次性上下文带出，随后清空。
          // 派发任务完成报告同理（结果回流：主 AI 无需用户转述即知晓后台任务结果）。
          const pendingBriefing = get().pendingBriefing
          const dispatchReportText = formatPendingDispatchReports(sessionId)
          const oneTimeParts = [
            pendingBriefing
              ? i18n.t('chat:compactHandoff.contextPreamble', { briefing: pendingBriefing })
              : '',
            dispatchReportText,
            sendOptions?.oneTimeSystemPrompt ?? '',
          ].filter(Boolean)
          const appendPrompt = oneTimeParts.length > 0
            ? `${workspacePrompt}\n\n${oneTimeParts.join('\n\n')}`
            : workspacePrompt
          if (pendingBriefing) {
            set({ pendingBriefing: null })
          }

          const clientDescriptor = detectClientDescriptor()
          const chatOptions = {
            appendSystemPrompt: normalizeForInvoke(appendPrompt),
            systemPrompt: userPrompt ? normalizeForInvoke(userPrompt) : null,
            workDir: actualWorkspaceDir,
            contextId: deps.contextId,
            engineId: engine,
            enableMcpTools: true,
            disabledMcpServers,
            attachments: attachmentsForBackend,
            additionalDirs: contextWorkspaces.map(w => w.path).filter(Boolean),
            agent: sendOptions?.runtimeOverride?.agent ?? sessionMeta?.agent ?? runtimeConfig.agent,
            model: resolvedModel,
            effort: sendOptions?.runtimeOverride?.effort ?? sessionMeta?.effort ?? runtimeConfig.effort,
            permissionMode: sendOptions?.runtimeOverride?.permissionMode ?? sessionMeta?.permissionMode ?? runtimeConfig.permissionMode,
            allowedTools: sendOptions?.allowedTools && sendOptions.allowedTools.length > 0
              ? sendOptions.allowedTools
              : undefined,
            modelProfileId: effectiveProfileId,
            profileMode,
            clientMessageId: userMessage.id,
            assistantMessageId,
            clientType: clientDescriptor.clientType,
            clientPlatform: clientDescriptor.clientPlatform,
            deviceId: clientDescriptor.deviceId || undefined,
          }

          if (conversationId) {
            await aiChatDispatchStream({
              action: 'continue',
              sessionId: conversationId,
              message: normalizeForInvoke(processedMessage),
              options: chatOptions,
            })
          } else {
            const sessionMeta = sessionStoreManager.getState().sessionMetadata.get(sessionId)
            const forkSessionId = sessionMeta?.forkFromId

            const newSessionId = await aiChatDispatch<string>({
              action: 'start',
              message: normalizeForInvoke(processedMessage),
              options: {
                ...chatOptions,
                forkSessionId: forkSessionId || undefined,
              },
            })
            set({ conversationId: newSessionId })
          }

          // 乐观置 running（spec F2）：SimpleAI 等引擎续聊不发 session_start 事件，
          // 而元数据 status 只认 session_start 置 running——中断后再发消息起会话
          // 格子永远灰点（「会话没有启动中」）。dispatch 受理即置 running，
          // 失败终态由后续 error/session_end 事件经 dispatchEvent 纠正。
          // background-running（用户显式转后台）不覆盖。
          try {
            const mgrState = sessionStoreManager.getState()
            const meta = mgrState.sessionMetadata.get(sessionId)
            if (meta && meta.status !== 'running' && meta.status !== 'background-running') {
              const newMetadata = new Map(mgrState.sessionMetadata)
              newMetadata.set(sessionId, {
                ...meta,
                status: 'running',
                updatedAt: new Date().toISOString(),
              })
              sessionStoreManager.setState({ sessionMetadata: newMetadata })
            }
          } catch {
            /* 元数据更新失败不阻断发送 */
          }
          return true
        } catch (e) {
          const err = e instanceof Error ? e : new Error(String(e))
          log.error('sendMessage failed', err, { sessionId, conversationId, workspaceDir: actualWorkspaceDir })
          // 批 4c（审计 4.4/5.2）：失败事务化——回滚乐观用户消息 + 恢复草稿。
          // 此前失败消息留在界面却从未进引擎上下文（UI/引擎历史从此分叉），
          // 且输入已被清空、ErrorBanner 重试再追加一条造成内容重复。
          const draftNow = get().inputDraft
          const draftEmpty = !draftNow?.text && (!draftNow?.attachments || draftNow.attachments.length === 0)
          set({
            error: resolveChatError(e, { sessionId, workspaceDir: actualWorkspaceDir }),
            isStreaming: false,
            currentMessage: null,
            progressMessage: null,
            // 乐观计时起点对本轮失效：发送失败无真实轮次，清空避免残留起点
            // 被未来迟到的 session_end 误结算（否则误累加一大段墙面时间）
            runStartAtMs: null,
            // 回滚本轮乐观追加的用户消息（未进引擎上下文，不该留在历史）
            messages: get().messages.filter((m) => m.id !== userMessage.id),
          })
          if (draftEmpty) {
            // 恢复草稿（用户未输入新内容时回填，含附件；不覆盖新输入）
            get().updateInputDraft({
              text: content,
              attachments: attachments ?? [],
              contextBlocks: [],
            })
          }
          return false
        }
      },

      settleSessionElapsedMs: () => {
        const runStart = get().runStartAtMs
        if (runStart == null) return
        const delta = Math.max(0, Date.now() - runStart)
        set((s) => ({
          sessionElapsedMs: s.sessionElapsedMs + delta,
          runStartAtMs: null,
          // 记录最近完成一轮时长：会话结束后折叠态继续显示「刚才那轮」而非回 0
          lastTurnMs: delta,
        }))
      },

      interrupt: async () => {
        const { conversationId, isStreaming } = get()
        if (!conversationId || !isStreaming) return

        const config = deps.getConfig()
        const engine = resolveSessionEngine(get().sessionId, config?.defaultEngine)

        log.info('Attempting to interrupt session', { conversationId, engine, isStreaming })

        // 仅标记主动中断。不提前 set({ isStreaming: false })、不调 finishMessage()：
        // 否则 UI 先经历一次"流式停止但消息未就位"的过渡，随后 session_end 又触发
        // 一次 finishMessage 把 currentMessage 移到 messages，两次渲染之间出现闪烁。
        // 正确做法：把 isStreaming=false 与 finishMessage 的单一过渡交给
        // session_end handler 一次性完成。
        set({ isInterrupting: true })

        try {
          // 批 4d（审计 4.9）：invoke 挂起兜底——后端死亡时 interrupt 的 dispatch
          // 可能永不 resolve（其内部 5s 定时器在 invoke resolve 后才启动，救不了
          // 这条路），此处 8s 有界等待，超时按失败处理走强制收尾 + toast。
          const interruptInvoke = aiChatDispatch({ action: 'interrupt',
            sessionId: conversationId,
            engineId: engine,
          })
          const invokeTimeout = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('interrupt invoke 超时（后端无响应）')), 8000),
          )
          await Promise.race([interruptInvoke, invokeTimeout])
          log.info('Session interrupted, waiting for backend session_end to finalize', {
            conversationId,
          })

          // 中断 ACK ≠ 引擎已停（spec F3）：ACK 只代表 abort 信号已置位，引擎要到
          // 下一个检查点才退出（工具执行/压缩摘要等窗口内更长）。此前此处直接
          // resolve，调用方（sendPendingNow/删除截断）拿到「已停」假象照常推进，
          // 撞上后端旧轮未退出的竞态。改为有界等待 session_end 收尾（isStreaming
          // 复位）再 resolve：正常路径毫秒级；引擎卡死时由上方 5s 兜底定时器强制
          // 收尾解锁，本等待随之满足（8s 上界仅为极端双保险）。
          await waitFor(() => !get().isStreaming, 8000)

          // 超时兜底：后端协作式中断可能一直不消费（罕见但存在——如无限递归、死循环），
          // session_end 永不到达时 isStreaming/isInterrupting 会卡死 UI。
          // 5s 后仍处于流式状态则强制结束（本地 isStreaming=false + finishMessage，
          // 与 session_end 到达时的收尾一致，避免半截消息）。
          // 批 4b（审计 4.1）：捕获轮次代际——中断后 5s 内用户追问会开启新一轮
          // （turnEpoch 递增），本定时器属于旧轮次，不得强制收尾（否则新回复被
          // 无声截断，且无任何错误提示）。
          const epochAtInterrupt = get().turnEpoch
          setTimeout(() => {
            const st = get()
            // 代际校验：中断等待期间用户可能已切会话/开新会话，conversationId 变化则失效，
            // 避免误杀新一轮流式。
            if (st.conversationId !== conversationId) return
            if (st.turnEpoch !== epochAtInterrupt) return
            if (st.isStreaming || st.isInterrupting) {
              log.warn('Interrupt timeout fallback: backend session_end not received, force-finishing streaming', {
                conversationId,
                isStreaming: st.isStreaming,
                isInterrupting: st.isInterrupting,
                hasCurrentMessage: !!st.currentMessage,
              })
              // 批 4b（审计 4.10）：强制收尾路径同样清理 progressMessage——
              // 此前只复位流式标志，灵动岛从 progressMessage 派生的 running 卡
              // 持续转圈直到下次事件
              // 中断兜底：session_end 不会到达，先结算本活动轮时长再收尾
              get().settleSessionElapsedMs()
              set({ isStreaming: false, isInterrupting: false, progressMessage: null })
              get().finishMessage()
              // 中断兜底强制收尾后，若有待发送队列则继续派发（session_end 不会到达此路径）
              void get().dispatchNextPending()
            }
          }, 5000)
        } catch (e) {
          const err = e instanceof Error ? e : new Error(String(e))
          log.error('Interrupt failed', err, { conversationId, engine })

          // invoke 本身失败（如后端未找到会话）：session_end 不会到达，
          // 前端需主动结束流式状态避免 UI 卡死。
          // 批 4b（审计 4.10）：同步清理 progressMessage（同超时兜底路径）
          // 先结算本活动轮时长，避免中断后已流逝时间丢失
          get().settleSessionElapsedMs()
          set({ isStreaming: false, isInterrupting: false, progressMessage: null })
          get().finishMessage()
          // 中断失败兜底收尾后，若有待发送队列则继续派发
          void get().dispatchNextPending()

          // 用户可见提示
          try {
            const { useToastStore } = await import('../../shims/stores')
            useToastStore.getState().error(
              i18n.t('chat:error.interruptFailed'),
              i18n.t('chat:error.interruptFailedHint'),
            )
          } catch (toastErr) {
            log.warn('Toast 提示失败', { error: String(toastErr) })
          }
        }
      },

      continueChat: async (prompt = '', allowedTools?: string[]) => {
        const { conversationId } = get()
        if (!conversationId) {
          set({ error: '没有活动会话', isStreaming: false })
          return
        }

        const router = deps.getEventRouter()
        await router.initialize()

        const currentWorkspace = deps.getWorkspace()
        const actualWorkspaceDir = currentWorkspace?.path
        const config = deps.getConfig()
        const currentEngine = resolveSessionEngine(get().sessionId, config?.defaultEngine)

        const { workspacePrompt, userPrompt, contextWorkspaces } =
          buildWorkspacePrompts(deps.getWorkspace, deps.getContextWorkspaceIds, deps.getAllWorkspaces)

        log.info('continueChat debug', {
          conversationId,
          actualWorkspaceDir,
          currentWorkspace: currentWorkspace ? { id: currentWorkspace.id, name: currentWorkspace.name, path: currentWorkspace.path } : null,
          workspacePromptLength: workspacePrompt.length,
          userPromptLength: userPrompt?.length ?? 0,
        })

        set({ isStreaming: true, error: null })

        const sessionConfig = getSessionConfig()
        const runtimeConfig = resolveRuntimeConfigForEngine(sessionConfig, currentEngine)
        // P1: 会话级 Profile 绑定（三态解析）— 会话覆盖（含「明确官方」哨兵）优先，
        // 降级状态栏镜像，再降级设置页激活的全局默认；返回 undefined 表示走官方端点。
        const sessionMeta = sessionStoreManager.getState().sessionMetadata.get(get().sessionId)
        const modelProfileId = resolveEffectiveProfileId(
          sessionMeta?.modelProfileId,
          sessionConfig.modelProfileId,
          getActiveModelProfile()?.id,
        )
        // P2: 供应商模式解析（官方/指定 Profile 二态），与 sendMessage 路径一致。
        const profileMode = resolveEffectiveProfileMode(
          sessionMeta?.profileMode,
          sessionConfig.profileMode,
        )
        const effectiveProfileId = isProfileModeWithoutProfile(profileMode)
          ? undefined
          : modelProfileId
        // 当前生效 Profile 的完整配置，用于归一化模型名（见 normalizeModelForProfile）
        const effectiveProfile = getModelProfileById(effectiveProfileId)
        // 会话级模型优先，未设置时降级到全局 sessionConfig 解析结果（resolveRuntimeConfigForEngine）。
        // Profile 归一化：选了 Profile 但模型是它不认的 Claude 别名（opus/sonnet/haiku）时清空，
        // 回退 profile.model 默认；官方 API 路径 effectiveProfile 为空，别名不受影响。
        const resolvedModel = normalizeModelForProfile(
          sessionMeta?.model ?? runtimeConfig.model,
          effectiveProfile,
        )
        const disabledMcpServers = getDisabledPluginMcpServers()
        const clientDescriptor = detectClientDescriptor()

        try {
          await aiChatDispatchStream({
            sessionId: conversationId,
            message: normalizeForInvoke(prompt),
            options: {
              appendSystemPrompt: normalizeForInvoke(workspacePrompt),
              systemPrompt: userPrompt ? normalizeForInvoke(userPrompt) : null,
              workDir: actualWorkspaceDir,
              contextId: deps.contextId,
              engineId: currentEngine,
              enableMcpTools: true,
              disabledMcpServers,
              additionalDirs: contextWorkspaces.map(w => w.path).filter(Boolean),
              agent: sessionMeta?.agent ?? runtimeConfig.agent,
              model: resolvedModel,
              effort: sessionMeta?.effort ?? runtimeConfig.effort,
              permissionMode: sessionMeta?.permissionMode ?? runtimeConfig.permissionMode,
              // 并入会话级放行集合：scope=session/global 授权过的工具在本会话续聊中持续放行（每次新进程 --resume 自动携带）。
              // 普通续聊（无显式 allowedTools）同样并入，这是期望行为——会话内放行应跨轮持续生效。
              allowedTools: (() => {
                const merged = [...new Set([...(allowedTools ?? []), ...get().sessionAllowedTools])]
                return merged.length > 0 ? merged : undefined
              })(),
              modelProfileId: effectiveProfileId,
              profileMode,
              clientType: clientDescriptor.clientType,
              clientPlatform: clientDescriptor.clientPlatform,
              deviceId: clientDescriptor.deviceId || undefined,
            },
          })
        } catch (e) {
          const err = e instanceof Error ? e : new Error(String(e))
          log.error('continueChat failed', err, { conversationId, workspaceDir: actualWorkspaceDir })
          set({
            error: resolveChatError(e, { conversationId, workspaceDir: actualWorkspaceDir }),
            isStreaming: false,
            currentMessage: null,
            progressMessage: null,
          })
        }
      },

      regenerateResponse: async (assistantMessageId) => {
        const { messages, isStreaming } = get()

        // 防止重复操作
        if (isStreaming) {
          log.warn('regenerateResponse: 当前正在流式传输，请稍后再试')
          return
        }

        // 找到目标消息的索引
        const messageIndex = messages.findIndex(m => m.id === assistantMessageId)
        if (messageIndex === -1) {
          log.warn('regenerateResponse: 未找到目标消息', { assistantMessageId })
          return
        }

        // 找到该 assistant 消息之前的最近一条 user 消息
        let userMessageIndex = -1
        for (let i = messageIndex - 1; i >= 0; i--) {
          if (messages[i].type === 'user') {
            userMessageIndex = i
            break
          }
        }

        if (userMessageIndex === -1) {
          log.warn('regenerateResponse: 未找到对应的用户消息')
          return
        }

        const userMessage = messages[userMessageIndex]
        const userContent = userMessage.type === 'user' ? userMessage.content : ''

        // 删除从 user 消息之后的所有消息（包括要重新生成的 assistant 消息）
        const newMessages = messages.slice(0, userMessageIndex)
        // 根因修复（审计 2.3）：本地截断后给后端消息库下消息级墓碑（时间阈值 =
        // 被移除的首条消息），防止恢复时 mergeBackendMessages 把被截断的旧分支
        // 从尾部「复活」。fire-and-forget：失败不影响本地操作（下次 session_end
        // 的 canonical 覆写仍会修正归档）。
        const removedFromTs = messages[userMessageIndex]?.timestamp
        const convId = get().conversationId
        if (removedFromTs && convId) {
          void import('@/services/transport')
            .then(({ invoke }) => invoke('message_tombstone_after', {
              conversationId: convId,
              afterTs: Date.parse(removedFromTs) || 0,
            }))
            .catch(() => undefined)
        }
        // 更新状态：删除后续消息，清空当前消息
        set({
          messages: newMessages,
          currentMessage: null,
          isStreaming: false,
          error: null,
        })

        log.info('regenerateResponse: 重新生成响应', {
          userMessageId: userMessage.id,
          removedCount: messages.length - userMessageIndex
        })

        // 重新发送用户消息
        // 获取工作区信息
        const workspace = deps.getWorkspace()
        const workspaceDir = workspace?.path || undefined

        // 批 4 补遗（审计 4.5）：先删后发的事务化——sendMessage 失败时恢复被删
        // 消息。否则旧回复已从内存消失、新回复没来，下次 session_end 整体覆写
        // JSONL 时被删历史永久丢失。墓碑同步撤销（恢复旧分支后它不再是"应删"）。
        const { sendMessage } = get()
        const sent = await sendMessage(userContent, workspaceDir)
        if (sent === false) {
          log.warn('regenerateResponse: 重发失败，恢复被截断的历史消息', {
            removedCount: messages.length - userMessageIndex,
          })
          set({ messages, currentMessage: null })
          const restoredConvId = get().conversationId
          if (removedFromTs && restoredConvId) {
            void import('@/services/transport')
              .then(({ invoke }) => invoke('message_revise_undelete', {
                conversationId: restoredConvId,
                afterTs: Date.parse(removedFromTs) || 0,
              }))
              .catch(() => undefined)
          }
        }
      },

      editAndResend: async (userMessageId, newContent) => {
        const { messages, isStreaming } = get()

        // 防止重复操作
        if (isStreaming) {
          log.warn('editAndResend: 当前正在流式传输，请稍后再试')
          return
        }

        // 找到目标消息的索引
        const messageIndex = messages.findIndex(m => m.id === userMessageId)
        if (messageIndex === -1) {
          log.warn('editAndResend: 未找到目标消息', { userMessageId })
          return
        }

        const targetMessage = messages[messageIndex]
        if (targetMessage.type !== 'user') {
          log.warn('editAndResend: 目标消息不是用户消息')
          return
        }

        // 删除从该 user 消息之后的所有消息
        const newMessages = messages.slice(0, messageIndex)
        // 根因修复（审计 2.3）：同 regenerateResponse——本地截断后下消息级墓碑，
        // 防止恢复时旧分支复活（fire-and-forget，详见 regenerateResponse 注释）。
        {
          const convId = get().conversationId
          if (convId) {
            void import('@/services/transport')
              .then(({ invoke }) => invoke('message_tombstone_after', {
                conversationId: convId,
                afterTs: Date.parse(targetMessage.timestamp) || 0,
              }))
              .catch(() => undefined)
          }
        }
        // 更新状态
        set({
          messages: newMessages,
          currentMessage: null,
          isStreaming: false,
          error: null,
        })

        log.info('editAndResend: 编辑并重发消息', {
          originalMessageId: userMessageId,
          removedCount: messages.length - messageIndex
        })

        // 发送新内容的消息
        const workspace = deps.getWorkspace()
        const workspaceDir = workspace?.path || undefined

        // 批 4 补遗（审计 4.5）：同 regenerateResponse——失败恢复被删历史
        const { sendMessage } = get()
        const sent = await sendMessage(newContent, workspaceDir)
        if (sent === false) {
          log.warn('editAndResend: 重发失败，恢复被截断的历史消息', {
            removedCount: messages.length - messageIndex,
          })
          set({ messages, currentMessage: null })
          const restoredConvId = get().conversationId
          if (restoredConvId) {
            void import('@/services/transport')
              .then(({ invoke }) => invoke('message_revise_undelete', {
                conversationId: restoredConvId,
                afterTs: Date.parse(targetMessage.timestamp) || 0,
              }))
              .catch(() => undefined)
          }
        }
      },

      loadMoreArchivedMessages: (count = 20) => {
        const { archivedMessages, messages, historyPaging, conversationId } = get()

        // 1) 内存归档兜底（历史遗留路径，通常为空）
        if (archivedMessages.length > 0) {
          const loadCount = Math.min(count, archivedMessages.length)
          const toLoad = archivedMessages.slice(-loadCount)
          const remaining = archivedMessages.slice(0, -loadCount)
          set({
            messages: [...toLoad, ...messages],
            archivedMessages: remaining,
          })
          return
        }

        // 2) 磁盘分页：尾部优先恢复的会话向上滚动时按需补读更早的消息
        if (!historyPaging || !historyPaging.hasMore || _loadingOlderPage) return
        _loadingOlderPage = true
        const { earliestSeq, sourceId } = historyPaging
        const persistedSeqAtCall = get().persistedSeq
        void dialogStorageService
          .getConversationPage(sourceId, earliestSeq, count)
          .then((page) => {
            const cur = get()
            // 会话已切换/游标已变/落盘水位推进（并发防护）→ 丢弃本次结果，用户再滚动会重试
            if (
              cur.conversationId !== conversationId ||
              cur.historyPaging?.earliestSeq !== earliestSeq ||
              cur.persistedSeq !== persistedSeqAtCall
            ) {
              return
            }
            if (!page || page.messages.length === 0) {
              set({ historyPaging: { ...historyPaging, hasMore: false } })
              return
            }
            // 去重防御：磁盘页可能与内存窗口重叠（seq 漂移的极端情况）
            const inMemory = new Set(cur.messages.map((m) => m.id))
            // checkpoint 同 id 快照收敛（取末行 = 最新内容）+ isStreaming 残留归一为中断态
            const deduped = dedupeMessagesById(page.messages) as ChatMessage[]
            const normalized = normalizeRecoveredMessages(deduped)
            const fresh = normalized.filter((m) => !inMemory.has(m.id))
            set({
              messages: fresh.length > 0 ? [...fresh, ...cur.messages] : cur.messages,
              // 前缀增长 → 已落盘计数同步增长（这些消息本就来自磁盘）
              persistedSeq: cur.persistedSeq + fresh.length,
              historyPaging: {
                earliestSeq: page.earliestSeq ?? earliestSeq,
                hasMore: page.hasMore,
                sourceId,
              },
            })
          })
          .finally(() => {
            _loadingOlderPage = false
          })
      },

      // ===== 消息压缩 =====
      onVisibleRangeChange: (start, end) => {
        // 参数校验：防止无效范围
        if (start < 0 || end < 0 || start > end) return

        const { messages, conversationId } = get()
        if (messages.length === 0) return

        // 更新可见范围（始终更新，保证 UI 状态正确）
        set({ visibleRange: { start, end } })

        // 防抖：当新 range 与上次压缩 range 重叠 >80% 时，跳过压缩/恢复
        // 避免压缩→Virtuoso 重算高度→新 range→振荡
        if (_lastCompactionRange) {
          const overlapStart = Math.max(start, _lastCompactionRange.start)
          const overlapEnd = Math.min(end, _lastCompactionRange.end)
          const overlapSize = Math.max(0, overlapEnd - overlapStart + 1)
          const currentSize = end - start + 1
          if (currentSize > 0 && overlapSize / currentSize > 0.8) {
            return
          }
        }
        _lastCompactionRange = { start, end }

        // 计算需要压缩和恢复的索引
        const { toCompact, toHydrate } = compactor.computeRangeActions(messages.length, start, end)

        const newMessages = [...messages]
        let changed = false
        let needDiskLoad = false

        // 恢复进入可见区域的消息
        for (const idx of toHydrate) {
          if (idx < 0 || idx >= newMessages.length) continue
          const msg = newMessages[idx]
          if (isCompacted(msg)) {
            // 一级恢复：从 compactor 快照 Map 恢复
            let hydrated = compactor.hydrateMessage(msg)
            if (hydrated === msg && conversationId) {
              // 快照未命中，二级降级：从自有 JSONL 的磁盘缓存恢复（磁盘上有完整版本）
              const fromDisk = dialogStorageService.getCachedFullMessage(conversationId, msg.id)
              if (fromDisk) {
                hydrated = compactor.hydrateFromExternal(msg.id, fromDisk)
              } else if (!dialogStorageService.hasMessageMapCache(conversationId)) {
                needDiskLoad = true
              }
            }
            if (hydrated !== msg) {
              newMessages[idx] = hydrated
              changed = true
            }
          }
        }

        // 磁盘缓存未加载 → 异步加载后补一次可见区恢复（一次读盘，之后走同步缓存）
        if (needDiskLoad && conversationId) {
          void dialogStorageService.loadMessageMap(conversationId).then((map) => {
            if (!map || map.size === 0) return
            const s = get()
            if (s.conversationId !== conversationId || !s.visibleRange) return
            const { toHydrate: hydrateIdx } = compactor.computeRangeActions(
              s.messages.length,
              s.visibleRange.start,
              s.visibleRange.end,
            )
            const patched = [...s.messages]
            let dirty = false
            for (const idx of hydrateIdx) {
              if (idx < 0 || idx >= patched.length) continue
              const m = patched[idx]
              if (m && isCompacted(m)) {
                const full = map.get(m.id)
                if (full) {
                  patched[idx] = compactor.hydrateFromExternal(m.id, full)
                  dirty = true
                }
              }
            }
            if (dirty) set({ messages: patched })
          })
        }

        // 压缩离开可见区域的消息
        for (const idx of toCompact) {
          if (idx < 0 || idx >= newMessages.length) continue
          const msg = newMessages[idx]
          if (!isCompacted(msg)) {
            const compacted = compactor.compactMessage(msg)
            // 仅当真正发生压缩（返回新引用）时才标记变更，避免 system /
            // tool_group 等不可压缩消息无谓触发 set({ messages }) → 整列表重渲染。
            if (compacted !== msg) {
              newMessages[idx] = compacted
              changed = true
            }
          }
        }

        if (changed) {
          set({ messages: newMessages })
        }
      },

      // ===== 持久化前恢复 =====
      getPersistableMessages: () => {
        const { messages, conversationId } = get()
        let newMessages: ChatMessage[] | null = null

        for (let i = 0; i < messages.length; i++) {
          const msg = messages[i]
          if (!isCompacted(msg)) continue

          // 懒初始化新数组，无压缩消息时保持原引用
          if (!newMessages) newMessages = [...messages]

          // 只读恢复：持久化路径不应有副作用，避免 hydrateMessage 的 touchSnapshotOrder
          // 与 hydrateFromExternal 的 saveSnapshot 污染 LRU——后者会把别的内存快照挤出
          // 队列，导致用户后续滚回该消息时被迫降级到磁盘（再触发一次读盘）。
          // 改用 getSnapshot 只读读取；降级读磁盘缓存（只读），不写回快照。
          // 两级都 miss 时保持压缩态——saveConversation 的合并保护会以磁盘完整版为准。
          const snapshot = compactor.getSnapshot(msg.id)
          let hydrated: ChatMessage | null = snapshot ?? null
          if (!hydrated && conversationId) {
            // 二级降级：自有 JSONL 磁盘缓存（同步只读；未加载时交给合并保护兜底）
            hydrated = dialogStorageService.getCachedFullMessage(conversationId, msg.id)
          }
          if (hydrated && hydrated !== msg) {
            newMessages[i] = hydrated
          }
        }

        return newMessages ?? messages
      },

      // ===== 资源清理 =====
      dispose: () => {
        // 清理缓冲定时器
        if (_paragraphTimer) {
          clearTimeout(_paragraphTimer)
          _paragraphTimer = null
        }
        _textBuffer = ''
        // thinking 缓冲同步清空（与 _textBuffer 对称：dispose 后不应残留跨会话内容）
        _thinkingBuffer = ''

        // 清理压缩器快照
        compactor.clearSnapshots()

        const state = get()
        // 重置状态
        set(createInitialState(state.sessionId))
      },
    }))
  )

  return store
}
