/**
 * 聊天组件共享常量配置
 */

import { Check, XCircle, Loader2, AlertTriangle, Circle, Square } from 'lucide-react';

/** Virtuoso 视口扩展常量（避免每次渲染创建新对象） */
export const VIEWPORT_EXTENSION = { top: 100, bottom: 150 };

/** Virtuoso 底部间距 */
export const FOOTER_SPACER_STYLE = { height: '120px' } as const;

/**
 * Virtuoso 顶部间距：为常驻灵动岛（v3 空闲也不卸载）预留空间，
 * 避免首条消息被贴顶悬浮岛遮住。
 */
export const ISLAND_HEADER_SPACER_STYLE = { height: '36px', flexShrink: 0 } as const;

/**
 * 状态图标配置
 */
export const STATUS_CONFIG = {
  pending: { icon: Loader2, className: 'animate-spin text-yellow-500', labelKey: 'status.pending' },
  running: { icon: Loader2, className: 'animate-spin text-blue-500', labelKey: 'status.running' },
  completed: { icon: Check, className: 'text-green-500', labelKey: 'status.completed' },
  failed: { icon: XCircle, className: 'text-red-500', labelKey: 'status.failed' },
  partial: { icon: AlertTriangle, className: 'text-orange-500', labelKey: 'status.partial' },
} as const;

/**
 * TaskBoard 任务状态配置
 */
export const TASK_STATUS_CONFIG = {
  completed: { icon: Check, color: 'text-green-500', bg: 'bg-green-500/10', labelKey: 'status.completed' },
  in_progress: { icon: Loader2, color: 'text-blue-500', bg: 'bg-blue-500/10', labelKey: 'status.running' },
  pending: { icon: Circle, color: 'text-gray-400', bg: 'bg-gray-500/10', labelKey: 'status.pending' },
  blocked: { icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-500/10', labelKey: 'status.blocked' },
  stopped: { icon: Square, color: 'text-gray-500', bg: 'bg-gray-500/10', labelKey: 'status.stopped' },
} as const;
