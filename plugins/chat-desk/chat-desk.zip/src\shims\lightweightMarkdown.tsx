/**
 * 轻量级 Markdown 渲染器
 *
 * 专为流式渲染设计，只处理行内格式，不做复杂的块级解析
 * 性能优化：
 * - 只处理可见的格式化元素
 * - 不处理代码块语法高亮（流式阶段）
 * - 不处理表格、Mermaid 等复杂元素
 * - 使用简单的字符串匹配，避免复杂的正则
 */

import { memo, useCallback, useMemo, useState } from 'react';
import { DeferredMermaidDiagram } from '../host/Chat/common/DeferredMermaidDiagram';
import { MarkdownRenderCache } from './cache';
import DOMPurify from 'dompurify';
import { highlightCode } from './syntaxHighlight';

/** 渲染片段类型 */
interface RenderPart {
  type: 'text' | 'bold' | 'italic' | 'code' | 'link' | 'strikethrough' | 'image';
  content: string;
  href?: string;
}

/**
 * 快速解析行内 Markdown 元素
 * 只处理：粗体、斜体、行内代码、链接、删除线
 * 不处理：代码块、标题、列表、表格等块级元素
 */
function parseInlineMarkdown(content: string): RenderPart[] {
  const parts: RenderPart[] = [];
  let remaining = content;
  let key = 0;

  // 安全限制：最大处理长度
  const MAX_LENGTH = 50000;
  if (content.length > MAX_LENGTH) {
    return [{ type: 'text', content }];
  }

  while (remaining.length > 0) {
    // 找到最近的特殊标记
    const markers = [
      { pattern: '**', type: 'bold' as const },
      { pattern: '__', type: 'bold' as const },
      { pattern: '*', type: 'italic' as const },
      { pattern: '_', type: 'italic' as const },
      { pattern: '`', type: 'code' as const },
      { pattern: '~~', type: 'strikethrough' as const },
    ];

    // 查找图片 ![alt](src)
    const imageMatch = remaining.match(/^!\[([^\]]*)\]\(([^)]+)\)/);
    if (imageMatch) {
      parts.push({
        type: 'image',
        content: imageMatch[1],
        href: imageMatch[2],
      });
      remaining = remaining.slice(imageMatch[0].length);
      continue;
    }

    // 查找链接 [text](url) - 只匹配开头位置
    const linkMatch = remaining.match(/^\[([^\]]+)\]\(([^)]+)\)/);
    if (linkMatch) {
      // 正则以 ^ 开头，匹配成功时必定在开头位置
      parts.push({
        type: 'link',
        content: linkMatch[1],
        href: linkMatch[2]
      });
      remaining = remaining.slice(linkMatch[0].length);
      continue;
    }

    // 找到最近的一个标记
    let nearestIndex = Infinity;
    let nearestMarker: typeof markers[0] | null = null;

    for (const marker of markers) {
      const idx = remaining.indexOf(marker.pattern);
      if (idx !== -1 && idx < nearestIndex) {
        nearestIndex = idx;
        nearestMarker = marker;
      }
    }

    // 也检查链接
    const linkStart = remaining.indexOf('[');
    if (linkStart !== -1 && linkStart < nearestIndex) {
      // 添加之前的文本
      if (linkStart > 0) {
        parts.push({ type: 'text', content: remaining.slice(0, linkStart) });
        remaining = remaining.slice(linkStart);
        continue;
      }
      // 尝试匹配链接
      const match = remaining.match(/^\[([^\]]+)\]\(([^)]+)\)/);
      if (match) {
        parts.push({
          type: 'link',
          content: match[1],
          href: match[2]
        });
        remaining = remaining.slice(match[0].length);
        continue;
      }
      // 不是有效链接，当作普通文本
      parts.push({ type: 'text', content: '[' });
      remaining = remaining.slice(1);
      continue;
    }

    if (nearestIndex === Infinity || !nearestMarker) {
      // 没有更多标记，添加剩余文本
      parts.push({ type: 'text', content: remaining });
      break;
    }

    // 添加标记之前的普通文本
    if (nearestIndex > 0) {
      parts.push({ type: 'text', content: remaining.slice(0, nearestIndex) });
    }

    // 根据标记类型处理
    const afterMarker = remaining.slice(nearestIndex + nearestMarker.pattern.length);

    if (nearestMarker.type === 'code') {
      // 行内代码：找结束的 `
      const endIdx = afterMarker.indexOf('`');
      if (endIdx !== -1) {
        const codeContent = afterMarker.slice(0, endIdx);
        parts.push({ type: 'code', content: codeContent });
        remaining = afterMarker.slice(endIdx + 1);
      } else {
        // 没有结束标记，当作普通文本
        parts.push({ type: 'text', content: remaining.slice(nearestIndex, nearestIndex + 1) });
        remaining = afterMarker;
      }
    } else if (nearestMarker.type === 'bold') {
      // 粗体：找结束的 ** 或 __
      const endIdx = afterMarker.indexOf(nearestMarker.pattern);
      if (endIdx !== -1 && endIdx > 0) {
        const boldContent = afterMarker.slice(0, endIdx);
        parts.push({ type: 'bold', content: boldContent });
        remaining = afterMarker.slice(endIdx + nearestMarker.pattern.length);
      } else {
        // 没有结束标记，当作普通文本
        parts.push({ type: 'text', content: remaining.slice(nearestIndex, nearestIndex + 2) });
        remaining = afterMarker;
      }
    } else if (nearestMarker.type === 'italic') {
      // 斜体：找结束的 * 或 _
      // 注意：需要处理 ** 的情况（优先粗体）
      const endIdx = afterMarker.indexOf(nearestMarker.pattern);
      if (endIdx !== -1 && endIdx > 0) {
        // 确保结束标记后面不是另一个 *（避免与粗体冲突）
        const afterEnd = afterMarker.slice(endIdx + 1);
        if (nearestMarker.pattern === '*' && afterEnd.startsWith('*')) {
          // 这应该是 ** 的开始，当作普通文本
          parts.push({ type: 'text', content: remaining.slice(nearestIndex, nearestIndex + 1) });
          remaining = afterMarker;
        } else {
          const italicContent = afterMarker.slice(0, endIdx);
          parts.push({ type: 'italic', content: italicContent });
          remaining = afterMarker.slice(endIdx + 1);
        }
      } else {
        // 没有结束标记，当作普通文本
        parts.push({ type: 'text', content: remaining.slice(nearestIndex, nearestIndex + 1) });
        remaining = afterMarker;
      }
    } else if (nearestMarker.type === 'strikethrough') {
      // 删除线：找结束的 ~~
      const endIdx = afterMarker.indexOf('~~');
      if (endIdx !== -1 && endIdx > 0) {
        const strikeContent = afterMarker.slice(0, endIdx);
        parts.push({ type: 'strikethrough', content: strikeContent });
        remaining = afterMarker.slice(endIdx + 2);
      } else {
        // 没有结束标记，当作普通文本
        parts.push({ type: 'text', content: remaining.slice(nearestIndex, nearestIndex + 2) });
        remaining = afterMarker;
      }
    }

    // 安全检查：防止无限循环
    key++;
    if (key > 1000) {
      parts.push({ type: 'text', content: remaining });
      break;
    }
  }

  return parts;
}

/**
 * 渲染行内 Markdown 片段
 */
function renderPart(part: RenderPart, index: number): React.ReactNode {
  switch (part.type) {
    case 'bold':
      return <strong key={index}>{part.content}</strong>;
    case 'italic':
      return <em key={index}>{part.content}</em>;
    case 'code':
      return (
        <code
          key={index}
          className="px-1.5 py-0.5 bg-background-surface rounded text-primary font-mono text-sm"
        >
          {part.content}
        </code>
      );
    case 'image':
      return (
        <img
          key={index}
          src={part.href!}
          alt={part.content}
          className="markdown-chat-image"
          loading="lazy"
        />
      );
    case 'link':
      return (
        <a
          key={index}
          href={part.href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          {part.content}
        </a>
      );
    case 'strikethrough':
      return <del key={index}>{part.content}</del>;
    default:
      return part.content;
  }
}

/**
 * 轻量级 Markdown 渲染组件
 * 专为流式渲染优化，只处理行内格式
 */
export const LightweightMarkdown = memo(function LightweightMarkdown({
  content,
  caret = false,
}: {
  content: string;
  /** 是否在末尾显示打字光标（仅流式中最后一段传入 true） */
  caret?: boolean;
}) {
  // 标准化：将单个换行符替换为空格（与 Markdown 规范一致）
  // 段落内的单个 \n 应视为连续文本，不应产生视觉换行
  // \n\n 已在 ProgressiveStreamingMarkdown 层面处理（用于段落分割）
  const normalizedContent = useMemo(() => content.replace(/\n/g, ' '), [content]);
  const parts = useMemo(() => parseInlineMarkdown(normalizedContent), [normalizedContent]);

  return (
    <span className="break-words">
      {parts.map((part, index) => renderPart(part, index))}
      {/* 光标只在有实质内容时才渲染：空/纯空白段（流式分割的末尾空段等）
          不应在空行上闪烁，避免文本结束 → 工具调用开始之间出现孤立光标 */}
      {caret && content.trim() && <span aria-hidden className="streaming-caret" />}
    </span>
  );
});

/**
 * 检测内容是否包含未闭合的代码块
 * 按行处理：仅当行首出现 ``` 时切换开关状态
 * 同行内的 ``` 对（如 ```code```）视为行内代码，跳过
 * 这样可以正确处理代码块内容中出现的 ```
 */
export function hasOpenCodeBlock(content: string): boolean {
  let inCodeBlock = false;
  const lines = content.split('\n');
  for (const line of lines) {
    const trimmed = line.trimStart();
    if (trimmed.startsWith('```')) {
      // 同行内如果出现两对 ```（如 ```code```），视为行内代码，跳过
      const afterFirst = trimmed.slice(3);
      if (afterFirst.includes('```')) {
        continue;
      }
      inCodeBlock = !inCodeBlock;
    }
  }
  return inCodeBlock;
}

/**
 * 检测内容是否包含块级 Markdown 元素
 * 用于流式渲染时判断最后一段是否需要走 marked 完整渲染
 *
 * 覆盖：表格、无序列表、有序列表、任务列表、标题、块引用、水平线、块级数学公式
 */
function hasBlockElement(text: string): boolean {
  let tableCount = 0;
  let listCount = 0;
  let quoteCount = 0;

  for (const line of text.split('\n')) {
    const trimmed = line.trimStart();

    // 表格：需要 >= 2 行以 | 开头
    if (trimmed.startsWith('|')) {
      tableCount++;
      if (tableCount >= 2) return true;
    }

    // 无序列表 / 任务列表：需要 >= 2 行以 - * + 开头
    if (/^[-*+]\s/.test(trimmed)) {
      listCount++;
      if (listCount >= 2) return true;
    }

    // 有序列表：需要 >= 2 行以 数字+点+空格 开头
    if (/^\d+\.\s/.test(trimmed)) {
      listCount++;
      if (listCount >= 2) return true;
    }

    // 标题：检测到 1 行就触发（# 后跟空格）
    if (/^#{1,6}\s/.test(trimmed)) {
      return true;
    }

    // 块引用：需要 >= 2 行以 > 开头
    if (/^>\s/.test(trimmed)) {
      quoteCount++;
      if (quoteCount >= 2) return true;
    }

    // 水平线：检测到 1 行就触发
    if (/^[-*_]{3,}$/.test(trimmed) || /^[-*_]{3,}\s*$/.test(trimmed)) {
      return true;
    }

    // 块级数学公式 $$...$$：检测到行首为 $$ 即触发
    if (/^\$\$/.test(trimmed)) {
      return true;
    }
  }
  return false;
}

/** 段落分割正则（编译一次，避免每次渲染重新创建） */
const PARAGRAPH_SPLIT_RE = /\n\n+/;

/**
 * 分割内容：将代码块、Mermaid 图表和普通文本分开
 *
 * 返回片段数组，标记每段是否已完成（不会再变化）：
 * - 代码块之前的文本：completed = true
 * - 最后一个已关闭代码块之后的文本：completed = false（可能还会追加）
 * - 已关闭的代码块：completed = true
 * - 未闭合的代码块标记：completed = false
 * - Mermaid 图表块：completed = true（已完整闭合）
 */
export function splitByCodeBlocks(content: string): Array<{
  type: 'text' | 'code-block' | 'mermaid-block';
  content: string;
  language?: string;
  completed: boolean;
}> {
  const parts: Array<{ type: 'text' | 'code-block' | 'mermaid-block'; content: string; language?: string; completed: boolean }> = [];

  // 匹配已关闭的 Mermaid 代码块：```mermaid\ncode\n```（支持可选空格）
  const mermaidRegex = /`{3}\s*mermaid\s*\n([\s\S]*?)`{3}/g;

  // 匹配已关闭的普通代码块：```lang\ncode\n```（排除 mermaid，lang 可为空）
  // 支持：```typescript\ncode\n``` 或 ```\ncode\n```
  const codeBlockRegex = /`{3}(\w*)\n([\s\S]*?)`{3}/g;

  // 合并处理：先找出所有代码块的位置，然后按顺序处理
  interface BlockMatch {
    index: number;
    endIndex: number;
    type: 'code-block' | 'mermaid-block';
    content: string;
    language?: string;
  }

  const allBlocks: BlockMatch[] = [];

  // 找出所有 Mermaid 块
  let mermaidMatch: RegExpExecArray | null;
  while ((mermaidMatch = mermaidRegex.exec(content)) !== null) {
    allBlocks.push({
      index: mermaidMatch.index,
      endIndex: mermaidMatch.index + mermaidMatch[0].length,
      type: 'mermaid-block',
      content: mermaidMatch[1].trim(),
    });
  }

  // 找出所有普通代码块（排除 mermaid）
  let codeMatch: RegExpExecArray | null;
  codeBlockRegex.lastIndex = 0;
  while ((codeMatch = codeBlockRegex.exec(content)) !== null) {
    const currentMatch = codeMatch; // 捕获当前匹配结果
    // 检查是否是 mermaid（已在上面处理）
    if (currentMatch[1].toLowerCase() === 'mermaid') continue;

    // 检查是否与其他块重叠
    const overlaps = allBlocks.some(
      b => (currentMatch.index >= b.index && currentMatch.index < b.endIndex) ||
           (currentMatch.index + currentMatch[0].length > b.index && currentMatch.index + currentMatch[0].length <= b.endIndex)
    );
    if (overlaps) continue;

    allBlocks.push({
      index: currentMatch.index,
      endIndex: currentMatch.index + currentMatch[0].length,
      type: 'code-block',
      content: currentMatch[2],
      language: currentMatch[1] || undefined,
    });
  }

  // 按位置排序
  allBlocks.sort((a, b) => a.index - b.index);

  // 处理所有块和文本
  let lastIndex = 0;
  for (const block of allBlocks) {
    // 添加块之前的文本（已完成的）
    if (block.index > lastIndex) {
      parts.push({
        type: 'text',
        content: content.slice(lastIndex, block.index),
        completed: true,
      });
    }

    // 添加代码块或 Mermaid 块
    parts.push({
      type: block.type,
      content: block.content,
      language: block.language,
      completed: true,
    });

    lastIndex = block.endIndex;
  }

  // 处理最后一个已关闭代码块之后的内容
  const remaining = content.slice(lastIndex);
  if (remaining) {
    // 检查是否有未闭合的代码块
    const openBlockMatch = remaining.match(/```(\w*)\n?([\s\S]*)$/);
    if (openBlockMatch) {
      // 有未闭合的代码块
      // 代码块标记之前的文本是已完成的
      const beforeOpen = remaining.slice(0, remaining.indexOf('```'));
      if (beforeOpen) {
        parts.push({
          type: 'text',
          content: beforeOpen,
          completed: true,
        });
      }
      // 未闭合的代码块部分作为代码块渲染（流式预览）
      const lang = openBlockMatch[1] || '';
      const codeContent = openBlockMatch[2] || '';
      parts.push({
        type: 'code-block',
        content: codeContent,
        language: lang,
        completed: false,
      });
    } else {
      // 没有未闭合的代码块，但这段文本可能是未完成的（流式还在追加）
      parts.push({
        type: 'text',
        content: remaining,
        completed: false,
      });
    }
  }

  return parts;
}

/**
 * 流式阶段的代码块渲染
 *
 * 显示代码块标记与复制按钮；仅在 `completed` 为 true（代码块已闭合）
 * 时启用语法高亮，避免流式追加过程中的重复 highlight 开销。
 *
 * 高亮管线复用 `highlightCode`（`src/utils/syntaxHighlight.ts`）：
 * - 已接入 performance.syntaxHighlighting 开关，关闭时返回转义纯文本
 * - 自带 LRU 缓存，`completed` 后一次性高亮，不会反复计算
 * - 语言未注册 / 高亮失败时自动回退 highlightAuto，再失败则纯文本
 */
export const StreamingCodeBlock = memo(function StreamingCodeBlock({
  content,
  language,
  completed = false,
}: {
  content: string;
  language?: string;
  /** 代码块是否已闭合（来自 splitByCodeBlocks 的 completed 标记） */
  completed?: boolean;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }, [content]);

  // 仅在高亮开关开启且代码块已闭合时执行高亮；
  // 流式阶段（completed=false）保持纯文本，避免高频追加触发重复 highlight。
  const highlightedHtml = useMemo(() => {
    if (!completed) return null;
    return highlightCode(content, language || '');
  }, [content, language, completed]);

  return (
    <div className="rounded-lg overflow-hidden bg-background-base border border-border-subtle group relative">
      <div className="flex items-center justify-between px-3 py-1.5 bg-background-elevated border-b border-border-subtle">
        <span className="text-xs text-text-tertiary font-mono">{language || ''}</span>
        <button
          onClick={handleCopy}
          className="text-xs text-text-tertiary hover:text-text-primary opacity-0 group-hover:opacity-100 transition-opacity"
          title="复制"
        >
          {copied ? '已复制' : '复制'}
        </button>
      </div>
      <pre className="code-block-pre p-3 overflow-x-auto">
        <code className={`text-sm font-mono whitespace-pre${highlightedHtml ? ' hljs' : ' text-text-secondary'}`}>
          {highlightedHtml ? (
            // highlightCode 返回 hljs 生成的 span/class 结构（或转义纯文本），
            // 与 CodeBlock.tsx 保持一致：仅放行 span + class，避免 XSS 面。
            <span dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(highlightedHtml, { ALLOWED_TAGS: ['span'], ALLOWED_ATTR: ['class'] }) }} />
          ) : (
            content
          )}
        </code>
      </pre>
    </div>
  );
});

export default LightweightMarkdown;

// ============================================================================
// 渐进式流式 Markdown 渲染器
// ============================================================================

/** 流式渲染专用 Markdown 缓存实例（50 条上限，1 分钟 TTL，提高命中率） */
const streamingMdCache = new MarkdownRenderCache(50);

/** 打字光标 HTML 片段 */
const STREAMING_CARET_HTML =
  '<span class="streaming-caret" aria-hidden="true"></span>';

/** 把 caret 注入到 marked 渲染结果中最后一个块级元素的末尾，
 * 让 caret 视觉上出现在最后一行文字的字符尾部（而非块下方）。
 *
 * 策略：找到最后一个 `</p>` `</li>` `</blockquote>` `</td>` `</th>` `</h1-6>` `</summary>`
 * 闭合标签，在其**前面**插入 caret，保持闭合标签原位。若没有块级闭合标签
 * （极少见的空 markdown），退化到 HTML 末尾追加。
 * 导出以便单测。 */
export function injectCaretIntoLastBlock(html: string): string {
  const blockCloseRe =
    /<\/(p|li|blockquote|td|th|h[1-6]|summary)>/g;
  let lastIdx = -1;
  let m: RegExpExecArray | null;
  while ((m = blockCloseRe.exec(html)) !== null) {
    lastIdx = m.index;
  }
  if (lastIdx === -1) {
    return html + STREAMING_CARET_HTML;
  }
  // 在闭合标签起始位置插入 caret，闭合标签整体保留
  return (
    html.slice(0, lastIdx) +
    STREAMING_CARET_HTML +
    html.slice(lastIdx)
  );
}

/**
 * 已完成文本块渲染器（单一容器）
 *
 * 所有段落渲染在同一容器中，<p> margin 正确折叠，避免独立 div 包裹导致间距翻倍。
 * 使用 CSS contain: content 限制重排范围。
 * caret=true 时把 caret 注入到最后一个块级元素内部，让它紧贴最后一行文字末尾。
 */
const CompletedTextBlock = memo(function CompletedTextBlock({
  content,
  caret = false,
  blockIndex,
}: {
  content: string;
  blockIndex?: number;
  /** 是否在末尾追加打字光标（仅流式中最后一段为 true） */
  caret?: boolean;
}) {
  // blockIndex 保留以兼容旧调用点；当前渲染路径未直接使用。
  void blockIndex;
  const html = useMemo(() => {
    if (!content.trim()) return null;
    // 使用缓存渲染，提高性能
    const rendered = streamingMdCache.render(content);
    return caret ? injectCaretIntoLastBlock(rendered) : rendered;
  }, [content, caret]);

  if (!html) return null;

  return (
    <div
      className="break-words"
      style={{ contain: 'content' }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
});

/**
 * 渐进式流式 Markdown 渲染器
 *
 * 核心改动：已完成段落合并到同一容器渲染，避免独立 div 包裹导致 <p> margin 不折叠。
 *
 * 策略：
 * 1. 已完成内容 → 单一容器 + marked + DOMPurify（<p> margin 折叠，无多余空行）
 * 2. 流式最后一段 → LightweightMarkdown（轻量行内渲染）
 * 3. 代码块 → StreamingCodeBlock / DeferredMermaidDiagram
 * 4. CSS contain: content 限制重排范围
 */
export const ProgressiveStreamingMarkdown = memo(function ProgressiveStreamingMarkdown({
  content,
  completed = false,
}: {
  content: string;
  completed?: boolean;
}) {
  const result = useMemo(() => {
    if (!content) return null;

    if (content.length > 50000) {
      return <span className="whitespace-pre-wrap break-words">{content}</span>;
    }

    const codeBlockCount = (content.match(/```/g) || []).length;

    // 无代码块路径
    if (codeBlockCount === 0) {
      // 已完成：单一容器渲染全部内容
      if (completed) {
        return (
          <div className="break-words" style={{ contain: 'content' }}
            dangerouslySetInnerHTML={{ __html: streamingMdCache.render(content) }} />
        );
      }

      // 流式：按段落分割
      const paragraphs = content.split(PARAGRAPH_SPLIT_RE);

      if (paragraphs.length <= 1) {
        // 流式最后一段含块级元素 → 走 marked 完整渲染
        if (hasBlockElement(content)) {
          return <CompletedTextBlock content={content} caret />;
        }
        return <LightweightMarkdown content={content} caret />;
      }

      // 已完成段落合并渲染 + 最后一段轻量渲染
      // 关键：已完成段落在同一容器内，<p> margin 折叠，不会出现多余空行
      const completedContent = paragraphs.slice(0, -1).join('\n\n') + '\n\n';
      const lastPara = paragraphs[paragraphs.length - 1];

      // 末段为空/纯空白：content 以段落边界（\n\n）收尾，最后一段已经完整结束。
      // 此时若仍按"流式中最后一段"渲染，会在空行上挂一个闪烁的打字光标
      // （尤其文本结束 → 工具调用开始之间，消息级 isStreaming 仍为 true，光标不消失）。
      // 按已完成段落统一渲染，等下一个 token 到达再继续流式。
      if (!lastPara.trim()) {
        return (
          <div className="break-words" style={{ contain: 'content' }}
            dangerouslySetInnerHTML={{ __html: streamingMdCache.render(completedContent) }} />
        );
      }

      return (
        <>
          <div className="break-words" style={{ contain: 'content' }}
            dangerouslySetInnerHTML={{ __html: streamingMdCache.render(completedContent) }} />
          {hasBlockElement(lastPara) ? (
            <CompletedTextBlock content={lastPara} caret />
          ) : (
            <LightweightMarkdown content={lastPara} caret />
          )}
        </>
      );
    }

    // 有代码块路径
    const parts = splitByCodeBlocks(content);

    return (
      <div className="break-words">
        {parts.map((part, index) => {
          // Mermaid 图表块
          if (part.type === 'mermaid-block') {
            return (
              <DeferredMermaidDiagram
                key={`mermaid-${index}`}
                code={part.content}
                id={`mermaid-${Date.now()}-${index}`}
                isStreaming={!completed}
              />
            );
          }

          // 代码块
          if (part.type === 'code-block') {
            return (
              <StreamingCodeBlock
                key={`code-${index}`}
                content={part.content}
                language={part.language}
                completed={part.completed}
              />
            );
          }

          // 已完成文本：单一容器渲染
          if (part.completed) {
            return (
              <CompletedTextBlock
                key={`ctext-${index}`}
                content={part.content}
                blockIndex={index}
              />
            );
          }

          // 未完成文本 + completed：整段完整渲染
          if (completed) {
            return (
              <CompletedTextBlock
                key={`ctext-${index}`}
                content={part.content}
                blockIndex={index}
              />
            );
          }

          // 未完成文本（流式中）：段落级渐进渲染
          const paragraphs = part.content.split(PARAGRAPH_SPLIT_RE);
          if (paragraphs.length <= 1) {
            // 流式最后一段含块级元素 → 走 marked 完整渲染
            if (hasBlockElement(part.content)) {
              return <CompletedTextBlock key={`ctext-${index}`} content={part.content} caret />;
            }
            return <LightweightMarkdown key={`ltext-${index}`} content={part.content} caret />;
          }

          // 已完成段落合并 + 最后一段轻量
          const completedParasContent = paragraphs.slice(0, -1).join('\n\n') + '\n\n';
          const lastPara = paragraphs[paragraphs.length - 1];

          // 末段为空/纯空白：文本以段落边界收尾，最后一段已完整结束。
          // 空段不再挂流式光标（同无代码块路径的处理）。
          if (!lastPara.trim()) {
            return (
              <div key={`ctext-${index}`} className="break-words" style={{ contain: 'content' }}
                dangerouslySetInnerHTML={{ __html: streamingMdCache.render(completedParasContent) }} />
            );
          }

          return (
            <span key={`streaming-${index}`}>
              <div className="break-words" style={{ contain: 'content' }}
                dangerouslySetInnerHTML={{ __html: streamingMdCache.render(completedParasContent) }} />
              {hasBlockElement(lastPara) ? (
                <CompletedTextBlock content={lastPara} caret />
              ) : (
                <LightweightMarkdown content={lastPara} caret />
              )}
            </span>
          );
        })}
      </div>
    );
  }, [content, completed]);

  return result;
});
