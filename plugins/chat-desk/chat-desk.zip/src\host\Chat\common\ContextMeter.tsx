/**
 * 上下文用量水位条
 *
 * 对标 Claude Code 状态行(上下文百分比)+ /cost。
 * 水位分子 = input + cacheCreation + cacheRead(三项之和,非单一 input);
 * 分母 = 会话配置 contextWindow(缺省 200K)。
 * 主行使用紧凑圆圈进度；悬停/聚焦浮出详情卡:token 四分类 + 缓存命中率 + 阈值预警 +
 * 按模型维度用量明细 + 原始报文查看入口。
 *
 * **用量口径（对标 /context 与 /cost 语义）：** 水位三元组（input/cacheCreation/
 * cacheRead）优先来自 scope='turn' 的单轮快照（message_delta.usage，与 CLI /context
 * 读数一致）；引擎未提供快照时由 cumulative 累计兜底（contextSource='cumulative'，
 * 详情卡标注"估算"）。模型维度明细/成本恒为本次 run 累计（/cost 口径），与水位分开。
 *
 * **悬浮卡显隐（关键修复）：**
 * `active` 由锚点容器 + 卡片本身两个独立事件宿主共同维持，覆盖 `mb-2` 间隙造成的
 * hover 命中区断开：anchor.onMouseLeave 不再关闭卡片（已移除），card.onMouseLeave 兜底
 * 处理"鼠标从卡片离开到外部"的失活。anchor.onBlur 做 relatedTarget 白检，避免 anchor
 * 与 card 之间的 Tab 流转误关卡片。
 */
import { useState, useRef } from 'react';
import { clsx } from 'clsx';
import type { UsageStats } from '@/stores/conversationStore/types';
import type { StreamRateSnapshot } from '@/services/streamRateTracker';
import { eventBus } from '@/services/eventBus';
import { useNowTicker } from '@/hooks/useNowTicker';

interface ContextMeterProps {
  usage: UsageStats;
  /** 会话配置里的上下文窗口;usage.contextWindow 优先,其次此值,再兜底 200K */
  contextWindow?: number;
  /** 主行标签密度：full=used/window, percent=百分比, icon=仅圆圈 */
  labelMode?: 'full' | 'percent' | 'icon';
  /** 当前会话引擎 ID：用于区分"自动压缩"vs"需手动压缩交接"提示文案。
   * simple-ai/claude-code 有运行时压缩。 */
  engineId?: string;
  /** 本轮生成速率快照（TTFT / TPS / 耗时）。有值时在详情卡展示速率区。 */
  streamRate?: StreamRateSnapshot | null;
  /** 是否流式进行中（影响速率区的口径标注） */
  streaming?: boolean;
}

/** 引擎是否具备运行时自动压缩能力 */
function engineHasAutoCompact(engineId?: string): boolean {
  return engineId === 'simple-ai' || engineId === 'claude-code';
}

/** 压缩阈值(与 SimpleAI compact.rs 默认对齐) */
const COMPACT_THRESHOLD = 0.8;
const CRITICAL_THRESHOLD = 0.95;
const RING_RADIUS = 9;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

function fmt(n: number): string {
  return formatTokensStrict(n);
}

function fmtCost(n: number | undefined): string {
  if (n == null || n === 0) return '';
  return `$${n.toFixed(4)}`;
}

/** 毫秒 → 可读时长（<1s 显示 ms，≥1s 显示秒） */
function fmtSeconds(ms: number): string {
  return ms < 1000 ? `${Math.round(ms)}ms` : `${(ms / 1000).toFixed(1)}s`;
}

import { formatTokensStrict } from '@/utils/formatTokens';

/**
 * 判断焦点相关目标是否仍在 anchor 或 card 区域内。用于 anchor.onBlur 白检，
 * 避免 Tab 在 anchor↔card 之间流转时误关卡片。
 */
function isFocusStillInside(
  relatedTarget: EventTarget | null,
  anchorRef: React.RefObject<HTMLDivElement | null>,
  cardRef: React.RefObject<HTMLDivElement | null>,
): boolean {
  const anchor = anchorRef.current;
  const card = cardRef.current;
  if (!anchor || !card) return false;
  if (relatedTarget == null) return false;
  if (!(relatedTarget instanceof HTMLElement)) return false;
  return anchor.contains(relatedTarget) || card.contains(relatedTarget);
}

export function ContextMeter({ usage, contextWindow, labelMode = 'full', engineId, streamRate, streaming }: ContextMeterProps) {
  const [active, setActive] = useState(false);
  const [showRaw, setShowRaw] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const cw = usage.contextWindow ?? contextWindow ?? 200000;
  const used = usage.input + usage.cacheCreation + usage.cacheRead;
  const pct = cw > 0 ? used / cw : 0;
  const pctClamped = Math.min(Math.max(pct, 0), 1);
  // 缓存命中率（成本口径 B：cacheRead / (input + cacheRead)，跨域统一）。
  // 仅当存在缓存读取数据时才展示，避免「无缓存数据」误显示 0%。
  const hitRateDenom = usage.input + usage.cacheRead;
  const hitRate = hitRateDenom > 0 && usage.cacheRead > 0
    ? Math.round((usage.cacheRead / hitRateDenom) * 100)
    : null;

  const modelUsage = usage.modelUsage;
  const modelCount = modelUsage ? Object.keys(modelUsage).length : 0;
  const totals = usage.sessionTotals;
  /** 实际路由模型中与配置名不同的部分（官方端点下响应模型 == 配置名，无需标注） */
  const routedModels = usage.actualModels ?? [];

  const level =
    pct >= CRITICAL_THRESHOLD ? 'crit' : pct >= COMPACT_THRESHOLD ? 'warn' : 'ok';
  const accentColor =
    level === 'crit'
      ? 'text-red-400'
      : level === 'warn'
        ? 'text-amber-400'
        : 'text-primary';
  const labelColor =
    level === 'crit'
      ? 'text-red-400'
      : level === 'warn'
        ? 'text-amber-400'
        : 'text-text-secondary';

  // 三段宽度(相对窗口)，主行圆圈只表达总量与风险等级，详情卡保留构成信息。
  const wi = Math.min((usage.input / cw) * 100, 100);
  const wc = Math.min((usage.cacheCreation / cw) * 100, 100);
  const wr = Math.min((usage.cacheRead / cw) * 100, 100);

  const winLabel = formatTokensStrict(cw);
  const percentLabel = `${Math.round(pct * 100)}%`;
  const mainLabel = labelMode === 'full'
    ? `${fmt(used)}/${winLabel}`
    : labelMode === 'percent'
      ? percentLabel
      : null;
  const ariaLabel = `上下文用量 ${percentLabel}，${fmt(used)}/${winLabel}`;
  const ringOffset = RING_CIRCUMFERENCE * (1 - pctClamped);

  // 生成速率区（本轮 TTFT / TPS / 耗时），仅当存在速率数据时展示
  const rateTps = streamRate?.avgTps ?? streamRate?.tps ?? null;
  const rateTpsLabel = rateTps != null && rateTps > 0 ? rateTps.toFixed(1) : null;
  const rateTtft = streamRate?.ttftMs != null && streamRate.ttftMs >= 100 ? streamRate.ttftMs : null;
  const rateGen = streamRate?.generationMs != null && streamRate.generationMs > 0 ? streamRate.generationMs : null;

  // 运行时长（墙钟）：流式中由 useNowTicker 每秒驱动重算，避免 chunk 间隙停滞；
  // 结束态用 snapshot 定格的 wallClockMs。periodStartMs 缺省（引擎未传 receivedAtMs）时不显示。
  // ticker 只在「详情卡展开且流式中」才走：详情卡未展开时用户看不到运行时长，
  // 不必每秒重渲染整个 ContextMeter（含 ring SVG）。结束时用定格值，也不需要 tick。
  const now = useNowTicker(active === true && streaming === true);
  const rateWall = (() => {
    const startMs = streamRate?.periodStartMs;
    if (startMs == null) return null;
    if (streamRate?.settled) return streamRate.wallClockMs ?? null;
    if (streaming !== true) return streamRate?.wallClockMs ?? null;
    // 详情卡未展开：用 streamRate 上一次 snapshot 的 wallClockMs（跟随 chunk 刷新），
    // 不开 ticker，避免空转。展开后切换为 now 驱动的实时值。
    if (active !== true) return streamRate?.wallClockMs ?? null;
    return Math.max(0, now - startMs);
  })();

  return (
    <div
      ref={anchorRef}
      tabIndex={0}
      role="status"
      aria-label={ariaLabel}
      title={ariaLabel}
      className="relative flex items-center gap-1 px-1.5 py-0.5 rounded-full cursor-default hover:bg-background-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 transition-colors shrink-0"
      onMouseEnter={() => setActive(true)}
      onFocus={() => setActive(true)}
      onBlur={(e) => {
        if (!isFocusStillInside(e.relatedTarget, anchorRef, cardRef)) {
          setActive(false);
          setShowRaw(false);
        }
      }}
    >
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        className={clsx('shrink-0 -rotate-90', accentColor)}
        aria-hidden="true"
      >
        <circle
          cx="12"
          cy="12"
          r={RING_RADIUS}
          fill="none"
          stroke="currentColor"
          strokeWidth="2.8"
          className="opacity-20"
        />
        <circle
          cx="12"
          cy="12"
          r={RING_RADIUS}
          fill="none"
          stroke="currentColor"
          strokeWidth="2.8"
          strokeLinecap="round"
          strokeDasharray={RING_CIRCUMFERENCE}
          strokeDashoffset={ringOffset}
          className="transition-[stroke-dashoffset] duration-300"
        />
      </svg>
      {mainLabel && (
        <span className={clsx('font-mono text-[11px] tabular-nums whitespace-nowrap', labelColor)}>
          {mainLabel}
        </span>
      )}

      {/* 悬浮详情卡 */}
      {active && (
        <div
          ref={cardRef}
          className={clsx(
            'absolute bottom-full right-0 mb-2 z-dropdown rounded-xl border border-border-subtle bg-background-elevated p-3 shadow-xl',
            showRaw ? 'w-[480px]' : 'w-[310px]',
          )}
          onMouseEnter={() => setActive(true)}
          onMouseLeave={() => {
            setActive(false);
            setShowRaw(false);
          }}
        >
          {showRaw && usage.rawPayload ? (
            /* 原始报文查看模式 */
            <div className="max-h-[400px] overflow-auto">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] uppercase tracking-wide text-text-muted">原始 result 报文</span>
                <button
                  className="text-[11px] text-primary hover:underline"
                  onClick={() => setShowRaw(false)}
                >
                  返回
                </button>
              </div>
              <pre className="text-[11px] font-mono text-text-secondary whitespace-pre-wrap break-all leading-relaxed">
                {JSON.stringify(usage.rawPayload, null, 2)}
              </pre>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] uppercase tracking-wide text-text-muted">
                  上下文用量
                  {usage.contextSource === 'cumulative' && (
                    <span
                      className="ml-1 normal-case tracking-normal text-amber-400/80"
                      title="该引擎未提供单轮用量快照，水位按本轮累计估算，多轮工具调用时可能偏大"
                    >
                      · 估算
                    </span>
                  )}
                </span>
                <span className={clsx('font-mono text-[11px]', labelColor)}>{percentLabel} · {winLabel}</span>
              </div>
              <div className="h-2 rounded bg-background-tertiary overflow-hidden flex mb-2.5 relative">
                <div className="h-full bg-primary" style={{ width: `${wi}%` }} />
                <div className="h-full bg-amber-500" style={{ width: `${wc}%` }} />
                <div className="h-full bg-purple-400" style={{ width: `${wr}%` }} />
                <div
                  className="absolute top-[-1px] h-[10px] w-px bg-text-tertiary"
                  style={{ left: `${COMPACT_THRESHOLD * 100}%` }}
                />
              </div>
              <div className="grid grid-cols-[1fr_auto] gap-y-1.5 gap-x-3 text-[12px]">
                <MeterRow color="bg-primary" label="输入 input" value={usage.input} />
                {usage.cacheCreation > 0 && (
                  <MeterRow color="bg-amber-500" label="缓存写入" value={usage.cacheCreation} />
                )}
                {usage.cacheRead > 0 && (
                  <MeterRow color="bg-purple-400" label="缓存读取" value={usage.cacheRead} />
                )}
                <MeterRow color="bg-text-tertiary" label="输出(本轮)" value={usage.output} dim />
              </div>
              {hitRate != null && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle flex items-center justify-between">
                  <span
                    className="text-[11px] text-text-muted"
                    title="缓存命中率 = 缓存读取 / (输入 + 缓存读取)，成本口径；与全局 Token 统计面板一致"
                  >
                    缓存命中率
                  </span>
                  <span className="font-mono text-[12px] text-purple-400">{hitRate}%</span>
                </div>
              )}

              {/* 响应侧实际模型（中转站动态路由时与配置名不同，且逐轮可变） */}
              {usage.actualModel && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle flex items-center justify-between gap-2">
                  <span className="text-[11px] text-text-muted shrink-0">实际模型</span>
                  <span
                    className="font-mono text-[11px] text-text-secondary truncate"
                    title={
                      routedModels.length > 1
                        ? `本会话实际路由过：${routedModels.join(' → ')}`
                        : undefined
                    }
                  >
                    {usage.actualModel}
                    {routedModels.length > 1 && (
                      <span className="text-text-muted"> +{routedModels.length - 1}</span>
                    )}
                  </span>
                </div>
              )}

              {/* 生成速率（本轮 TTFT / TPS / 生成耗时 / 运行时长） */}
              {(rateTpsLabel || rateTtft || rateGen || rateWall != null) && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle">
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className="text-[11px] text-text-muted"
                      title="本轮回复的端到端生成速率（含思考与工具间隔）；流式期间为即时滚窗值，结束后为全程平均。运行时长 = session_start 到 session_end 的墙钟时长（含 prefill 与工具间隙）"
                    >
                      生成速率
                    </span>
                    <span className="text-[10px] text-text-muted">
                      {streaming ? '即时' : '平均'}
                      {streamRate?.providerTokens != null
                        ? ` · ${streamRate.providerTokens.toLocaleString()} tok`
                        : ''}
                    </span>
                  </div>
                  <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-0.5 text-[11px]">
                    {rateTpsLabel && (
                      <>
                        <span className="text-text-muted">速率 TPS</span>
                        <span className="font-mono text-right tabular-nums text-primary">
                          {rateTpsLabel}
                          <span className="text-text-muted ml-1">tok/s</span>
                        </span>
                      </>
                    )}
                    {rateTtft != null && (
                      <>
                        <span className="text-text-muted">首 token</span>
                        <span className="font-mono text-right tabular-nums text-text-secondary">
                          {fmtSeconds(rateTtft)}
                        </span>
                      </>
                    )}
                    {rateGen != null && (
                      <>
                        <span className="text-text-muted">生成耗时</span>
                        <span className="font-mono text-right tabular-nums text-text-secondary">
                          {fmtSeconds(rateGen)}
                        </span>
                      </>
                    )}
                    {rateWall != null && (
                      <>
                        <span className="text-text-muted">运行时长</span>
                        <span className="font-mono text-right tabular-nums text-text-secondary">
                          {fmtSeconds(rateWall)}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* 会话累计（跨消息累加每次 run 的用量，对标 /cost 总量） */}
              {totals && totals.runs > 0 && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle">
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className="text-[11px] text-text-muted"
                      title="本会话所有消息的累计消耗（对标 /cost）；当前上下文占用看上方水位"
                    >
                      会话累计
                    </span>
                    <span className="text-[10px] text-text-muted">{totals.runs} 条消息</span>
                  </div>
                  <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-0.5 text-[11px]">
                    <MeterRow color="bg-primary/60" label="输入合计" value={totals.input} dim />
                    {totals.cacheCreation > 0 && (
                      <MeterRow color="bg-amber-500/60" label="缓存写入合计" value={totals.cacheCreation} dim />
                    )}
                    {totals.cacheRead > 0 && (
                      <MeterRow color="bg-purple-400/60" label="缓存读取合计" value={totals.cacheRead} dim />
                    )}
                    <MeterRow color="bg-text-tertiary/60" label="输出合计" value={totals.output} dim />
                    {totals.costUsd > 0 && (
                      <>
                        <span className="text-text-muted flex items-center gap-1">
                          <span className="w-2 h-2 rounded-sm shrink-0 bg-transparent" />
                          总花费
                        </span>
                        <span className="font-mono text-right tabular-nums text-text-muted">
                          {fmtCost(totals.costUsd)}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* 按模型维度的本轮累计明细（/cost 口径，非当前上下文占用） */}
              {modelCount > 0 && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle">
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className="text-[11px] text-text-muted"
                      title="本次 run 内所有 API 调用的累计用量与花费（对标 /cost）；多轮工具调用时大于上方的当前上下文占用，属正常现象"
                    >
                      本轮累计 · 按模型
                    </span>
                    <span className="text-[10px] text-text-muted">{modelCount} 模型</span>
                  </div>
                  {modelUsage && Object.entries(modelUsage).map(([model, m]) => {
                    // key 是请求侧配置名（如中转站别名 qusc）；实际路由模型不同时标注
                    const routed = routedModels.filter((am) => am !== model);
                    return (
                    <div key={model} className="mb-2 last:mb-0">
                      <div
                        className="text-[11px] font-medium text-text-secondary mb-1 truncate"
                        title={routed.length > 0 ? `配置模型 ${model}，实际路由：${routedModels.join(' / ')}` : undefined}
                      >
                        {model}
                        {routed.length > 0 && (
                          <span className="font-normal text-text-muted"> · 实际 {routed.join(' / ')}</span>
                        )}
                      </div>
                      <div className="grid grid-cols-[1fr_auto] gap-x-2 gap-y-0.5 text-[11px]">
                        <MeterRow color="bg-primary/60" label="输入" value={m.inputTokens} dim />
                        {m.cacheCreationInputTokens != null && m.cacheCreationInputTokens > 0 ? (
                          <MeterRow color="bg-amber-500/60" label="缓存写入" value={m.cacheCreationInputTokens} dim />
                        ) : null}
                        {m.cacheReadInputTokens != null && m.cacheReadInputTokens > 0 ? (
                          <MeterRow color="bg-purple-400/60" label="缓存读取" value={m.cacheReadInputTokens} dim />
                        ) : null}
                        <MeterRow color="bg-text-tertiary/60" label="输出" value={m.outputTokens} dim />
                        {m.costUsd != null && m.costUsd > 0 ? (
                          <>
                            <span className="text-text-muted flex items-center gap-1">
                              <span className="w-2 h-2 rounded-sm shrink-0 bg-transparent" />
                              花费
                            </span>
                            <span className="font-mono text-right tabular-nums text-text-muted">{fmtCost(m.costUsd)}</span>
                          </>
                        ) : null}
                      </div>
                    </div>
                    );
                  })}
                </div>
              )}

              {/* 原始报文查看按钮 */}
              {usage.rawPayload && (
                <div className="mt-2.5 pt-2.5 border-t border-border-subtle">
                  <button
                    className="flex items-center gap-1 text-[11px] text-text-muted hover:text-primary transition-colors"
                    onClick={() => setShowRaw(true)}
                  >
                    <span className="text-xs">📄</span>
                    查看原始报文
                  </button>
                </div>
              )}

              {/* 查看完整 Token 统计 */}
              <div className="mt-2.5 pt-2.5 border-t border-border-subtle">
                <button
                  className="flex items-center gap-1 text-[11px] text-text-muted hover:text-primary transition-colors"
                  onClick={() => {
                    eventBus.emit('polaris:open-settings', { tab: 'token-stats' })
                    setActive(false)
                  }}
                >
                  <span className="text-xs">📊</span>
                  查看 Token 统计
                </button>
              </div>

              {level !== 'ok' && (
                <div
                  className={clsx(
                    'mt-2.5 rounded-md px-2 py-1.5 text-[11px]',
                    level === 'crit'
                      ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/30',
                  )}
                >
                  {level === 'crit'
                    ? `逼近上下文窗口(${percentLabel})· 建议压缩交接或开启新会话`
                    : engineHasAutoCompact(engineId)
                      ? `接近压缩阈值(${percentLabel})· 即将自动压缩上下文`
                      : `接近上下文上限(${percentLabel})· 该引擎无自动压缩，建议压缩交接`}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

function MeterRow({
  color,
  label,
  value,
  dim,
}: {
  color: string;
  label: string;
  value: number;
  dim?: boolean;
}) {
  return (
    <>
      <span className={clsx('flex items-center gap-2', dim ? 'text-text-muted' : 'text-text-secondary')}>
        <span className={clsx('w-2 h-2 rounded-sm shrink-0', color)} />
        {label}
      </span>
      <span className={clsx('font-mono text-right tabular-nums', dim ? 'text-text-muted' : 'text-text-primary')}>
        {value.toLocaleString()}
      </span>
    </>
  );
}