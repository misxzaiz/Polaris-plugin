import type { ChatMessage, EngineId, Workspace } from '@/types'
import type { SessionRuntimeConfig, ProfileMode } from '@/types/sessionConfig'
import { sessionStoreManager } from './sessionStoreManager'
import { normalizeEngineId } from '@/utils/engineDisplay'
import { useEngineMetadataStore } from '@/stores/engineMetadataStore'
import { listPluginMcpServerStatuses } from '@/plugin-system'
import { usePluginStore } from '../../shims/stores'
import { useConfigStore } from '../../shims/stores'
import { getUserSystemPrompt } from '@/services/workspaceReference'
import { toAppError, ErrorSource } from '@/types/errors'
import { OFFICIAL_API_PROFILE } from '@/types/modelProfile'
import i18n from 'i18next'

export function resolveSessionEngine(sessionId: string, configEngineId?: string): EngineId {
  const metadataEngineId = sessionStoreManager.getState().sessionMetadata.get(sessionId)?.engineId
  return normalizeEngineId(metadataEngineId || configEngineId)
}

/**
 * 解析辅助任务引擎（标题生成 / 润色等低频任务）。
 *
 * 优先级：
 * 1. config.auxiliaryEngine（非空且合法）→ 该引擎
 * 2. 主引擎（defaultEngine）
 *
 * 用于将辅助任务路由到更便宜的引擎以降本；用户留空 = 跟随主引擎。
 */
export function resolveAuxiliaryEngine(config?: { auxiliaryEngine?: string; defaultEngine?: string } | null): EngineId {
  const aux = config?.auxiliaryEngine
  if (aux && aux.trim()) {
    // 只在 aux 为合法引擎 ID 时采用，否则降级主引擎
    return normalizeEngineId(aux)
  }
  return normalizeEngineId(config?.defaultEngine)
}

export function resolveRuntimeConfigForEngine(
  sessionConfig: SessionRuntimeConfig,
  engineId: EngineId
): Partial<SessionRuntimeConfig> {
  const model = sessionConfig.model || undefined

  // agent / effort 透传引擎能力驱动，不再按引擎 ID 硬编码白名单：
  // - 引擎声明 sessionConfig.selectors 含 'agent' / 'effort' → 透传（插件引擎声明优先）
  // - 未声明的引擎按能力标志兜底：有 tools 能力（可调用工具 → 可有人格）→ agent；
  //   内置引擎（claude-code/simple-ai）恒支持 effort（历史行为保持）
  // - 权限模式对所有引擎透传（各引擎 adapter 自行映射白名单值）
  const meta = useEngineMetadataStore.getState().getEngine(engineId as string)
  const declaredSelectors = meta?.sessionConfig?.selectors
  const caps = meta?.capabilities

  const agentSupported = declaredSelectors
    ? declaredSelectors.includes('agent')
    : engineId === 'claude-code' || engineId === 'simple-ai' || (caps?.tools ?? false)
  const effortSupported = declaredSelectors
    ? declaredSelectors.includes('effort')
    : engineId === 'claude-code' || engineId === 'simple-ai'

  return {
    // agent persona 透传：
    // - claude-code：经 --agent 透传 CLI（注：当前 corpus 未暴露给 CLI，U2-4 待补）
    // - simple-ai：经 SessionOptions.agent 注入 corpus persona（见 simple_ai/mod.rs start_session）
    // - 插件引擎：引擎声明 selectors 含 agent 即透传（如 codebuddy --agent）
    agent: agentSupported ? sessionConfig.agent || undefined : undefined,
    model,
    // effort 透传：
    // - claude-code：经 --effort 传给 CLI
    // - simple-ai：经 SessionOptions.effort 注入请求体（OpenAIChat → reasoning_effort /
    //   Anthropic → thinking.budget_tokens / Responses → reasoning.effort，见 simple_ai_protocol.rs）
    // - 插件引擎：引擎声明 selectors 含 effort 即透传（如 codebuddy --effort）
    effort: effortSupported ? sessionConfig.effort || undefined : undefined,
    permissionMode: sessionConfig.permissionMode || undefined,
  }
}

export function getDisabledPluginMcpServers(): string[] {
  const list = listPluginMcpServerStatuses(usePluginStore.getState().pluginStates)
    .filter((server) => !server.enabled)
    .map((server) => server.id)
  // cap.ui 控制界面能力（主题/对话渲染）默认不暴露给 AI：uiControlEnabled 关闭
  // （默认）时禁用 bus MCP（polaris-bus），AI 工具集不含 bus_dispatch → 无 cap.ui.*。
  // 开启后 bus MCP 正常挂载，AI 经 bus_dispatch 调 cap.ui.theme / cap.ui.chat。
  // 与后端 policy_permission 的 Remote-deny 双保险互补（此处管本地 AI 工具暴露）。
  if (!useConfigStore.getState().config?.uiControlEnabled) {
    list.push('polaris-bus')
  }
  return list
}

/**
 * 解析发送 / 继续消息时最终生效的模型 Profile ID。
 *
 * 三态优先级：
 * 1. 会话级覆盖（SessionMetadata.modelProfileId）—— 最高优先级、三态权威：
 *    - 哨兵 OFFICIAL_API_PROFILE 或空串 → 用户明确选官方 API，返回 undefined（不使用任何 Profile）
 *    - 具体 id → 使用该 Profile
 *    - undefined → 从未设置，向下降级
 * 2. 状态栏镜像（sessionConfig.modelProfileId）
 * 3. 设置页激活的全局默认（globalActiveProfileId）
 *
 * 返回 `undefined` 表示「走官方端点」。哨兵值绝不会作为结果返回，确保不透传后端
 * （后端按 id 查找，拿到哨兵会命中 notFoundRuntime 中断请求）。
 */
export function resolveEffectiveProfileId(
  sessionMetaProfileId: string | undefined,
  sessionConfigProfileId: string | undefined,
  globalActiveProfileId: string | undefined,
): string | undefined {
  // 会话级覆盖存在（含「明确官方」）时以它为准，不再向下降级
  if (sessionMetaProfileId !== undefined) {
    return sessionMetaProfileId === OFFICIAL_API_PROFILE || sessionMetaProfileId === ''
      ? undefined
      : sessionMetaProfileId
  }
  // 无会话级覆盖 → 降级状态栏镜像，再降级全局默认（两者按惯例只存真实 id 或空串）
  const fallback = sessionConfigProfileId || globalActiveProfileId
  return fallback && fallback !== OFFICIAL_API_PROFILE ? fallback : undefined
}

/**
 * 解析发送 / 继续消息时最终生效的供应商选择模式（官方 / 指定 Profile）。
 *
 * 数据源优先级与 [`resolveEffectiveProfileId`] 完全一致：
 * 1. 会话级覆盖（SessionMetadata.profileMode）—— 最高优先级、权威
 * 2. 状态栏镜像（sessionConfig.profileMode）
 * 3. 兜底默认 `'profile'`（与旧行为一致：modelProfileId 为空即官方）
 *
 * 返回值语义（配合 resolveEffectiveProfileId 使用）：
 * - `'official'`：强制官方端点 → 发送层必须传 modelProfileId=undefined
 * - `'profile'`：使用 Profile → modelProfileId 由 resolveEffectiveProfileId 决定
 * - `undefined`：跟随全局旧逻辑（不发 profileMode 字段，后端 None 向前兼容）
 *
 * 双函数在调用点成对使用，保证二态不冲突：
 *   const mode = resolveEffectiveProfileMode(meta.profileMode, cfg.profileMode)
 *   const pid = resolveEffectiveProfileId(meta.modelProfileId, cfg.modelProfileId, globalActive)
 *   // 若 mode 为 official，pid 必须随 setModelProfileId 清理为空
 */
export function resolveEffectiveProfileMode(
  sessionMetaProfileMode: ProfileMode | undefined,
  sessionConfigProfileMode: ProfileMode | undefined,
): ProfileMode | undefined {
  // 会话级覆盖存在时以它为准
  if (sessionMetaProfileMode !== undefined) {
    return sessionMetaProfileMode
  }
  // 无会话级覆盖 → 跟随状态栏镜像（含全局默认，normalizeSessionConfig 已兜底）
  if (sessionConfigProfileMode !== undefined && sessionConfigProfileMode !== 'profile') {
    return sessionConfigProfileMode
  }
  // 镜像为 'profile' 或未设置时跟随状态栏镜像（'profile' / undefined）。
  return sessionConfigProfileMode
}

/**
 * 判断用户是否明确选择了「官方」——该模式下 modelProfileId 必须为空。
 * 用于发送链路在传 options 前做防御性归一：避免「选官方却残留 Profile 穿透」。
 */
export function isProfileModeWithoutProfile(mode: ProfileMode | undefined): boolean {
  return mode === 'official'
}

/**
 * 解析聊天发送/继续时的错误为可展示文案。
 *
 * 后端业务错误（i18n key，以 `errors:` 开头，如 `errors:modelProfile.notFoundRuntime`）
 * 原样透传给 ErrorBanner（其内部会按 key 翻译）；其余错误按 AI 来源包装为泛化文案。
 */
export function resolveChatError(e: unknown, context: Record<string, unknown>): string {
  const raw = typeof e === 'string' ? e : e instanceof Error ? e.message : ''
  if (raw.startsWith('errors:')) {
    return raw
  }
  return toAppError(e, { source: ErrorSource.AI, context }).getUserMessage()
}

// ============================================================================
// 历史消息降级恢复
// ============================================================================

// 说明：此前这里有一条「localStorage 历史（event_chat_session_history）」的
// 压缩消息二级恢复链路（hydrateFromLocalStorage + 解析缓存）。该 key 的写入方
// （historyService.saveToHistory）早已无人调用，链路恒 miss——这正是
// "长会话滚回历史只见截断内容 / 截断态被覆写进 JSONL"的根因。
// 现压缩消息的磁盘兜底统一走自有 JSONL：
// dialogStorageService.getCachedFullMessage / loadMessageMap。

/**
 * 校验外部来源恢复的消息是否具有完整结构
 * 防止因数据污染或版本不兼容导致坏数据注入 store
 */
export function isValidMessageStructure(msg: unknown): msg is ChatMessage {
  if (!msg || typeof msg !== 'object') return false
  const m = msg as Record<string, unknown>
  if (typeof m.id !== 'string' || typeof m.type !== 'string' || typeof m.timestamp !== 'string') return false
  // assistant 消息必须有 blocks 数组
  if (m.type === 'assistant') return Array.isArray(m.blocks)
  // user 消息必须有 content 字符串
  if (m.type === 'user') return typeof m.content === 'string'
  return true
}

/**
 * 从用户消息生成标题
 * 取前 16 个字符作为标题，超出的部分用省略号
 */
export function generateTitleFromMessage(content: string): string {
  const cleanContent = content.replace(/\n/g, ' ').trim()
  const maxTitleLength = 16
  if (cleanContent.length <= maxTitleLength) {
    return cleanContent
  }
  return cleanContent.slice(0, maxTitleLength) + '...'
}

// ============================================================================
// 工作区提示词构建
// ============================================================================

export interface WorkspacePrompts {
  workspacePrompt: string
  userPrompt: string | null
  contextWorkspaces: Workspace[]
  allWorkspaces: Workspace[]
}

/**
 * 构建工作区系统提示词和用户自定义提示词
 * sendMessage 和 continueChat 共用
 */
export function buildWorkspacePrompts(
  getWorkspace: () => Workspace | null,
  getContextWorkspaceIds: () => string[],
  getAllWorkspaces: () => Workspace[],
): WorkspacePrompts {
  const currentWorkspace = getWorkspace()
  const contextWorkspaceIds = getContextWorkspaceIds()
  const allWorkspaces = getAllWorkspaces()
  const contextWorkspaces = allWorkspaces.filter(w => contextWorkspaceIds.includes(w.id))

  let workspacePrompt = ''
  if (currentWorkspace) {
    workspacePrompt = i18n.t('systemPrompt:workingIn', { name: currentWorkspace.name }) + '\n' +
      i18n.t('systemPrompt:projectPath', { path: currentWorkspace.path }) + '\n' +
      i18n.t('systemPrompt:fileRefSyntax')
  }

  let userPrompt: string | null = null
  if (currentWorkspace) {
    userPrompt = getUserSystemPrompt(currentWorkspace, contextWorkspaces)
  }

  return { workspacePrompt, userPrompt, contextWorkspaces, allWorkspaces }
}

/**
 * 规范化文本用于 Tauri IPC 传输
 * 将换行符统一转义为 \\n 字面量
 */
export function normalizeForInvoke(text: string): string {
  return text
    .replace(/\r\n/g, '\\n')
    .replace(/\r/g, '\\n')
    .replace(/\n/g, '\\n')
    .trim()
}
