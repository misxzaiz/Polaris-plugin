/**
 * 工具调用块渲染器 - 优化版本
 */

import { memo, useState, useMemo, useCallback, useEffect } from 'react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { clsx } from 'clsx';
import { Check, XCircle, ChevronDown, ChevronRight, Code, Copy, ListChecks } from 'lucide-react';
import type { ToolCallBlock } from '@/types';
import { getToolConfig, extractToolKeyInfo, getToolShortName } from '@/utils/toolConfig';
import { extractFullFilePath, extractFullCommand } from '@/utils/toolInputExtractor';
import { copyToClipboard } from '@/utils/clipboard';
import { useFileEditorStore } from '@/stores/fileEditorStore';
import { useWorkspaceStore } from '@/stores/workspaceStore';
import {
  formatDuration,
  calculateDuration,
  generateCollapsedSummary,
  stripAnsiCodes,
  parseGrepMatches,
} from '@/utils/toolSummary';
import { InlineDiffView } from './InlineDiffView';
import { JsonTreeView } from '../../../shims/misc';
import { isEditTool, isWriteTool } from '@/utils/diffExtractor';
import { STATUS_CONFIG } from '../chatUtils/constants';
import { isGrepTool } from '../chatUtils/helpers';
import { GrepOutputRenderer } from './GrepOutputRenderer';
import { PatchDiffRenderer } from './PatchDiffRenderer';
import { CodePreviewView } from './CodePreviewView';
import { highlightCode } from '@/utils/syntaxHighlight';
import { ansiToHtml } from '@/utils/ansiToHtml';

export const ToolCallBlockRenderer = memo(function ToolCallBlockRenderer({
  block,
  isStreaming,
  compact = false,
}: {
  block: ToolCallBlock;
  isStreaming?: boolean;
  /** 精炼模式：供补充卡片段落列表使用，去掉外层卡片壳（圆角/底色/色条），保留全部工具专属内容 */
  compact?: boolean;
}) {
  const { t } = useTranslation('chat');
  // edit/write 工具流式期间默认展开，方便查看 diff/预览
  const [isExpanded, setIsExpanded] = useState(() =>
    (isEditTool(block.name) || isWriteTool(block.name)) && isStreaming === true
  );
  const [showFullOutput, setShowFullOutput] = useState(false);
  const [showToolDetails, setShowToolDetails] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState(false);
  const [copiedOutput, setCopiedOutput] = useState(false);

  // 获取工具配置
  const toolConfig = useMemo(() => getToolConfig(block.name), [block.name]);

  // 文件路径点击打开编辑器
  const openFile = useFileEditorStore((s) => s.openFile);
  const currentWorkspace = useWorkspaceStore((s) => {
    const { workspaces, currentWorkspaceId } = s;
    return workspaces.find(w => w.id === currentWorkspaceId) || null;
  });
  const fullFilePath = useMemo(() => extractFullFilePath(block.input), [block.input]);

  const handleFilePathClick = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (!fullFilePath) return;
    const isAbsolute = fullFilePath.startsWith('/') || /^[A-Za-z]:[\\/]/.test(fullFilePath);
    const absolutePath = isAbsolute
      ? fullFilePath
      : currentWorkspace
        ? (currentWorkspace.path.replace(/[\\/]+$/, '') + '/' + fullFilePath.replace(/^[\\/]+/, ''))
        : fullFilePath;
    const fileName = fullFilePath.split(/[/\\]/).pop() || fullFilePath;
    openFile(absolutePath, fileName);
  }, [fullFilePath, currentWorkspace, openFile]);

  /** 从 InlineDiffView 回调打开文件（接受路径字符串，非事件） */
  const handleOpenFileByPath = useCallback((path: string) => {
    if (!path) return;
    const isAbsolute = path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path);
    const absolutePath = isAbsolute
      ? path
      : currentWorkspace
        ? (currentWorkspace.path.replace(/[\\/]+$/, '') + '/' + path.replace(/^[\\/]+/, ''))
        : path;
    const fileName = path.split(/[\\/]/).pop() || path;
    openFile(absolutePath, fileName);
  }, [currentWorkspace, openFile]);

  // 状态图标
  const statusConfig = STATUS_CONFIG[block.status] || STATUS_CONFIG.pending;
  const StatusIcon = statusConfig.icon;

  // 计算耗时
  const duration = useMemo(() => {
    if (block.duration) return formatDuration(block.duration);
    const calculated = calculateDuration(block.startedAt, block.completedAt);
    return calculated ? formatDuration(calculated) : '';
  }, [block.duration, block.startedAt, block.completedAt]);

  // 耗时毫秒数：用于决定是否显示耗时/起止时间（仅 > 1s 才显示，秒级完成不占位）。
  const durationMs = useMemo(() => {
    if (block.duration) return block.duration;
    return calculateDuration(block.startedAt, block.completedAt) ?? 0;
  }, [block.duration, block.startedAt, block.completedAt]);

  // 失败摘要：从 error 文本中提取首行非空内容，用于折叠态头部一行展示。
  const errorSummary = useMemo(() => {
    if (block.status !== 'failed' || !block.error) return '';
    const firstLine = block.error.split('\n').map((l) => l.trim()).find((l) => l.length > 0);
    return firstLine ? (firstLine.length > 80 ? firstLine.slice(0, 80) + '…' : firstLine) : '';
  }, [block.status, block.error]);

  // 流式结束后自动折叠 edit/write 面板
  useEffect(() => {
    if (!isStreaming && isExpanded && (isEditTool(block.name) || isWriteTool(block.name))) {
      setIsExpanded(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isStreaming]);

  // 提取关键信息
  const keyInfo = useMemo(() => extractToolKeyInfo(block.name, block.input), [block.name, block.input]);

  // Edit 工具的简化输出提示
  const editOutputSummary = useMemo(() => {
    if (!isEditTool(block.name) || block.status !== 'completed') {
      return null;
    }

    if (block.output) {
      const output = block.output.toLowerCase();
      // 成功
      if (output.includes('has been updated') ||
          output.includes('successfully edited') ||
          output.includes('edited successfully')) {
        return {
          type: 'success',
          text: t('tool.fileUpdated')
        };
      }
      // 失败
      if (output.includes('failed') ||
          output.includes('error') ||
          output.includes('could not')) {
        return {
          type: 'error',
          text: t('tool.fileUpdateFailed')
        };
      }
    }

    return null;
  // eslint-disable-next-line react-hooks/exhaustive-deps -- t is stable i18n function
  }, [block.output, block.name, block.status]);

  // 解析 Grep 数据
  const grepData = useMemo(() => {
    if (isGrepTool(block) && block.output) {
      return parseGrepMatches(block.output, block.input);
    }
    return null;
  }, [block]);

  // 判断输出是否需要展开功能
  const outputNeedsExpand = (block.output?.length ?? 0) > 1000;

  // 生成折叠状态的简化摘要（用于单行显示）
  const collapsedSummary = useMemo(() => {
    if (block.status === 'completed' || block.status === 'failed') {
      return generateCollapsedSummary(block.name, block.input, block.output, block.status);
    }
    return null;
  }, [block.name, block.input, block.output, block.status]);

  // 获取工具缩写
  const toolShortName = useMemo(() => getToolShortName(block.name), [block.name]);

  // 是否可展开
  const hasInput = block.input && Object.keys(block.input).length > 0;
  const hasOutput = block.output && block.output.length > 0;
  const hasError = block.status === 'failed' && block.error;
  const canExpand = hasInput || hasOutput || hasError;

  // 是否显示 Diff 按钮
  const showDiffButton = useMemo(() => {
    const isEdit = isEditTool(block.name);
    const isCompleted = block.status === 'completed';
    const hasDiff = !!block.diffData;

    return isEdit && isCompleted && hasDiff;
  }, [block.name, block.status, block.diffData]);

  // 是否有补丁数据（apply_patch）
  const hasPatchData = useMemo(() => {
    return block.name === 'apply_patch' && block.patchData && block.patchData.length > 0;
  }, [block.name, block.patchData]);

  // 是否为 update_plan（降级展示）
  const isUpdatePlan = useMemo(() => {
    return block.name === 'update_plan';
  }, [block.name]);

  // 是否使用专用输出渲染器
  const useCustomRenderer = grepData !== null || hasPatchData;

  // 状态动画类
  const statusAnimationClass = useMemo(() => {
    switch (block.status) {
      case 'pending':
        return 'animate-pulse border-dashed';
      case 'running':
        return 'animate-pulse';
      case 'completed':
        return '';
      case 'failed':
        return 'animate-shake-once';
      case 'partial':
        return '';
      default:
        return '';
    }
  }, [block.status]);

  // Bash 工具需要清理 ANSI 码
  const displayOutput = useMemo(() => {
    if (!block.output) return '';
    const normalizedToolName = block.name.toLowerCase();
    if (
      normalizedToolName.includes('bash') ||
      normalizedToolName.includes('command') ||
      normalizedToolName.includes('execute')
    ) {
      return stripAnsiCodes(block.output);
    }
    return block.output;
  }, [block.name, block.output]);

  // 是否为 Bash/Command 类工具
  const isBashTool = useMemo(() => {
    const n = block.name.toLowerCase();
    return n.includes('bash') || n.includes('command') || n.includes('execute');
  }, [block.name]);

  // Bash 工具输出渲染为彩色 HTML（保留 ANSI 颜色，仅用于展示）
  const renderedOutput = useMemo(() => {
    if (!block.output) return '';
    if (isBashTool) return ansiToHtml(block.output);
    return '';
  }, [block.name, block.output, isBashTool]);

  // 提取完整命令（用于复制，不截断）
  const fullCommand = useMemo(() => extractFullCommand(block.input), [block.input]);

  // 判断输出是否为 JSON 结构（用于走树形视图，而非纯文本 pre）。
  // 仅对以 { } 或 [ ] 包裹且能被 JSON.parse 成功的输出判定为 JSON。
  const outputIsJson = useMemo(() => {
    if (!displayOutput) return false;
    const trimmed = displayOutput.trim();
    if (!((trimmed.startsWith('{') && trimmed.endsWith('}')) ||
          (trimmed.startsWith('[') && trimmed.endsWith(']')))) {
      return false;
    }
    try {
      const parsed = JSON.parse(trimmed);
      return typeof parsed === 'object' && parsed !== null;
    } catch {
      return false;
    }
  }, [displayOutput]);

  // 复制命令回调
  const handleCopyCommand = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!fullCommand) return;
    await copyToClipboard(fullCommand);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 2000);
  }, [fullCommand]);

  // 复制输出回调（始终复制完整输出）
  const handleCopyOutput = useCallback(async () => {
    const text = block.output ? stripAnsiCodes(block.output) : '';
    if (!text) return;
    await copyToClipboard(text);
    setCopiedOutput(true);
    setTimeout(() => setCopiedOutput(false), 2000);
  }, [block.output]);

  return (
    <div
      className={clsx(
        compact
          ? 'w-full border-b border-border last:border-b-0'
          : 'my-1.5 rounded-lg overflow-hidden w-full transition-[border-color,background-color] duration-200 border border-border bg-background-elevated',
        compact ? '' : statusAnimationClass,
        compact ? '' : (block.status === 'failed' && 'border-error/30 bg-error/[0.06]')
      )}
    >
      {/* 统一头部 - 折叠和展开共用 */}
      <div
        className={clsx(
          'group flex items-center gap-2 cursor-pointer hover:bg-background-hover transition-colors',
          compact ? 'px-3 py-2 min-h-[44px]' : 'px-2.5 py-1.5',
          !compact && 'border-l-2',
          toolConfig.borderColor
        )}
        onClick={() => canExpand && setIsExpanded(!isExpanded)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            if (canExpand) {
              setIsExpanded(!isExpanded);
            }
          }
        }}
        tabIndex={canExpand ? 0 : -1}
        role="button"
        aria-expanded={isExpanded}
      >
        {/* 工具缩写图标 */}
        <div
          className={clsx(
            'w-5 h-5 rounded text-[10px] font-semibold flex items-center justify-center shrink-0',
            toolConfig.bgColor,
            toolConfig.color
          )}
        >
          {toolShortName}
        </div>

        {/* 工具名称 */}
        <span className="text-xs font-medium text-text-secondary shrink-0">
          {toolConfig.label}
        </span>

        {/* 关键参数 */}
        {keyInfo && (
          <span className={clsx('text-xs truncate flex-1 min-w-0', toolConfig.color)}>
            {keyInfo}
          </span>
        )}

        {/* 失败摘要：折叠态也能看到失败原因（一行截断，展开看完整 error） */}
        {errorSummary && !isExpanded && (
          <span
            className="text-[10px] text-error truncate max-w-[40%] shrink-0"
            title={block.error}
          >
            {errorSummary}
          </span>
        )}

        {/* 右侧信息区 */}
        <div className="flex items-center gap-1.5 ml-auto shrink-0">
          {/* 耗时：仅 > 1s 才显示，秒级完成不占位 */}
          {duration && durationMs > 1000 && (
            <span className="text-[10px] text-text-muted px-1.5 py-0.5 bg-background-secondary rounded tabular-nums">
              {duration}
            </span>
          )}

          {/* 折叠摘要：统一 grey，仅 status 类型保留语义色（成功/失败是真正需要颜色的信息） */}
          {collapsedSummary && collapsedSummary.summary && (
            <span className={clsx(
              'text-[10px] px-1.5 py-0.5 rounded',
              collapsedSummary.summaryType === 'status'
                ? (block.status === 'completed' ? 'text-success bg-success/10' : 'text-error bg-error/10')
                : 'text-text-tertiary bg-background-secondary'
            )}>
              {collapsedSummary.summary}
            </span>
          )}

          <StatusIcon className={clsx('w-3.5 h-3.5', statusConfig.className)} />

          {canExpand && (
            <ChevronDown
              className={clsx(
                'w-3 h-3 text-text-muted transition-transform duration-200',
                isExpanded && 'rotate-180'
              )}
            />
          )}
        </div>
      </div>

      {/* 展开时显示详情区域：单层背景，透明融入外层 elevated，避免嵌套色阶 */}
      {isExpanded && (
        <div className={clsx('border-t border-border', compact ? 'px-3 py-2' : 'px-4 py-3')}>
          {/* 工具名称和时间：始终显示起止时间，帮助用户判断最新活动与AI是否还在执行 */}
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-text-muted font-mono">{block.name}</span>
            <div className="text-xs text-text-tertiary flex gap-3">
              <span>{t('tool.startTime', { time: new Date(block.startedAt).toLocaleTimeString('zh-CN') })}</span>
              {block.completedAt && (
                <span>{t('tool.endTime', { time: new Date(block.completedAt).toLocaleTimeString('zh-CN') })}</span>
              )}
            </div>
          </div>

          {/* 文件路径：点击打开编辑器（非 Edit 工具，Edit 工具已整合到 InlineDiffView 头部） */}
          {fullFilePath && !isEditTool(block.name) && !isWriteTool(block.name) && (
            <div className="mb-3">
              <button
                type="button"
                className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-1"
                onClick={handleFilePathClick}
                title={fullFilePath}
              >
                <Code className="w-3 h-3 shrink-0" />
                <span className="truncate">{fullFilePath}</span>
              </button>
            </div>
          )}
          {/* Edit 工具：紧凑内联 Diff（负 margin 抵消父级 px-4 padding） */}
          {showDiffButton && block.diffData && (
            <div className="mb-3 -mx-4">
              <InlineDiffView
                filePath={block.diffData.filePath}
                oldContent={block.diffData.oldContent}
                newContent={block.diffData.newContent}
                diffString={block.diffData.diffString}
                edits={block.diffData.edits}
                onOpenFile={handleOpenFileByPath}
                maxHeight="240px"
              />
            </div>
          )}

          {/* Write 工具：代码预览 */}
          {isWriteTool(block.name) && block.input && !!(block.input.content || block.input.newContent) && (
            <div className="mb-3 -mx-4">
              <CodePreviewView
                filePath={(block.input.file_path || block.input.path || block.input.filePath) as string}
                content={(block.input.content || block.input.newContent) as string}
                onOpenFile={handleOpenFileByPath}
                maxHeight="240px"
              />
            </div>
          )}

          {/* apply_patch：多文件补丁渲染 */}
          {hasPatchData && (
            <PatchDiffRenderer block={block} />
          )}

          {/* update_plan：降级展示，仅显示简要信息 */}
          {isUpdatePlan && (
            <div className="mb-3">
              <div className="text-xs text-text-tertiary flex items-center gap-1.5 italic">
                <ListChecks className="w-3 h-3" />
                {t('tool.planUpdated')}
              </div>
            </div>
          )}

          {/* 非Edit/补丁/计划工具或无Diff：显示输入参数（左色条 + 标题，扁平结构） */}
          {!showDiffButton && !hasPatchData && !isUpdatePlan && !isWriteTool(block.name) && hasInput && (
            <div className="mb-3 border-l-2 border-border pl-3">
              <div className="text-xs text-text-muted mb-1.5 flex items-center gap-1.5">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
                {t('tool.inputParams')}
                {isBashTool && fullCommand && (
                  <button
                    onClick={handleCopyCommand}
                    className={clsx(
                      'ml-auto flex items-center gap-1 px-1.5 py-0.5 rounded text-xs transition-colors',
                      copiedCommand
                        ? 'text-success bg-success/10'
                        : 'text-primary hover:text-primary-hover'
                    )}
                  >
                    {copiedCommand ? (
                      <>
                        <Check className="w-3 h-3" />
                        {t('tool.copied')}
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        {t('tool.copyCommand')}
                      </>
                    )}
                  </button>
                )}
              </div>
              {isBashTool && fullCommand ? (
                <pre className="text-xs font-mono bg-background-surface rounded p-2.5 overflow-x-auto">
                  <code dangerouslySetInnerHTML={{ __html: highlightCode(fullCommand, 'bash') }} />
                </pre>
              ) : (
                <JsonTreeView data={block.input} defaultDepth={2} />
              )}
            </div>
          )}

          {/* Edit 工具：简化输出提示 */}
          {editOutputSummary && (
            <div className="mb-3">
              <div className={clsx(
                'text-xs flex items-center gap-1.5',
                editOutputSummary.type === 'success' ? 'text-success' : 'text-error'
              )}>
                {editOutputSummary.type === 'success' ? (
                  <Check className="w-3.5 h-3.5" />
                ) : (
                  <XCircle className="w-3.5 h-3.5" />
                )}
                {editOutputSummary.text}
              </div>
            </div>
          )}

          {/* 非Edit工具：完整输出结果（左色条 + 标题，扁平结构） */}
          {!isEditTool(block.name) && !isWriteTool(block.name) && hasOutput && (
            <div className="mb-3 border-l-2 border-border pl-3">
              <div className="text-xs text-text-muted mb-1.5 flex items-center gap-1.5">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {t('tool.outputResult')}
                <div className="ml-auto flex items-center gap-1.5">
                  {displayOutput && !outputIsJson && (
                    <button
                      onClick={handleCopyOutput}
                      className={clsx(
                        'flex items-center gap-1 px-1.5 py-0.5 rounded text-xs transition-colors',
                        copiedOutput
                          ? 'text-success bg-success/10'
                          : 'text-primary hover:text-primary-hover'
                      )}
                    >
                      {copiedOutput ? (
                        <>
                          <Check className="w-3 h-3" />
                          {t('tool.copied')}
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          {t('tool.copyOutput')}
                        </>
                      )}
                    </button>
                  )}
                  {outputNeedsExpand && !useCustomRenderer && !outputIsJson && (
                    <button
                      onClick={() => setShowFullOutput(!showFullOutput)}
                      className="text-primary hover:text-primary-hover text-xs"
                    >
                      {showFullOutput ? t('tool.collapse') : t('tool.expandAll')}
                    </button>
                  )}
                </div>
              </div>
              {useCustomRenderer && grepData ? (
                <GrepOutputRenderer data={grepData} />
              ) : outputIsJson ? (
                <JsonTreeView data={displayOutput} defaultDepth={2} />
              ) : renderedOutput ? (
                <pre
                  className={clsx(
                    'text-xs font-mono bg-background-surface rounded p-2.5 overflow-x-auto',
                    showFullOutput ? 'max-h-96 overflow-y-auto' : 'max-h-48 overflow-y-auto'
                  )}
                  dangerouslySetInnerHTML={{ __html: renderedOutput }}
                />
              ) : (
                <pre className={clsx(
                  'text-xs text-text-secondary bg-background-surface rounded p-2.5 overflow-x-auto font-mono',
                  showFullOutput ? 'max-h-96 overflow-y-auto' : 'max-h-48 overflow-y-auto'
                )}>
                  {showFullOutput
                    ? displayOutput
                    : (displayOutput.length > 1000
                      ? displayOutput.slice(0, 1000) + '\n... (' + t('tool.outputTruncated') + ')'
                      : displayOutput)}
                </pre>
              )}
            </div>
          )}

          {/* Edit 工具：工具详情折叠区域（默认展开，避免双层折叠） */}
          {isEditTool(block.name) && (hasInput || hasOutput) && (
            <div className="mb-3 border-l-2 border-border pl-3">
              <div
                onClick={() => setShowToolDetails(!showToolDetails)}
                className="text-xs text-text-tertiary hover:text-text-primary cursor-pointer flex items-center gap-1 select-none mb-1.5"
              >
                <ChevronRight
                  className={clsx(
                    'w-3 h-3 transition-transform',
                    showToolDetails && 'rotate-90'
                  )}
                />
                {t('tool.toolDetails')}
              </div>
              {showToolDetails && (
                <div className="space-y-2">
                  {hasInput && (
                    <div>
                      <div className="text-xs text-text-muted mb-1">{t('tool.inputParams')}</div>
                      <JsonTreeView data={block.input} defaultDepth={2} />
                    </div>
                  )}
                  {hasOutput && (
                    <div>
                      <div className="text-xs text-text-muted mb-1">{t('tool.outputResult')}</div>
                      <JsonTreeView data={displayOutput} defaultDepth={2} />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 错误信息（红色左色条，失败定位更醒目） */}
          {hasError && (
            <div className="mb-3 border-l-2 border-error/50 pl-3">
              <div className="text-xs text-error mb-1.5 flex items-center gap-1.5">
                <XCircle className="w-3 h-3" />
                {t('tool.errorInfo')}
              </div>
              <pre className="text-xs text-error bg-error-faint rounded p-2.5 overflow-x-auto font-mono">
                {block.error}
              </pre>
            </div>
          )}

          {/* 状态标签 */}
          <div className="flex items-center gap-2">
            <span className={clsx(
              'text-xs px-2 py-0.5 rounded-full',
              toolConfig.bgColor,
              toolConfig.color
            )}>
              {t(statusConfig.labelKey)}
            </span>
            {duration && (
              <span className="text-xs text-text-tertiary">
                {t('tool.duration', { duration })}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
});
