/**
 * 聊天导航组件
 *
 * 功能：
 * - 右侧进度条显示当前位置
 * - 悬停展开对话目录
 * - 点击对话轮次快速跳转
 * - 一键回到底部
 */

import { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { clsx } from 'clsx';
import { ArrowDown } from 'lucide-react';
import type { ConversationRound } from '@/utils/conversationRounds';
import { useWindowSize } from '@/hooks/useWindowSize';

interface ChatNavigatorProps {
  /** 对话轮次列表 */
  rounds: ConversationRound[];
  /** 当前可见的轮次索引 */
  currentRoundIndex: number;
  /** 回到底部回调 */
  onScrollToBottom: () => void;
  /** 滚动到指定轮次 */
  onScrollToRound: (roundIndex: number) => void;
  /** 导航样式变体：'floating' 当前浮球 | 'timeline' 右侧时间线 */
  variant?: 'floating' | 'timeline';
  /**
   * 面板顶部扩展槽（跨端会话交互 v2）：渲染在轮次列表上方。
   * 由调用方注入「其他设备进行中」区块（RemoteSessionsNavSection），
   * ChatNavigator 保持轮次导航的单一职责。
   */
  headerSlot?: React.ReactNode;
}

/** 延迟隐藏时间（毫秒） */
const HIDE_DELAY = 150;

/** 悬停展开延迟（毫秒）：悬停意图确认，快速掠过右缘不弹面板 */
const SHOW_DELAY = 250;

export function ChatNavigator({
  rounds,
  currentRoundIndex,
  onScrollToBottom,
  onScrollToRound,
  variant = 'floating',
  headerSlot,
}: ChatNavigatorProps) {
  const { t } = useTranslation('chat');
  const { isCompact } = useWindowSize({ compactThreshold: 500 });
  const [isPanelVisible, setIsPanelVisible] = useState(false);

  // 使用 ref 存储悬停状态，避免闭包陷阱
  const isHoveringRef = useRef(false);
  const isHoveringPanelRef = useRef(false);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // 当前高亮项的 ref，用于自动滚动到可视区域
  const currentItemRef = useRef<HTMLDivElement>(null);

  // 清除所有定时器
  const clearTimers = useCallback(() => {
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
    if (showTimerRef.current) {
      clearTimeout(showTimerRef.current);
      showTimerRef.current = null;
    }
  }, []);

  // 隐藏面板（带延迟）
  const scheduleHide = useCallback(() => {
    clearTimers();
    hideTimerRef.current = setTimeout(() => {
      // 直接读取 ref 的当前值，不依赖闭包
      if (!isHoveringRef.current && !isHoveringPanelRef.current) {
        setIsPanelVisible(false);
      }
    }, HIDE_DELAY);
  }, [clearTimers]);

  // 显示面板（带延迟）
  const scheduleShow = useCallback(() => {
    clearTimers();
    showTimerRef.current = setTimeout(() => {
      setIsPanelVisible(true);
    }, SHOW_DELAY);
  }, [clearTimers]);

  // 悬浮球悬停处理
  const handleFloatingBallMouseEnter = useCallback(() => {
    isHoveringRef.current = true;
    scheduleShow();
  }, [scheduleShow]);

  const handleFloatingBallMouseLeave = useCallback(() => {
    isHoveringRef.current = false;
    scheduleHide();
  }, [scheduleHide]);

  // 面板悬停处理
  const handlePanelMouseEnter = useCallback(() => {
    isHoveringPanelRef.current = true;
    clearTimers();
  }, [clearTimers]);

  const handlePanelMouseLeave = useCallback(() => {
    isHoveringPanelRef.current = false;
    scheduleHide();
  }, [scheduleHide]);

  // 组件卸载时清理定时器
  useEffect(() => {
    return () => clearTimers();
  }, [clearTimers]);

  // 面板定位（wrapper 层）：定位与动画分离——animate-dialog-in 的 keyframes
  // 会覆盖元素 inline transform（CSS 动画优先级高于 inline style），若单元素
  // 同时承担 translateY(-50%) 居中定位与入场动画，动画期间面板整体偏低半个
  // 高度、动画结束回落 inline transform 时瞬间上跳（悬停闪动主因，见
  // plans/chat-navigator-hover-flicker-fix.md）。外层 wrapper 只定位不动画，
  // 悬停事件也挂 wrapper，命中区在动画期间保持稳定。
  const panelWrapperStyle = useMemo(() => {
    if (isCompact) {
      return {
        right: '8px',
        left: '8px',
        bottom: '60px',
      };
    }
    if (variant === 'timeline') {
      // right:10px 与触发条 hover 区（right 2–10px）零间隙相接，
      // 消除圆点 → 面板之间无 hover 归属的死区（150ms 隐藏倒计时半途关面板）
      return {
        right: '10px',
        top: '50%',
        transform: 'translateY(-50%)',
      };
    }
    return {
      right: '24px',
      top: '50%',
      transform: 'translateY(-50%)',
    };
  }, [isCompact, variant]);

  const panelMaxHeight = isCompact ? '50vh' : '70vh';

  // 当面板显示或当前项变化时，滚动到当前项
  useEffect(() => {
    if (isPanelVisible && currentItemRef.current) {
      currentItemRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [isPanelVisible, currentRoundIndex]);

  // 点击对话轮次
  const handleRoundClick = useCallback((roundIndex: number) => {
    onScrollToRound(roundIndex);
    setIsPanelVisible(false);
  }, [onScrollToRound]);

  // 点击回到底部
  const handleScrollToBottom = useCallback(() => {
    onScrollToBottom();
    setIsPanelVisible(false);
  }, [onScrollToBottom]);

  // 触摸/点击切换面板
  const handleFloatingBallClick = useCallback(() => {
    setIsPanelVisible(prev => !prev);
  }, []);

  // 点击面板外部关闭（触摸模式）
  const floatingBallRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!isPanelVisible || !isCompact) return;
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node;
      const inFloatingBall = floatingBallRef.current?.contains(target) ?? false;
      const inPanel = panelRef.current?.contains(target) ?? false;

      if (!inFloatingBall && !inPanel) {
        setIsPanelVisible(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [isPanelVisible, isCompact]);

  if (rounds.length === 0 && !headerSlot) {
    return null;
  }

  return (
    <div className="absolute inset-0 pointer-events-none z-dropdown">
      {variant === 'timeline' ? (
        /* 时间线变体：贴边圆点列 */
        <div className="absolute right-0 top-0 bottom-0 w-3 z-dropdown pointer-events-none">
          {/* 仅圆点区域可触发，垂直居中，不铺满全高 */}
          <div
            ref={floatingBallRef}
            className="absolute left-0.5 right-0.5 top-1/2 -translate-y-1/2 flex flex-col items-center gap-1 pointer-events-auto cursor-pointer"
            onMouseEnter={handleFloatingBallMouseEnter}
            onMouseLeave={handleFloatingBallMouseLeave}
            onClick={handleFloatingBallClick}
          >
            {rounds.map((round, idx) => (
              <div
                key={round.roundIndex}
                className={clsx(
                  'w-1.5 h-1.5 rounded-full transition-all duration-150',
                  idx === currentRoundIndex
                    ? 'bg-primary scale-125 shadow-sm shadow-primary/40'
                    : round.hasTools
                      ? 'bg-warning/40'
                      : 'bg-border-strong',
                  'hover:scale-150 hover:bg-primary/80'
                )}
                onClick={(e) => {
                  e.stopPropagation();
                  handleRoundClick(idx);
                }}
                title={round.userSummary}
              />
            ))}
          </div>
        </div>
      ) : (
        /* 浮球变体：贴边悬浮球 - 位于当前聊天区域右边缘 */
        <div
          ref={floatingBallRef}
          className={clsx(
            'absolute right-0 top-1/2 -translate-y-1/2',
            // 尺寸：紧凑模式更大方便触摸
            isCompact ? 'w-9 h-9 rounded-l-xl' : 'w-7 h-12 rounded-l-xl',
            // 实心背景
            'bg-background-elevated',
            'border border-border/50 border-r-0',
            'shadow-lg shadow-black/5',
            // 内容布局
            'flex items-center justify-center',
            // 交互
            'pointer-events-auto cursor-pointer transition-all duration-150',
            'group',
            // 悬停状态
            isPanelVisible
              ? 'bg-background-elevated shadow-xl'
              : 'hover:bg-background-elevated hover:shadow-xl'
          )}
          onMouseEnter={handleFloatingBallMouseEnter}
          onMouseLeave={handleFloatingBallMouseLeave}
          onClick={handleFloatingBallClick}
          title={t('navigator.title')}
        >
          {/* 列表图标 - 表示对话轮次 */}
          <div className={clsx(
            'w-4 h-4 flex flex-col items-center justify-center gap-0.5',
            'transition-transform duration-200',
            isPanelVisible ? 'scale-110' : 'group-hover:scale-110'
          )}>
            {/* 数字列表样式 */}
            <div className="flex items-center gap-1 w-full">
              <div className="w-1 h-1 bg-text-secondary rounded-full" />
              <div className="flex-1 h-0.5 bg-text-muted rounded" />
            </div>
            <div className="flex items-center gap-1 w-full">
              <div className="w-1 h-1 bg-text-tertiary rounded-full" />
              <div className="w-2.5 h-0.5 bg-text-muted rounded" />
            </div>
            <div className="flex items-center gap-1 w-full">
              <div className="w-1 h-1 bg-text-tertiary rounded-full" />
              <div className="w-2 h-0.5 bg-text-muted rounded" />
            </div>
          </div>
        </div>
      )}

      {/* 悬浮面板：外层 wrapper 定位 + 悬停命中，内层跑入场动画（见 panelWrapperStyle 注释） */}
      {isPanelVisible && (
        <div
          ref={panelRef}
          className="absolute z-dropdown pointer-events-auto"
          style={panelWrapperStyle}
          onMouseEnter={handlePanelMouseEnter}
          onMouseLeave={handlePanelMouseLeave}
        >
          <div
            className={clsx(
              isCompact
                ? 'w-auto bg-background-elevated'
                : 'w-56 bg-background-elevated',
              'border border-border/80 rounded-lg shadow-lg shadow-black/20',
              'overflow-hidden animate-dialog-in',
              'flex flex-col'
            )}
            style={{ maxHeight: panelMaxHeight }}
          >
            {/* 标题 */}
            <div className="flex items-center justify-between px-2.5 py-1 shrink-0">
              <span className="text-[10px] text-text-tertiary tracking-wide">
                {t('navigator.title')}
              </span>
              <span className="text-[10px] text-text-muted">
                {rounds.length}
              </span>
            </div>

            {/* 对话轮次列表（顶部扩展槽：跨端会话区块由调用方注入） */}
            <div className="overflow-y-auto chat-navigator-list flex-1 min-h-0">
              {headerSlot}
              {rounds.map((round, idx) => (
                <div
                  key={round.roundIndex}
                  ref={idx === currentRoundIndex ? currentItemRef : null}
                  className={clsx(
                    'px-2.5 py-1.5 cursor-pointer transition-colors relative',
                    'hover:bg-background-hover',
                    idx === currentRoundIndex && 'bg-primary/5'
                  )}
                  onClick={() => handleRoundClick(idx)}
                >
                  {/* 当前轮次指示线 */}
                  {idx === currentRoundIndex && (
                    <div className="absolute left-0 top-1 bottom-1 w-0.5 bg-primary rounded-full" />
                  )}

                  {/* 第一行：序号 + 用户摘要 + 时间 */}
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={clsx(
                      'text-[10px] font-semibold w-3.5 text-right shrink-0',
                      idx === currentRoundIndex ? 'text-primary' : 'text-text-muted'
                    )}>
                      {round.roundIndex + 1}
                    </span>
                    <span className={clsx(
                      'text-xs truncate flex-1',
                      idx === currentRoundIndex ? 'text-text-primary' : 'text-text-secondary'
                    )}>
                      {round.userSummary}
                    </span>
                    <span className="text-[9px] text-text-muted shrink-0">
                      {round.timestamp}
                    </span>
                  </div>

                  {/* 第二行：助手回复 */}
                  {round.assistantMessage ? (
                    <div className="flex items-center gap-1.5 pl-5">
                      {round.hasTools && (
                        <span className="text-[9px] text-warning shrink-0">🔧</span>
                      )}
                      <span className="text-[10px] text-text-tertiary truncate">
                        {round.assistantSummary || t('navigator.replying')}
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 pl-5">
                      <span className="text-[10px] text-text-muted italic">
                        {t('navigator.waitingReply')}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* 底部按钮 */}
            <div className="flex justify-center px-2 py-1.5 shrink-0 border-t border-border-subtle/50">
              <button
                className="w-[50px] h-7 rounded-md flex items-center justify-center text-text-muted hover:text-text-secondary hover:bg-background-hover transition-colors"
                onClick={handleScrollToBottom}
                title={t('navigator.scrollToBottom')}
              >
                <ArrowDown className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
