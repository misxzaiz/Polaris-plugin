#!/usr/bin/env node
/**
 * Polaris 插件商城 MCP Server
 *
 * 提供工具：
 *   - search_plugins(query)        按关键字搜索商城索引
 *   - list_plugins(category?)      列出插件（可按分类过滤）
 *   - get_plugin_detail(id)        获取单个插件详情（含 versions 历史版本列表）
 *   - list_plugin_versions(id)     列出某个插件的所有历史版本
 *   - install_plugin(id, scope, version?) 一键安装：可选指定版本，
 *                                  默认安装最新版
 *   - proxy_fetch(url)             桌面侧代理 GET 一个索引 URL（手机/远程面板
 *                                  访问桌面本机商城源的通道：本地源对手机
 *                                  webview 不可达，由 MCP 进程代为请求）
 *
 * 索引地址通过环境变量 MARKETPLACE_INDEX 传入（默认指向本仓库 index.json）。
 * JSON-RPC 2.0 over stdin/stdout，与 Polaris MCP 规范一致。
 */
const http = require('http')
const https = require('https')

// 索引多源：raw.githubusercontent 优先（最新无 CDN 缓存），jsdelivr 兜底（国内可直连但缓存延迟）。
// 任一源失败自动重试并回退下一个源。
// 可通过环境变量 MARKETPLACE_INDEX 覆盖为单一自定义源。
const INDEX_URLS = process.env.MARKETPLACE_INDEX
  ? [process.env.MARKETPLACE_INDEX]
  : [
      'https://raw.githubusercontent.com/misxzaiz/Polaris-plugin/main/index.json',
      'https://cdn.jsdelivr.net/gh/misxzaiz/Polaris-plugin@main/index.json'
    ]
const INDEX_TIMEOUT = 15000
const INDEX_RETRIES = 2

function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n') }

function fetchWithTimeout(url, timeout) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http
    const req = lib.get(url, { headers: { 'Accept': 'application/json' } }, (res) => {
      let data = ''
      res.on('data', c => { data += c })
      res.on('end', () => {
        if (res.statusCode !== 200) {
          reject(new Error(`HTTP ${res.statusCode}`))
          return
        }
        try { resolve(JSON.parse(data)) } catch (e) { reject(new Error('解析 JSON 失败: ' + e.message)) }
      })
    })
    req.on('error', reject)
    req.setTimeout(timeout, () => { req.destroy(new Error('请求超时')) })
  })
}

function fetchJson(url) {
  return fetchWithTimeout(url, INDEX_TIMEOUT)
}

// 依序尝试每个源，每个源失败后重试 INDEX_RETRIES 次，全部失败才报错
async function fetchIndexMulti() {
  let lastErr = null
  for (const url of INDEX_URLS) {
    for (let attempt = 0; attempt <= INDEX_RETRIES; attempt++) {
      try {
        return await fetchJson(url)
      } catch (e) {
        lastErr = e
        if (attempt < INDEX_RETRIES) {
          await new Promise(r => setTimeout(r, 500 * (attempt + 1)))
        }
      }
    }
  }
  throw lastErr || new Error('所有索引源均不可用')
}

let cache = null
let cacheAt = 0
async function getIndex() {
  const now = Date.now()
  if (cache && now - cacheAt < 60000) return cache
  cache = await fetchIndexMulti()
  cacheAt = now
  return cache
}

const tools = [
  {
    name: 'search_plugins',
    description: '在 Polaris 插件商城按关键字搜索插件（匹配 id/name/description/tags）。',
    inputSchema: {
      type: 'object',
      properties: { query: { type: 'string', description: '搜索关键字' } },
      required: ['query']
    }
  },
  {
    name: 'list_plugins',
    description: '列出 Polaris 插件商城中的插件，可按分类过滤。',
    inputSchema: {
      type: 'object',
      properties: {
        category: { type: 'string', description: '可选分类过滤' },
        limit: { type: 'number', description: '返回上限，默认 50' }
      }
    }
  },
  {
    name: 'get_plugin_detail',
    description: '获取某个插件的完整详情（含 downloadUrl / updateUrl / 权限 / versions 历史版本列表）。',
    inputSchema: {
      type: 'object',
      properties: { id: { type: 'string', description: '插件 id' } },
      required: ['id']
    }
  },
  {
    name: 'list_plugin_versions',
    description: '列出某个插件的所有历史版本（含版本号、downloadUrl、sha256）。',
    inputSchema: {
      type: 'object',
      properties: { id: { type: 'string', description: '插件 id' } },
      required: ['id']
    }
  },
  {
    name: 'install_plugin',
    description: '一键安装插件：返回该插件的 downloadUrl 与安装指引。可选 version 参数指定安装历史版本，不传则安装最新版。',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: '插件 id' },
        version: { type: 'string', description: '可选，指定安装的版本号（如 "0.3.0"）。不传则安装最新版。' },
        scope: { type: 'string', enum: ['user', 'project'], description: '安装作用域，默认 user' }
      },
      required: ['id']
    }
  },
  {
    name: 'list_installed',
    description: '列出本地已安装的 Polaris 插件（含 installPath / 版本 / 来源）。',
    inputSchema: { type: 'object', properties: {} }
  },
  {
    name: 'uninstall_plugin',
    description: '卸载已安装的插件。需先通过 list_installed 获取 installPath。',
    inputSchema: {
      type: 'object',
      properties: {
        installPath: { type: 'string', description: '插件安装路径（来自 list_installed）' }
      },
      required: ['installPath']
    }
  },
  {
    name: 'check_plugin_update',
    description: '检查已安装插件是否有新版本（读取其 origin.updateUrl 比对版本）。',
    inputSchema: {
      type: 'object',
      properties: {
        installPath: { type: 'string', description: '插件安装路径' }
      },
      required: ['installPath']
    }
  },
  {
    name: 'apply_plugin_update',
    description: '应用插件更新：下载新版本并替换。需先 installPath。',
    inputSchema: {
      type: 'object',
      properties: {
        installPath: { type: 'string', description: '插件安装路径' }
      },
      required: ['installPath']
    }
  },
  {
    name: 'proxy_fetch',
    description: '桌面侧代理 GET 一个索引 URL 并返回解析后的 JSON。用于手机/远程面板访问桌面本机商城源（如 http://127.0.0.1:8787/index.json）——面板 webview 直 fetch 会因拓扑（127.0.0.1 指向手机自身）、CORS 或混合内容策略失败，本工具在桌面 MCP 进程内代为请求，天然可达桌面本地服务。',
    inputSchema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '索引 URL（http/https），如 http://127.0.0.1:8787/index.json' }
      },
      required: ['url']
    }
  }
]

async function handleCall(name, args) {
  // proxy_fetch 不依赖商城索引（它正是索引不可达时的旁路），单独处理
  if (name === 'proxy_fetch') {
    const url = String(args.url || '').trim()
    if (!/^https?:\/\//i.test(url)) {
      return { error: `url 必须是 http/https 地址，收到: ${url || '(空)'}` }
    }
    // 只代理索引/元数据 JSON，拒绝可执行文件与安装包（防被当通用代理滥用）
    const pathPart = url.split(/[?#]/)[0]
    if (/\.(zip|exe|dll|bat|cmd|ps1|sh|msi)(\?|$)/i.test(pathPart)) {
      return { error: 'proxy_fetch 仅用于索引/元数据 JSON，不代理可执行文件或安装包' }
    }
    const data = await fetchJson(url)
    return { url, fetchedAt: new Date().toISOString(), data }
  }

  const index = await getIndex()
  const plugins = Array.isArray(index.plugins) ? index.plugins : []

  if (name === 'search_plugins') {
    const q = String(args.query || '').toLowerCase()
    const matches = plugins.filter(p => {
      const hay = [p.id, p.name, p.description, (p.tags || []).join(' ')].join(' ').toLowerCase()
      return hay.includes(q)
    })
    return matches.map(p => ({
      id: p.id, name: p.name, version: p.version, description: p.description, category: p.category, tier: p.tier || 'demo'
    }))
  }

  if (name === 'list_plugins') {
    const cat = args.category
    let list = cat ? plugins.filter(p => p.category === cat) : plugins
    list = list.slice(0, Number(args.limit) || 50)
    return list.map(p => ({
      id: p.id, name: p.name, version: p.version, description: p.description, category: p.category, tier: p.tier || 'demo'
    }))
  }

  if (name === 'get_plugin_detail') {
    const p = plugins.find(x => x.id === args.id)
    if (!p) return { error: `未找到插件: ${args.id}` }
    return {
      id: p.id, name: p.name, version: p.version, description: p.description,
      author: p.author, category: p.category, tags: p.tags, tier: p.tier || 'demo', permissions: p.permissions,
      manifestUrl: p.manifestUrl, downloadUrl: p.downloadUrl, updateUrl: p.updateUrl,
      sha256: p.sha256, readme: p.readme,
      versions: p.versions || []
    }
  }

  if (name === 'list_plugin_versions') {
    const p = plugins.find(x => x.id === args.id)
    if (!p) return { error: `未找到插件: ${args.id}` }
    const versions = p.versions || []
    if (versions.length === 0) return { id: p.id, version: p.version, versions: [{ version: p.version, downloadUrl: p.downloadUrl, sha256: p.sha256 }], note: '该插件未记录历史版本，仅返回当前最新版' }
    return { id: p.id, version: p.version, versions }
  }

  if (name === 'install_plugin') {
    const p = plugins.find(x => x.id === args.id)
    if (!p) return { error: `未找到插件: ${args.id}` }

    // 如果指定了版本号，从 versions 中查找对应版本的 downloadUrl
    if (args.version) {
      const versions = p.versions || []
      const target = versions.find(v => v.version === args.version)
      if (!target) return { error: `未找到插件 ${args.id} 的版本 ${args.version}。可用版本：${versions.map(v => v.version).join(', ') || p.version}` }
      return {
        id: p.id, name: p.name, version: target.version, tier: p.tier || 'demo',
        downloadUrl: target.downloadUrl,
        scope: args.scope || 'user',
        instruction: `调用 Polaris 总线 router_dispatch → cap.pluginDiscovery，payload action="install_remote"，sourceUrl="${target.downloadUrl}"，scope="${args.scope || 'user'}"`
      }
    }

    return {
      id: p.id, name: p.name, version: p.version, tier: p.tier || 'demo',
      downloadUrl: p.downloadUrl,
      scope: args.scope || 'user',
      instruction: `在 Polaris 设置 → 插件 → 远程安装，粘贴此 downloadUrl；或让 AI 调用 installRemotePlugin 完成：${p.downloadUrl}`
    }
  }

  // 以下工具操作本地已装插件。MCP server 为独立 Node 进程，无法直接调用
  // Tauri 命令，因此返回操作指引与所需参数，由面板或 AI 在宿主侧执行。
  if (name === 'list_installed') {
    return {
      note: 'MCP 进程无法直接读取本地已装列表。请在 Polaris 商城面板查看「已装」标签，',
      hint: '或由 AI 引导用户打开 设置 → 插件 查看已装插件及其 installPath。'
    }
  }

  if (name === 'uninstall_plugin') {
    return {
      installPath: args.installPath,
      instruction: `调用 Polaris 总线 router_dispatch → cap.pluginDiscovery，payload action="uninstall_local"，installPath="${args.installPath}"。面板的「已装」标签提供一键卸载。`
    }
  }

  if (name === 'check_plugin_update') {
    return {
      installPath: args.installPath,
      instruction: `调用 Polaris 总线 router_dispatch → cap.pluginDiscovery，payload action="check_update"，installPath="${args.installPath}"。返回 updateAvailable/latestVersion/downloadUrl。面板「已装」标签提供一键检查。`
    }
  }

  if (name === 'apply_plugin_update') {
    return {
      installPath: args.installPath,
      instruction: `调用 Polaris 总线 router_dispatch → cap.pluginDiscovery，payload action="apply_update"，installPath="${args.installPath}"。面板「已装」标签提供一键更新。`
    }
  }

  return { error: `未知工具: ${name}` }
}

let buf = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => {
  buf += chunk
  while (true) {
    const i = buf.indexOf('\n')
    if (i === -1) break
    const line = buf.slice(0, i).trim()
    buf = buf.slice(i + 1)
    if (!line) continue
    let msg
    try { msg = JSON.parse(line) } catch { continue }
    if (msg.method === 'initialize') {
      send({ jsonrpc: '2.0', id: msg.id, result: {
        protocolVersion: '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'polaris-marketplace', version: '1.0.0' }
      }})
    } else if (msg.method === 'tools/list') {
      send({ jsonrpc: '2.0', id: msg.id, result: { tools } })
    } else if (msg.method === 'tools/call') {
      const { name, arguments: args } = msg.params || {}
      handleCall(name, args)
        .then(result => send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] } }))
        .catch(e => send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: `错误: ${e.message}` }], isError: true } }))
    }
  }
})
